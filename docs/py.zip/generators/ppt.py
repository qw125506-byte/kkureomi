# -*- coding: utf-8 -*-
"""⑤ 진행 PPT — 간담회진행PPT 스킬(build_ppt.py, 시 견본 복제 방식)을 공통 행사데이터에 연결한다.

스킬은 혼자서도 돌 수 있게 자체 시각 계산을 갖고 있지만, 여기서는 core/calc.py 계산으로 바꿔 끼워
모든 문서가 같은 계산을 쓰게 한다. 견본은 templates/ppt.pptx.
"""
import importlib.util
import io
import contextlib

from core import calc
from core.hwpx import ROOT, TEMPLATES

_spec = importlib.util.spec_from_file_location("build_ppt", ROOT / "간담회진행PPT" / "scripts" / "build_ppt.py")
bpp = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(bpp)
bpp.TEMPLATE = TEMPLATES / "ppt.pptx"
bpp.with_times = lambda event, program: calc.program_times(event, program)[0]


def generate(data, out_path, extras=False):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        bpp.build(data, out_path, extras=extras)
    return {"path": str(out_path), "warnings": [], "log": buf.getvalue().strip()}


def read_text(path):
    """PPTX 장표 글자(검증용)"""
    import re
    import zipfile
    out = []
    with zipfile.ZipFile(path) as z:
        names = sorted((n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)),
                       key=lambda n: int(re.findall(r"\d+", n)[0]))
        for n in names:
            x = z.read(n).decode("utf-8")
            for para in re.findall(r"<a:p>.*?</a:p>", x, flags=re.S):
                s = "".join(re.findall(r"<a:t>([^<]*)</a:t>", para))
                if s.strip():
                    out.append(s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"'))
    return out
