# -*- coding: utf-8 -*-
"""④ 보도자료 — templates/press.hwpx(2026 유니브시티 페스티벌 보도자료)를 복제해 내용만 바꾼다.

원본 구성: 담당 표(부서·팀 / 담당팀장 / 담당자 / 사진 O·X / 관련자료) / 제목 / 부제 / 본문 문단.
본문 문장은 data.press(4단계 AI 초안 → 사람이 확인)에서만 가져온다. 없으면 「[확인 필요]」 표시만 넣는다.
시장 인용문(press.quote)에는 기본으로 「[확인 필요]」를 붙인다(mark_quote=False로 끌 수 있음).
"""
import copy

from core.hwpx import BuildError, Doc, N, cell, cell_ps, clone, expect_text, insert_after, remove, set_cell_lines, set_only

T_HEAD = "2137484011"
P = dict(title=2, subtitle=3, body_from=6, body_to=25)
TOPS = 27
CHECK = "[확인 필요]"


def staff_of(data, *keys):
    for s in data["org"].get("staff") or []:
        if any(k in s["role"] for k in keys):
            return s
    return None


def phone(data, s):
    tel = s.get("tel", "")
    pre = data["org"].get("phone_prefix", "")
    return f"{pre}{tel}" if tel and len(tel) <= 4 else tel


def generate(data, out_path, mark_quote=True):
    org, press = data["org"], data.get("press") or {}
    doc = Doc("press.hwpx")
    tops = doc.orig
    if len(tops) != TOPS:
        raise BuildError(f"보도자료 원본 문단 수({len(tops)})가 예상({TOPS})과 다릅니다")
    expect_text(tops[P["body_to"]], "한편", "보도자료 마지막 문단")

    # 담당 표
    t = doc.tbl(T_HEAD)
    set_cell_lines(cell(t, 2, 0), [org["dept"]] + ([org["team"]] if org.get("team") else []))
    for col, keys in ((1, ("팀장",)), (2, ("담당",))):
        s = staff_of(data, *keys)
        set_cell_lines(cell(t, 2, col), [s["name"], f"({phone(data, s)})"] if s else [""])
        if not s:
            doc.warnings.append(f"보도자료 담당 표: {keys[0]} 정보(org.staff)가 없음")
    set_cell_lines(cell(t, 2, 3), ["O" if press.get("photo") else "X"])

    # 제목·부제
    title = press.get("title") or f"{CHECK} 제목"
    set_only(tops[P["title"]], f"“{title}”")
    if press.get("subtitle"):
        set_only(tops[P["subtitle"]], f'- {press["subtitle"]} -')
    else:
        set_only(tops[P["subtitle"]], f"- {CHECK} 부제 -")

    # 본문
    body = list(press.get("body") or [])
    if press.get("quote"):
        q = press["quote"] + (f" {CHECK}" if mark_quote else "")
        if body and body[-1].startswith("한편"):
            body.insert(len(body) - 1, q)
        else:
            body.append(q)
    if not body:
        body = [f"{CHECK} 보도자료 본문이 아직 없습니다. AI 초안(4단계)을 만들거나 직접 입력하세요."]
        doc.warnings.append("보도자료 본문(press.body)이 비어 있어 확인 필요 표시만 넣음")
    old = tops[P["body_from"]:P["body_to"] + 1]
    lead, para, blank = copy.deepcopy(old[0]), copy.deepcopy(old[2]), copy.deepcopy(old[3])
    new = []
    for i, s in enumerate(body):
        if i:
            new.append(clone(blank))
        p = clone(lead if i == 0 else para)
        set_only(p, f"  {s}" if i == 0 else s)
        new.append(p)
    insert_after(old[-1], new)
    for p in old:
        remove(p)
    return doc.save(out_path, f"{data['event']['title']} 보도자료")
