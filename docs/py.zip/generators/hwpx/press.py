# -*- coding: utf-8 -*-
"""④ 보도자료 — templates/press.hwpx(사용자 견본 「(창업견본) 보도자료」)를 복제해 내용만 바꾼다.

견본 구성: 담당 표(부서·팀 / 담당팀장 / 담당자 / 사진 / 관련자료) / 제목 / 부제 / 본문 아홉 문단(문단 사이 한 줄 띄움):
  ① 개최(리드) ② 참석 ③ 진행 ④~⑥ 논의 내용 셋 ⑦ 시 답변 ⑧ 시장 발언 ⑨ 향후계획
본문 문장은 data.press(자동 작성 core/autofill.rule_press 또는 사람이 쓴 것)에서만 가져온다.
시장 인용문(press.quote)은 ⑧자리에 넣고 기본으로 「[확인 필요]」를 붙인다(mark_quote=False로 끌 수 있음).
"""
import copy

from core.hwpx import BuildError, Doc, N, bp, cell, clone, expect_text, insert_after, remove, set_cell_lines, set_only

T_HEAD = "2137484011"
P = dict(title=2, subtitle=3, body_from=6, body_to=22)
TOPS = 25
PROTO_LEAD, PROTO_BLANK, PROTO_PARA = 6, 7, 10          # 리드·빈 줄·본문 문단 본(견본 문단 번호)
CHECK = "[확인 필요]"


def staff_of(data, *keys):
    for s in data["org"].get("staff") or []:
        if any(k in s["role"] for k in keys):
            return s
    return None


def phone(data, s):
    tel = s.get("tel", "")
    pre = data["org"].get("phone_prefix", "")
    return f"{pre}{tel}" if tel and len(tel) <= 4 else tel


def one_line(p, sec):
    """제목·부제가 한 줄에 들어가게 자간을 줄인다(견본은 한 줄). 안 되면 그대로 둔다."""
    from generators.hwpx.brief import fit                      # 자간을 줄여 보고, 그래도 넘치면 글자 크기를 조금(85%까지) 줄임
    fit(p, bp.body_avail(sec), ratio=0.97, squeeze=10, min_scale=0.85)


def generate(data, out_path, mark_quote=True):
    org, press = data["org"], data.get("press") or {}
    doc = Doc("press.hwpx")
    tops = doc.orig
    if len(tops) != TOPS:
        raise BuildError(f"보도자료 원본 문단 수({len(tops)})가 예상({TOPS})과 다릅니다")
    expect_text(tops[P["body_to"]], "후속", "보도자료 마지막 문단")

    # 담당 표
    t = doc.tbl(T_HEAD)
    set_cell_lines(cell(t, 2, 0), [org["dept"]] + ([org["team"]] if org.get("team") and org["team"] != org["dept"] else []))
    for col, keys in ((1, ("팀장",)), (2, ("담당",))):
        s = staff_of(data, *keys)
        set_cell_lines(cell(t, 2, col), [s["name"], f"({phone(data, s)})"] if s else [""])
        if not s:
            doc.warnings.append(f"보도자료 담당 표: {keys[0]} 정보(org.staff)가 없음")
    set_cell_lines(cell(t, 2, 3), ["○"])
    set_cell_lines(cell(t, 2, 4), ["○"])

    # 제목·부제
    title = press.get("title") or f"{CHECK} 제목"
    set_only(tops[P["title"]], f"“{title}”")
    one_line(tops[P["title"]], doc.sec)
    sub = press.get("subtitle") or f"{CHECK} 부제"
    set_only(tops[P["subtitle"]], f"- {sub} -")
    one_line(tops[P["subtitle"]], doc.sec)

    # 본문
    body = list(press.get("body") or [])
    if press.get("quote"):
        q = press["quote"] + (f" {CHECK}" if mark_quote else "")
        if body and body[-1].startswith("한편"):
            body.insert(len(body) - 1, q)
        else:
            body.insert(max(len(body) - 1, 0), q) if len(body) > 1 else body.append(q)
    if not body:
        body = [f"{CHECK} 보도자료 본문이 아직 없습니다. 자동 작성을 쓰거나 직접 입력하세요."]
        doc.warnings.append("보도자료 본문(press.body)이 비어 있어 확인 필요 표시만 넣음")
    if press.get("body") and not (data.get("result") or {}).get("suggestions") and any('“' in x for x in body):
        doc.warnings.append("시장 발언(따옴표)은 행사 취지로 쓴 초안입니다. 회의록을 올려 두면 실제 발언으로 쓰고, 아니면 배포 전에 실제 발언으로 바꿔 주세요.")
    old = tops[P["body_from"]:P["body_to"] + 1]
    lead, blank, para = copy.deepcopy(old[0]), copy.deepcopy(old[1]), copy.deepcopy(old[PROTO_PARA - P["body_from"]])
    new = []
    for i, s in enumerate(body):
        if i:
            new.append(clone(blank))
        if i == 0:
            p = clone(lead)
            set_only(p, f"  {s}")
        else:
            p = clone(para)
            set_only(p, f"  {s}")
        new.append(p)
    insert_after(old[-1], new)
    for p in old:
        remove(p)
    return doc.save(out_path, f"{data['event']['title']} 보도자료")
