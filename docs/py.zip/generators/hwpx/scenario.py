# -*- coding: utf-8 -*-
"""③ 진행 시나리오 — templates/scenario.hwpx를 복제해 내용만 바꾼다.

원본 구성: 표지(일시·장소 / 제목 / 안건 / 부서) → 1쪽 「사전안내·안내」 표 → 식순별 쪽(「식 순 | 시 나 리 오 | 비 고」 표).
식순 쪽은 원본 3쪽째 표를 본으로 식순마다 1쪽씩 다시 만든다.
- 사회자 멘트: program[].script (없으면 「다음은 ~이 있겠습니다.」 기본 문형)
- type=attendees 식순 뒤: 주빈·참석자 소개 쪽, 배석자 소개 쪽
- type=discussion 식순: 「(토의주재) …」
"""
import copy
import re

from core.hwpx import (Doc, BuildError, N, Q, cell, cell_ps, clone, expect_text, find_tbl, insert_after, josa,
                       owner_p, p_with, remove, set_only, set_runs, spaced)

T_COVER_WHEN = "2030456389"
T_TITLE = "2082232949"
T_DEPT = "2082232964"
T_OPENING = "1154476336"
T_PAGE = "1154476342"      # 식순 쪽 본(참석자 소개 쪽)
T_NOTE_SRC = "1154476380"  # [영상 시청 후] 같은 괄호 줄 서식
P = dict(when=0, title=5, agenda=7, dept=10, opening=11, pages_from=12, pages_to=18)
TOPS = 27


class Lines:
    """칸 안 문단 본: ◯ 줄, 이어지는 줄, 빈 줄, 괄호 안내 줄, (인 사) 줄"""

    def __init__(self, sec):
        op = cell(find_tbl(sec, T_OPENING), 2, 1)
        ps = cell_ps(op)
        self.bullet, self.cont, self.blank, self.aside = (copy.deepcopy(ps[0]), copy.deepcopy(ps[1]),
                                                          copy.deepcopy(ps[2]), copy.deepcopy(ps[3]))
        self.note = copy.deepcopy(cell_ps(cell(find_tbl(sec, T_NOTE_SRC), 1, 1))[0])
        lab = cell_ps(cell(find_tbl(sec, T_PAGE), 1, 0))
        self.label, self.lead = copy.deepcopy(lab[0]), copy.deepcopy(lab[1])

    def make(self, kind, text=""):
        src = {"o": self.bullet, "c": self.cont, "b": self.blank, "a": self.aside, "n": self.note,
               "label": self.label, "lead": self.lead}[kind]
        p = clone(src)
        if kind == "o":
            text = f" ◯ {text}"
        elif kind == "c":
            text = f"    {text}"
        set_only(p, text)
        return p


def fill_cell(tc, paras):
    sub = tc.find("hp:subList", N)
    for p in cell_ps(tc):
        sub.remove(p)
    for p in paras:
        sub.append(p)


def sentences(script):
    return [s for s in re.split(r"(?<=[.?!])\s+", (script or "").strip()) if s]


def mc_name(data, role):
    for s in data["org"].get("staff") or []:
        if s["role"] == role:
            return s["name"]
    return ""


def guests_word(data):
    label = data["event"].get("attendee_label") or ""
    tail = label.split(",")[-1].strip()
    return f"{tail}님들" if tail else "참석자 여러분"


def opening(doc, L, data):
    ev, prog = data["event"], data["program"]
    mc = data["derived"]["program"][0]["lead"]
    name = mc_name(data, mc)
    t = doc.tbl(T_OPENING)
    for r, lbl in ((1, "사전안내"), (2, "안   내")):
        fill_cell(cell(t, r, 0), [L.make("label", lbl), L.make("lead", f"({mc})")])
    title = ev["title"]
    fill_cell(cell(t, 1, 1), [L.make("o", f"잠시 후, {title}{josa(title, '을/를')} 시작할 예정이오니 자리에 착석하여 주시기 "
                                       "바라며, 원활한 진행을 위하여 핸드폰은 진동 또는 전원을 꺼주시면 감사하겠습니다.")])
    order = ", ".join(p["item"] for p in prog[1:-1]) or ", ".join(p["item"] for p in prog)
    fill_cell(cell(t, 2, 1), [
        L.make("o", "안녕하십니까?"),
        L.make("c", f'{data["org"]["dept"]} {mc} {name}입니다.' if name else f'{data["org"]["dept"]} {mc}입니다.'),
        L.make("b"), L.make("a", " (인     사) "), L.make("b"),
        L.make("o", f"바쁘신 일정에도 불구하고 본 회의에 참석해 주신 {guests_word(data)}께 감사드리며, "
                    "오늘 회의 진행순서를 간략히 말씀드리겠습니다."),
        L.make("b"),
        L.make("o", f"오늘 회의는 {order} 순으로 진행하겠습니다."),
    ])


def page(tmpl, L, label, lead, paras):
    p = clone(tmpl)
    p.set("pageBreak", "1")
    t = p.find(".//hp:tbl", N)
    fill_cell(cell(t, 1, 0), [L.make("label", label), L.make("lead", f"({lead})"), L.make("b")])
    fill_cell(cell(t, 1, 1), paras or [L.make("b")])
    fill_cell(cell(t, 1, 2), [L.make("b")])
    return p


def program_pages(tmpl, L, data, d):
    pages, rows = [], d["program"]
    host = data["host"]
    for i, st in enumerate(rows):
        paras = []
        if i:
            paras += [L.make("n", f'[{rows[i - 1]["item"]} 종료 후]'), L.make("b")]
        lines = sentences(st.get("script")) or [
            f'다음은 {st["lead"]}의 「{st["item"]}」{josa(st["item"], "이/가")} 있겠습니다.']
        for k, s in enumerate(lines):
            if k:
                paras.append(L.make("b"))
            paras.append(L.make("o", s))
        if st.get("type") == "discussion":
            paras += [L.make("b"), L.make("c", f'(토의주재) {st.get("desc") or st["item"]}')]
        pages.append(page(tmpl, L, st["item"], st["lead"], paras))

        if st.get("type") == "attendees":
            intro = [L.make("o", f'먼저, {host["name"]} {host["position"]}님 참석하셨습니다.'), L.make("b")]
            for a in data["attendees"]:
                intro.append(L.make("c", f'{a["name"]} {a["org"]} {a["position"]}님 참석하셨습니다.'))
            pages.append(page(tmpl, L, "참석자 소개", st["lead"], intro))
            staff = data.get("staff_present") or []
            if staff:
                city = data["org"]["city"]
                sp = [L.make("o", f"다음은, {city}청 간부님들을 소개해 드리겠습니다."), L.make("b")]
                sp += [L.make("c", f'{s["name"]} {s["position"]}님 참석하셨습니다.') for s in staff]
                pages.append(page(tmpl, L, "참석자 소개", st["lead"], sp))
    return pages


def generate(data, out_path):
    d, ev = data["derived"], data["event"]
    doc = Doc("scenario.hwpx")
    tops = doc.orig
    if len(tops) != TOPS:
        raise BuildError(f"시나리오 원본 문단 수({len(tops)})가 예상({TOPS})과 다릅니다")
    expect_text(tops[P["title"]], "시나리", "시나리오 제목")
    L = Lines(doc.sec)
    tmpl = copy.deepcopy(owner_p(doc.tbl(T_PAGE)))

    # 표지
    set_runs(p_with(doc.tbl(T_COVER_WHEN), "2026"),
             {0: f'{d["date_text"]} {ev.get("venue_short") or ev["venue"]} {ev["start"]}'})
    set_runs(p_with(doc.tbl(T_TITLE), "시나리"), {0: f'{ev["title"]} '}, expect={1: "회의"})
    set_runs(p_with(tops[P["agenda"]], "(안"), {3: f' {ev.get("summary", "")}'}, expect={2: "(안"})
    t = doc.tbl(T_DEPT)
    set_only(p_with(t, "천 안 시"), spaced(data["org"]["city"]))
    set_only(p_with(t, "("), f'({data["org"]["dept"]})')

    opening(doc, L, data)
    old = tops[P["pages_from"]:P["pages_to"] + 1]
    insert_after(tops[P["opening"]], program_pages(tmpl, L, data, d))
    for p in old:
        remove(p)
    return doc.save(out_path, f'{ev["title"]} 시나리오')
