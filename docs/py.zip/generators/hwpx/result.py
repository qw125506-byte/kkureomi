# -*- coding: utf-8 -*-
"""⑥ 결과보고 — templates/result.hwpx(2026년 대학 총장 초청 간담회 결과보고)를 복제해 내용만 바꾼다.

원본 구성: 결재란 / 요약 표지(핵심 항목·일시·장소·참석·주요내용·의견수렴·향후계획) / 본문 제목·보고 문장 /
시장님 총평 / Ⅰ 간담회 개요 / Ⅱ 기관별 의견수렴 표 / Ⅳ(→Ⅲ) 향후계획 / 붙임(회의록·참석자 명단·사진).
- 원본은 Ⅰ, Ⅱ, Ⅳ로 Ⅲ이 빠져 있어 Ⅲ으로 바로잡는다.
- 표지와 본문 일시 모두 실제 종료 시각(result.actual_end, 없으면 계획 종료)을 쓴다(원본은 15:00/15:20으로 달랐음).
"""
import copy
import re

from core import calc
from core.hwpx import (Doc, BuildError, N, Q, cell, cell_ps, clone, expect_text, find_tbl, insert_after, josa,
                       merge_same, owner_p, p_with, rebuild_rows, remove, renumber, runs, set_cell_lines, set_only,
                       set_runs, spaced, tr_cells, bf_image)

T_APPROVAL = "2113655862"
T_TITLE = "2113655867"
T_COVER = "2113655868"
T_DEPT = "2113655880"
T_BODY_TITLE = "2113655898"
T_INTENT = "2113655899"
T_SUGGEST = "1170865051"
T_SUGGEST_HEAD = "1170865049"
T_PLAN_HEAD = "1170865053"
T_MINUTES_HEAD = "1170865055"
T_MINUTES = "1170865071"
T_ROSTER_HEAD = "1171806921"
T_ROSTER = "1171806919"
T_PHOTO_HEAD = "1170865073"
T_PHOTO = "1170865074"
P = dict(review=15, review_body=16, overview=22, plan_from=35, plan_to=37, att_from=41, att_to=43,
         minutes_from=45, minutes_to=51, roster_from=52, roster_to=53, photo_from=54, photo_to=55)
TOPS = 56
NUMS = "❶❷❸❹❺❻❼❽❾❿⓫⓬⓭⓮⓯⓰⓱⓲⓳⓴"


def short_pos(position, city):
    """천안시장 → 시장 (명단의 기관 칸에 시 이름이 있으므로)"""
    stem = city[:-1] if city.endswith("시") else city
    return position[len(stem):] if position.startswith(stem) and len(position) > len(stem) else position


def spaced_pos(pos):
    """원본 표기: 시  장  님, 총  장 (짧은 직위만 띄움)"""
    return ("  " if len(pos) == 3 else "   ").join(pos) if len(pos) <= 3 else pos


def fill_approval(doc, data):
    org, t = data["org"], doc.tbl(T_APPROVAL)
    set_cell_lines(cell(t, 0, 1), [f'{org["dept"]}    - '])
    line = org.get("approval_line") or []
    slots = [3, 4, 5, 6, 8, 9]
    if len(line) != len(slots):
        doc.warnings.append(f"결재선 {len(line)}칸 — 원본 결재란은 {len(slots)}칸이라 앞에서부터 채움")
    for col, who in zip(slots, line + [""] * len(slots)):
        set_cell_lines(cell(t, 0, col), [who[:-2], who[-2:]] if len(who) > 4 else [who])   # 청년정책 / 팀장
    set_cell_lines(cell(t, 2, 1), [org.get("retention", "")])
    set_cell_lines(cell(t, 5, 1), [org.get("disclosure", "")])


def slogan_bar(ev):
    """머리문구 띠: 「 - 청년 창업가와 함께하는 - 」, 머리문구가 없으면 빈칸(「- -」만 남지 않게)"""
    sl = (ev.get("slogan") or "").strip()
    return f" - {sl} - " if sl else " "


def fill_cover(doc, data, d, res, end):
    ev = data["event"]
    tt = doc.tbl(T_TITLE)
    set_runs(p_with(tt, "위한"), {1: slogan_bar(ev)})
    set_only(p_with(tt, "결과 보고"), f'{ev["title"]} 결과 보고')

    box = owner_p(doc.tbl(T_COVER))   # 핵심 항목은 표 밖 같은 문단 안 글상자에 있음
    ps = list(box.iter(Q("p")))
    hl = [p for p in ps if p.get("paraPrIDRef") == "137"]          # 핵심 항목 4줄
    tmpl = copy.deepcopy(hl[2])
    for h in res.get("highlights") or []:
        np_ = clone(tmpl)
        set_only(np_, f" - {h}")
        hl[0].addprevious(np_)
    for p in hl:
        remove(p)
    note = p_with(box, "(참 고)")
    if res.get("highlight_note"):
        set_only(note, " " + res["highlight_note"])
    else:       # 지우면 한글이 파일을 열다 멈춘다(표지 글상자 끝 문단) → 빈 문단으로 둔다
        set_only(note, "")
    set_runs(p_with(box, "(일    시)"), {3: f'{d["date_text"]} ', 4: f'{ev["start"]} ~ {end}'})
    set_runs(p_with(box, "(장    소)"), {3: ev.get("venue_short") or ev["venue"], 4: ""})
    short_staff = f'※ 배석({d["staff_count"]}명)' if d["staff_count"] else ""     # 표지는 한 줄에 맞게 짧게
    who = d["attendee_text"]
    if len(who) > 30:                     # 표지는 한 줄: 길면 인원만(긴 설명은 본문 (참석대상)에)
        who = ev.get("headcount") or who.split("(")[0]
    set_runs(p_with(box, "(참    석)"), {3: f'{who} ', 4: short_staff})
    summary = res.get("summary") or ev.get("summary", "")
    set_runs(p_with(box, "(주요내용)"), {3: " ", 4: "", 5: "", 6: summary, 7: "", 8: ""})
    sug = res.get("suggestions") or []
    orgs = len({s["org"] for s in sug})
    cnt = sum(1 for s in sug if s.get("title"))
    subj = res.get("opinion_subject") or "기관"
    set_runs(p_with(box, "(의견수렴)"), {3: f" {orgs}개 {subj} 주요의견 ", 4: f"[총 {cnt}건]"})
    set_runs(p_with(box, "(향후계획)"), {3: f' {res.get("next_steps", "")}'})
    dt = doc.tbl(T_DEPT)
    set_only(p_with(dt, "천안시"), data["org"]["city"])
    set_only(p_with(dt, "["), f'[{data["org"]["dept"]}]')


def fill_body_head(doc, data):
    ev = data["event"]
    bt = doc.tbl(T_BODY_TITLE)
    set_only(p_with(bt, "위한"), slogan_bar(ev))
    set_only(p_with(bt, "결과 보고"), f'{ev["title"]} 결과 보고')
    it = doc.tbl(T_INTENT)
    title = ev["title"]
    lead = f'{ev.get("slogan", "")} 「{title}」{josa(title, "을/를")}'.strip()
    set_runs(p_with(it, "「"), {1: lead})


def fill_review(doc, res):
    tops = doc.orig
    head, body = tops[P["review"]], tops[P["review_body"]]
    lines = res.get("mayor_summary") or []
    if not lines:
        remove(head)
        remove(body)
        return
    ps = list(body.iter(Q("p")))[1:]
    item, blank = copy.deepcopy(ps[0]), copy.deepcopy(ps[1])
    parent = ps[0].getparent()
    for p in ps:
        parent.remove(p)
    for k, s in enumerate(lines):
        if k:
            parent.append(clone(blank))
        np_ = clone(item)
        set_only(np_, f"  {s}")
        parent.append(np_)


def fill_overview(doc, data, d, end):
    ev, res = data["event"], data.get("result") or {}
    box = doc.orig[P["overview"]]
    set_runs(p_with(box, "(일    시)"), {2: f'{d["date_text"]} {ev["start"]} ~ {end}'})
    set_runs(p_with(box, "(장    소)"), {3: ev.get("venue_short") or ev["venue"]})
    set_runs(p_with(box, "(참석대상)"), {2: f'{d["attendee_text"]} ', 3: f'※ 배석({d["staff_count"]}명)' if d["staff_count"] else ""})
    label = p_with(box, "(회의내용)")
    ps = list(box.iter(Q("p")))
    i = ps.index(label)
    olds = [p for p in ps[i + 1:] if "".join(p.itertext()).strip()]
    tmpl = copy.deepcopy(olds[0])
    anchor = label
    for c in res.get("contents") or []:
        np_ = clone(tmpl)
        set_only(np_, f"   - {c}")
        anchor.addnext(np_)
        anchor = np_
    for p in olds:
        remove(p)


def fill_suggestions(doc, data, res):
    sug = res.get("suggestions") or []
    t = doc.tbl(T_SUGGEST)
    rows = t.findall("hp:tr", N)
    row_t = rows[1]
    orgs, rows_data = [], []
    for s in sug:
        if s["org"] not in orgs:
            orgs.append(s["org"])
    n = 0
    for o in orgs:
        items = [s for s in sug if s["org"] == o and s.get("title")]
        if not items:
            rows_data.append((o, None))
        for s in items:
            n += 1
            rows_data.append((o, (NUMS[n - 1] if n <= len(NUMS) else f"{n}.", s)))

    def fill(tr, item, i):
        o, v = item
        c = tr_cells(tr)
        for k in (0, 1, 2, 3):
            c[k].find("hp:cellSpan", N).set("rowSpan", "1")
        set_cell_lines(c[0], [str(orgs.index(o) + 1)])
        set_cell_lines(c[1], [o])
        if v is None:
            set_cell_lines(c[2], ["별도 건의사항 없음"])
            set_cell_lines(c[3], ["-"])
            return
        num, s = v
        depts = "".join(f"[{x}]" for x in s.get("depts") or [])
        set_cell_lines(c[2], [f'{num} {s["title"]}'] + ([depts] if depts else []))
        det = s.get("detail") or []
        set_cell_lines(c[3], det if len(det) <= 1 else [f"- {x}" for x in det])
    rebuild_rows(t, 1, None, row_t, None, rows_data, fill)
    merge_same(t, 0, [str(orgs.index(o) + 1) for o, _ in rows_data], 1)
    merge_same(t, 1, [o for o, _ in rows_data], 1)
    renumber(t)
    subj = res.get("opinion_subject") or "기관"
    if subj != "대학":                       # 표 머리 「대학명」 → 「기관명」
        set_cell_lines(tr_cells(rows[0])[1], [f"{subj}명"])
    set_runs(p_with(doc.tbl(T_SUGGEST_HEAD), "의견수렴"), {1: f" {subj}별 의견수렴 내용 [총{n}건]"})


def fill_plan(doc, res):
    tops = doc.orig
    set_runs(p_with(doc.tbl(T_PLAN_HEAD), "Ⅳ"), {0: "Ⅲ"})
    old = tops[P["plan_from"]:P["plan_to"] + 1]
    bullet, note = copy.deepcopy(old[0]), copy.deepcopy(old[2])
    new = []
    for line in res.get("plan_lines") or []:
        if line.startswith("☞"):
            p = clone(note)
            set_only(p, f"    {line}")
        else:
            p = clone(bullet)
            set_only(p, f"   {line}")
        new.append(p)
    if new:
        insert_after(old[-1], new)
    for p in old:
        remove(p)


MIN_HEAD = ["발언자(성명)", "발언내용", "핵심내용", "비고(관련부서)"]
MIN_WIDTHS = [9000, 20060, 11800, 9600]          # 원본 회의록 표 너비(50460) 안에서 나눔


def speakers(data, res):
    """붙임 회의록에 넣을 발언: 참석자 명단에 있는 사람만(시장·공무원·사회자 제외).
    명단과 이름이 하나도 맞지 않으면(「참석자 1」 녹취 등) 기관이 적힌 발언만, 그것도 없으면 전부."""
    ms = res.get("minutes") or []
    people = {a["name"]: a for a in data["attendees"] if a.get("name")}
    ms = [m for m in ms if m.get("name") in people] or [m for m in ms if m.get("org")] or ms
    sug = res.get("suggestions") or []
    out = []
    for m in ms:                  # 핵심내용·관련부서가 없으면 같은 기관의 Ⅱ 건의사항 제목·관련부서로
        a = people.get(m.get("name")) or {}
        orgs = {m.get("org"), a.get("org"), a.get("org_short")} - {None, ""}
        mine = [s for s in sug if s.get("org") in orgs and s.get("title")]
        out.append({**m, "key": m.get("key") or [s["title"] for s in mine],
                    "depts": m.get("depts") or list(dict.fromkeys(d for s in mine for d in s.get("depts") or []))})
    return out


def fill_minutes(doc, data, res, ms):
    t = doc.tbl(T_MINUTES)
    rows = t.findall("hp:tr", N)
    disc = next((p for p in data["program"] if p.get("type") == "discussion"), None)
    title = f'[{data["event"]["title"]} : {(disc.get("desc") or disc["item"]) if disc else "의견 수렴"}]'
    set_only(p_with(doc.orig[P["minutes_from"] + 2], "["), title)

    # 칸 본: 발언자 칸 = 원본 회의록 왼쪽 칸, 글 칸 = 원본 발언 줄(왼쪽 맞춤), 머리 = Ⅱ 의견수렴 표 머리
    who_t = copy.deepcopy(tr_cells(rows[2])[0])
    text_t = copy.deepcopy(tr_cells(rows[3])[1])
    line_t = copy.deepcopy(cell_ps(text_t)[0])
    head_tr = copy.deepcopy(doc.tbl(T_SUGGEST).findall("hp:tr", N)[0])
    head_c = tr_cells(head_tr)
    row_t = copy.deepcopy(rows[2])
    for tc in row_t.findall("hp:tc", N):
        row_t.remove(tc)

    def sized(tc, col, height):
        a, sz = tc.find("hp:cellAddr", N), tc.find("hp:cellSz", N)
        a.set("colAddr", str(col))
        sz.set("width", str(MIN_WIDTHS[col]))
        sz.set("height", str(height))
        tc.find("hp:cellSpan", N).set("rowSpan", "1")
        tc.find("hp:cellSpan", N).set("colSpan", "1")
        return tc

    def text_cell(col, lines, dash):
        tc = sized(copy.deepcopy(text_t), col, 2980)
        sub = tc.find("hp:subList", N)
        for p in cell_ps(tc):
            sub.remove(p)
        for x in lines or [""]:
            x = re.sub(r"^[\s\-–·]+", "", x)
            p = clone(line_t)
            set_only(p, (f" - {x}" if dash else f" {x}") if x else "")
            sub.append(p)
        return tc

    for tr in rows:
        t.remove(tr)
    # 머리 행
    head = copy.deepcopy(head_tr)
    for tc in head.findall("hp:tc", N):
        head.remove(tc)
    for col, label in enumerate(MIN_HEAD):
        tc = sized(copy.deepcopy(head_c[min(col, 3)]), col, 2980)
        set_cell_lines(tc, [label])
        head.append(tc)
    t.append(clone(head))
    # 발언자별 행
    for m in ms:
        tr = copy.deepcopy(row_t)
        who = sized(copy.deepcopy(who_t), 0, 2980)
        set_cell_lines(who, ([m["org"]] if m.get("org") else []) + [f'{m["position"]}({m["name"]})' if m.get("name") else m["position"]])
        tr.append(who)
        tr.append(text_cell(1, m.get("lines"), True))
        tr.append(text_cell(2, m.get("key"), True))
        tr.append(text_cell(3, m.get("depts"), False))
        t.append(clone(tr))
    t.set("colCnt", "4")
    t.set("repeatHeader", "1")
    t.find("hp:sz", N).set("width", str(sum(MIN_WIDTHS)))
    renumber(t)


def fill_roster(doc, data, res):
    city = data["org"]["city"]
    h = data["host"]
    people = [(spaced(city), spaced_pos(short_pos(h["position"], city)), h["name"])]
    people += [(spaced(city), s["position"], s["name"]) for s in data.get("staff_present") or []]
    people += [(spaced(city), s["position"], s["name"]) for s in res.get("present_extra") or []]
    people += [(a["org"], a["position"], a["name"]) for a in data["attendees"]]
    t = doc.tbl(T_ROSTER)
    rows = t.findall("hp:tr", N)
    row_t = copy.deepcopy(rows[8])

    def fill(tr, p, i):
        c = tr_cells(tr)
        set_cell_lines(c[0], [str(i + 1)])
        set_cell_lines(c[1], [p[0]])
        set_cell_lines(c[2], [p[1]])
        set_cell_lines(c[3], [" ".join(p[2])])
        set_cell_lines(c[4], [""])
    rebuild_rows(t, 1, None, row_t, None, people, fill)
    merge_same(t, 1, [p[0] for p in people], 1)
    renumber(t)


def generate(data, out_path):
    d, ev = data["derived"], data["event"]
    res = data.get("result") or {}
    if not res:
        raise BuildError("결과보고는 행사 후 데이터(result)가 있어야 만들 수 있습니다")
    end = res.get("actual_end") or d["end"]
    if res.get("host_name") and data["host"].get("name", "").strip("ㅇ○ ") == "":     # 계획서에 시장 이름이 없을 때: 회의록에서 찾은 이름
        data = {**data, "host": {**data["host"], "name": res["host_name"]}}
    doc = Doc("result.hwpx")
    tops = doc.orig
    if len(tops) != TOPS:
        raise BuildError(f"결과보고 원본 문단 수({len(tops)})가 예상({TOPS})과 다릅니다")
    expect_text(tops[P["review"]], "총평", "시장님 총평")
    expect_text(tops[P["att_from"]], "붙임", "붙임 목록")
    blocks = {"minutes": tops[P["minutes_from"]:P["minutes_to"] + 1],
              "roster": tops[P["roster_from"]:P["roster_to"] + 1],
              "photo": tops[P["photo_from"]:P["photo_to"] + 1]}
    att_lines = tops[P["att_from"]:P["att_to"] + 1]

    fill_approval(doc, data)
    fill_cover(doc, data, d, res, end)
    fill_body_head(doc, data)
    fill_review(doc, res)
    fill_overview(doc, data, d, end)
    fill_suggestions(doc, data, res)
    fill_plan(doc, res)

    # 붙임: 있는 것만, 번호 다시 매김
    photos = res.get("photos") or []
    ms = speakers(data, res)
    use = [("minutes", "회의록", bool(ms)), ("roster", "참석자 명단", True),
           ("photo", "간담회 사진", bool(photos))]
    kept = [(k, name) for k, name, on in use if on]
    heads = {"minutes": T_MINUTES_HEAD, "roster": T_ROSTER_HEAD, "photo": T_PHOTO_HEAD}
    for k, name, on in use:
        if not on:
            for p in blocks[k]:
                remove(p)
    for no, (k, name) in enumerate(kept, 1):
        set_runs(p_with(doc.tbl(heads[k]), "붙임"), {0: f"붙임{no}"})
    if ms:
        fill_minutes(doc, data, res, ms)
    fill_roster(doc, data, res)
    img_map = {}
    if photos:
        pt = doc.tbl(T_PHOTO)
        pics = list(pt.iter(Q("pic")))
        if len(photos) > len(pics):
            doc.warnings.append(f"사진 칸이 {len(pics)}개라 앞의 {len(pics)}장만 넣음")
        for pic, path in zip(pics, photos):
            img = pic.find(".//{http://www.hancom.co.kr/hwpml/2011/core}img")
            img_map[img.get("binaryItemIDRef")] = path
        if len(photos) < len(pics):
            for tr in pt.findall("hp:tr", N)[len(photos):]:
                pt.remove(tr)
            renumber(pt)
    first, other = copy.deepcopy(att_lines[0]), copy.deepcopy(att_lines[1])
    new = []
    for no, (k, name) in enumerate(kept, 1):
        p = clone(first if no == 1 else other)
        end_mark = " 끝. " if no == len(kept) else ""
        set_only(p, (f"붙임 {no}. " if no == 1 else f"     {no}. ") + f"{name} 1부.{end_mark}")
        new.append(p)
    insert_after(att_lines[-1], new)
    for p in att_lines:
        remove(p)
    return doc.save(out_path, f'{ev["title"]} 결과보고', img_map, keep_layout=True)
