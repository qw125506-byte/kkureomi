# -*- coding: utf-8 -*-
"""⑥ 결과보고 — templates/result.hwpx(사용자 견본 「(견본) 결과보고」)를 복제해 내용만 바꾼다.

견본 구성(15쪽): 결재란 / 요약 표지(핵심 항목·일시·장소·참석·주요내용·의견수렴·향후계획) / 본문 제목·보고 문장 /
Ⅰ 총평(시장님) / Ⅱ 간담회 개요 / Ⅲ 기관별 의견수렴 내용 표 / Ⅳ 향후계획 표 / 붙임 1 회의록 / 붙임 2 참석자 명단 / 붙임 3 사진.
- 의견수렴 표: 계획서 참석자는 한 명도 빼지 않는다(건의가 없으면 「별도 건의사항 없음」 줄로 남긴다).
- 표지·본문 일시는 실제 종료 시각(result.actual_end, 없으면 계획 종료)을 쓴다.
- 페이지 2의 총평·개요 글상자는 쪽 위 고정 위치라 줄 수가 견본(총평 5줄 안팎)을 넘지 않게 줄여 넣는다.
"""
import copy
import math
import re

from core import calc
from core.hwpx import (set_value, Doc, BuildError, N, Q, bp, cell, cell_ps, clone, expect_text, find_tbl, insert_after, josa,
                       owner_p, p_with, rebuild_rows, remove, renumber, set_cell_lines, set_only, set_runs, spaced,
                       tr_cells)
from generators.hwpx.brief import fit

T_APPROVAL = "2113655862"
T_COVER_TITLE = "1212474946"
T_COVER_BOX = "2113655868"
T_DEPT = "2113655880"
T_BODY_TITLE = "1212474948"
T_INTENT = "2113655899"
T_SUGGEST_HEAD = "1212474973"
T_SUGGEST = "1170865051"
T_PLAN = "1212474982"
T_MINUTES_HEAD = "1212474977"
T_MINUTES = "1170865071"
T_ROSTER_HEAD = "1212474979"
T_ROSTER = "1171806919"
T_PHOTO_HEAD = "1212474981"
P = dict(review=19, overview=25, suggest=30, suggest_extra=(31, 32), att_from=40, att_to=42, minutes_title=46, photo_head=53)
TOPS = 55
REVIEW_SLOTS = 13          # 총평 글상자(쪽 위 고정)에 들어가는 줄 수(견본: 5줄 + 사이 빈 줄)
CHARS_PER_LINE = 33


def short_pos(position, city):
    """천안시장 → 시장 (명단의 기관 칸에 시 이름이 있으므로)"""
    stem = city[:-1] if city.endswith("시") else city
    return position[len(stem):] if position.startswith(stem) and len(position) > len(stem) else position


def spaced_pos(pos):
    """원본 표기: 시   장, 총   장 (짧은 직위만 띄움)"""
    return ("  " if len(pos) == 3 else "   ").join(pos) if len(pos) <= 3 else pos


def fill_approval(doc, data):
    org, t = data["org"], doc.tbl(T_APPROVAL)
    set_cell_lines(cell(t, 0, 1), [f'{org["dept"]}    - '])
    line = org.get("approval_line") or []
    slots = [3, 4, 5, 6, 8, 9]
    if len(line) != len(slots):
        doc.warnings.append(f"결재선 {len(line)}칸 — 원본 결재란은 {len(slots)}칸이라 앞에서부터 채움")
    for col, who in zip(slots, line + [""] * len(slots)):
        set_cell_lines(cell(t, 0, col), [who[:-2], who[-2:]] if len(who) > 4 else [who])   # 청년정책 / 팀장
    set_cell_lines(cell(t, 2, 1), [org.get("retention", "")])
    set_cell_lines(cell(t, 5, 1), [org.get("disclosure", "")])


def cover_title(tbl, text):
    tc = cell(tbl, 1, 0)
    p = cell_ps(tc)[0]
    set_only(p, text)
    fit(p, bp.cell_avail(tc), ratio=0.97, squeeze=8)


def fill_cover(doc, data, d, res, end):
    ev = data["event"]
    cover_title(doc.tbl(T_COVER_TITLE), f'{ev["title"]} 결과 보고')
    box = owner_p(doc.tbl(T_COVER_BOX))
    ps = list(box.iter(Q("p")))
    hl = [p for p in ps if p.get("paraPrIDRef") == "102"]            # 핵심 항목 4줄(작은 글상자 안)
    items = (res.get("highlights") or [])[:4]
    if items and hl:
        tmpl = copy.deepcopy(hl[-1])
        for h in items:
            np_ = clone(tmpl)
            set_only(np_, f" - {h}")
            hl[0].addprevious(np_)
        for p in hl:
            remove(p)
    set_runs(p_with(box, "(일    시)"), {3: f'{d["date_text"]} ', 4: f'{ev["start"]} ~ {end}'})
    set_runs(p_with(box, "(장    소)"), {3: ev.get("venue_short") or ev["venue"], 4: ""})
    from generators.hwpx.plan import cover_attend
    who = cover_attend(d["attendee_text"])
    if len(who) > 30:                     # 표지는 한 줄: 길면 인원만(긴 설명은 본문 (참석대상)에)
        who = ev.get("headcount") or who.split("(")[0]
    short_staff = f'※ 배석({d["staff_count"]}명)' if d["staff_count"] else ""
    set_runs(p_with(box, "(참    석)"), {3: f'{who} ', 4: short_staff})
    summary = res.get("summary") or ev.get("summary", "")
    set_runs(p_with(box, "(주요내용)"), {3: " ", 4: summary, 5: "", 6: "", 7: "", 8: ""})
    sug = res.get("suggestions") or []
    people = len({a["name"] for a in data["attendees"] if a.get("name")}) or len({s["org"] for s in sug})
    cnt = sum(1 for s in sug if s.get("title"))
    subj = res.get("opinion_subject") or "기관"
    set_runs(p_with(box, "(의견수렴)"), {2: f"(의견수렴) {people}개 {subj} 주요의견 " if subj != "기관" else f"(의견수렴) 참석자 {people}명 주요의견 ",
                                        3: f"[총 {cnt}건]"})
    set_runs(p_with(box, "(향후계획)"), {4: res.get("next_steps", "")})
    dt = doc.tbl(T_DEPT)
    set_only(p_with(dt, "천안시"), data["org"]["city"])
    set_only(p_with(dt, "["), f'[{data["org"]["dept"]}]')


def fill_body_head(doc, data):
    ev = data["event"]
    cover_title(doc.tbl(T_BODY_TITLE), f'{ev["title"]} 결과 보고')
    title = ev["title"]
    lead = f'{ev.get("slogan", "")} 「{title}」{josa(title, "을/를")}'.strip()
    p = p_with(doc.tbl(T_INTENT), "「")
    set_runs(p, {1: lead})


def est_lines(s):
    return max(1, math.ceil(len(s) / CHARS_PER_LINE))


def fit_review(lines):
    """총평 줄 수를 글상자(쪽 위 고정)에 맞게: 뒤에서부터 줄이고, 그래도 넘치면 빈 줄을 뺀다"""
    lines = list(lines)
    total = lambda: sum(est_lines(x) for x in lines)                    # noqa: E731
    if len(lines) > 3 and total() > REVIEW_SLOTS:                      # 맺음 인사 → 첫머리 인사 순으로 뺀다
        for k in (len(lines) - 1, 0):
            if len(lines) > 3 and total() > REVIEW_SLOTS:
                lines.pop(k)
    while len(lines) > 3 and total() > REVIEW_SLOTS:
        lines.pop()
    return lines


def fill_review(doc, res):
    top = doc.orig[P["review"]]
    lines = fit_review(res.get("mayor_summary") or [])
    if not lines:
        remove(top)
        return
    ps = [p for p in top.iter(Q("p")) if p.get("paraPrIDRef") == "109"]
    item, blank = copy.deepcopy(ps[0]), copy.deepcopy(ps[1])
    parent = ps[0].getparent()
    for p in ps:
        parent.remove(p)
    tight = sum(est_lines(x) for x in lines) + (len(lines) - 1) > REVIEW_SLOTS
    for k, s in enumerate(lines):
        if k and not tight:
            parent.append(clone(blank))
        np_ = clone(item)
        set_value(np_, s)                                              # 앞의 글머리 기호는 그대로
        parent.append(np_)


def fill_overview(doc, data, d, end):
    ev, res = data["event"], data.get("result") or {}
    box = doc.orig[P["overview"]]
    set_runs(p_with(box, "(일    시)"), {2: f'{d["date_text"]} {ev["start"]} ~ {end}'})
    set_runs(p_with(box, "(장    소)"), {3: ev.get("venue_short") or ev["venue"]})
    from generators.hwpx.plan import cover_attend
    set_runs(p_with(box, "(참석대상)"), {2: f'{cover_attend(d["attendee_text"])} ', 3: f'※ 배석({d["staff_count"]}명)' if d["staff_count"] else ""})
    label = p_with(box, "(회의내용)")
    ps = list(box.iter(Q("p")))
    i = ps.index(label)
    olds = [p for p in ps[i + 1:] if "".join(p.itertext()).strip()]
    tmpl = copy.deepcopy(olds[0])
    anchor = label
    for c in (res.get("contents") or [])[:4]:
        np_ = clone(tmpl)
        set_only(np_, f"   - {c}")
        anchor.addnext(np_)
        anchor = np_
    for p in olds:
        remove(p)


def suggestion_rows(res, data):
    """의견수렴 표 줄: (기관 줄들, 건의 제목 줄들, 세부 줄들, 부서 줄들) — 계획서 참석자는 한 명도 빼지 않는다"""
    rows, covered = [], set()
    for s in res.get("suggestions") or []:
        orgs = s["org"].split("·") if s.get("title") else [s["org"]]
        covered.update(orgs)
        if not s.get("title"):
            rows.append((orgs, ["별도 건의사항 없음"], ["-"], [""]))
            continue
        det = s.get("detail") or []
        rows.append((orgs, [s["title"]], det if det else [""], s.get("depts") or [""]))
    return rows


def est_row_height(item):
    """줄 수로 어림한 행 높이(HWPUNIT). 세부 내용 칸 한 줄 24자, 제목 칸 11자, 기관 칸 6자 안팎"""
    orgs, title, det, depts = item
    lines = max(sum(math.ceil(len(x) / 24) for x in det) if det else 1,
                sum(math.ceil(len(x) / 11) for x in title),
                sum(math.ceil(len(x) / 6) for x in orgs),
                len(depts))
    return lines * 1800 + 1500


PAGE_ROWS_H = 66000       # 표 한 쪽에 넣는 행 높이 합(머리 줄·쪽 여백 빼고)
FIRST_ROWS_H = 58000      # 첫 쪽은 「Ⅲ 의견수렴」 제목 줄이 있어 조금 적게


def chunk_rows(rows):
    chunks, cur, h = [], [], 0
    for r in rows:
        rh = est_row_height(r)
        if cur and h + rh > (PAGE_ROWS_H if chunks else FIRST_ROWS_H):
            chunks.append(cur)
            cur, h = [], 0
        cur.append(r)
        h += rh
    return chunks + ([cur] if cur else [])


def fill_suggestions(doc, data, res):
    first = doc.tbl(T_SUGGEST)
    cont_p = doc.orig[P["suggest_extra"][1]]                         # 견본의 둘째 표 문단: 이어지는 쪽의 표 본
    rows = suggestion_rows(res, data)
    n = sum(1 for s in res.get("suggestions") or [] if s.get("title"))
    chunks = chunk_rows(rows) or [[]]
    subj = res.get("opinion_subject") or "기관"
    widths = [3700, 6600, 11200, 21837, 7400]                       # 세부 내용 칸을 넓혀 줄 수를 줄임(전체 폭 50737 그대로)
    protos = copy.deepcopy(first.findall("hp:tr", N)[1])
    counter = [0]

    def build(tbl, part):
        trs = tbl.findall("hp:tr", N)

        def fill(tr, item, i):
            orgs, title, det, depts = item
            c = tr_cells(tr)
            counter[0] += 1
            set_cell_lines(c[0], [str(counter[0])])
            set_cell_lines(c[1], orgs)
            set_cell_lines(c[2], title)
            set_cell_lines(c[3], det)
            set_cell_lines(c[4], depts)
            for tc in tr.findall("hp:tc", N):
                tc.find("hp:cellSz", N).set("height", "3546")
        row_t = copy.deepcopy(protos)
        rebuild_rows(tbl, 1, row_t, row_t, row_t, part, fill)
        renumber(tbl)
        for tr in tbl.findall("hp:tr", N):
            for tc in tr.findall("hp:tc", N):
                tc.find("hp:cellSz", N).set("width", str(widths[int(tc.find("hp:cellAddr", N).get("colAddr"))]))
        set_cell_lines(tr_cells(tbl.findall("hp:tr", N)[0])[1], [f"{subj}명"])
    build(first, chunks[0])
    prev = doc.orig[P["suggest"]]
    for part in chunks[1:]:
        np_ = clone(cont_p)
        np_.set("pageBreak", "1")
        tbl = np_.find(".//hp:tbl", N)
        build(tbl, part)
        insert_after(prev, [np_])
        prev = np_
    remove(doc.orig[P["suggest_extra"][0]])                         # 견본의 사이 빈 줄·둘째 표 문단(본)은 지움
    remove(cont_p)
    set_only(p_with(doc.tbl(T_SUGGEST_HEAD), "의견수렴"), f"{subj}별 의견수렴 내용 [총{n}건]")


def fill_plan(doc, data, res):
    t = doc.tbl(T_PLAN)
    trs = t.findall("hp:tr", N)
    fu = data.get("follow_up") or []
    items = [(f["task"], _due(f.get("due"))) for f in fu] or [(x, "") for x in res.get("plan_lines") or []]
    if not items:
        items = [("소관 부서 검토 후 결과 안내", "")]

    def fill(tr, it, i):
        c = tr_cells(tr)
        set_cell_lines(c[0], [str(i + 1)])
        set_cell_lines(c[1], [re.sub(r"\s+", " ", it[0])])
        set_cell_lines(c[2], [it[1]])
    rebuild_rows(t, 1, trs[1], trs[2], trs[-1], items, fill)
    renumber(t)


def _due(due):
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})$", due or "")
    return f"~ {int(m.group(2))}. {int(m.group(3))}." if m else re.sub(r"\s+", "", due or "")


def fill_minutes(doc, data, ms):
    t = doc.tbl(T_MINUTES)
    rows = t.findall("hp:tr", N)
    row_t = copy.deepcopy(rows[1])
    ps = cell_ps(tr_cells(row_t)[1])
    sub = tr_cells(row_t)[1].find("hp:subList", N)
    for p in ps[1:]:                                               # 글 칸은 「- 발언」 한 문단 본만 남김
        sub.remove(p)
    disc = next((p for p in data["program"] if p.get("type") == "discussion"), None)
    title = f'[{data["event"]["title"]} : {(disc.get("desc") or disc["item"]) if disc else "의견 수렴"}]'
    set_only(doc.orig[P["minutes_title"]], title)

    def fill(tr, m, i):
        c = tr_cells(tr)
        who = ([m["org"]] if m.get("org") else []) + [spaced_pos(m["position"]) if len(m["position"]) <= 3 else m["position"]]
        if m.get("name"):
            who.append(f'({spaced(m["name"])})')
        set_cell_lines(c[0], who)
        set_cell_lines(c[1], [f"- {re.sub(r'^[\s\-–·]+', '', x)}" for x in (m.get("lines") or [""])])
        for tc in tr.findall("hp:tc", N):
            tc.find("hp:cellSz", N).set("height", "3546")
    rebuild_rows(t, 0, row_t, row_t, row_t, ms, fill)
    renumber(t)


def fill_roster(doc, data, res):
    city = data["org"]["city"]
    h = data["host"]
    people = [(spaced(city), spaced_pos(short_pos(h["position"], city)), h["name"])]
    people += [(spaced(city), s["position"], s["name"]) for s in data.get("staff_present") or []]
    people += [(spaced(city), s["position"], s["name"]) for s in res.get("present_extra") or []]
    people += [(a["org"], a["position"], a["name"]) for a in data["attendees"]]
    t = doc.tbl(T_ROSTER)
    rows = t.findall("hp:tr", N)
    row_t = copy.deepcopy(rows[8])

    def fill(tr, p, i):
        c = tr_cells(tr)
        set_cell_lines(c[0], [str(i + 1)])
        set_cell_lines(c[1], [p[0]])
        set_cell_lines(c[2], [p[1]])
        set_cell_lines(c[3], [" ".join(p[2])])
        set_cell_lines(c[4], [""])
    rebuild_rows(t, 1, None, row_t, None, people, fill)
    from core.hwpx import merge_same
    merge_same(t, 1, [p[0] for p in people], 1)
    renumber(t)


def generate(data, out_path):
    d, ev = data["derived"], data["event"]
    res = data.get("result") or {}
    if not res:
        raise BuildError("결과보고는 행사 후 데이터(result)가 있어야 만들 수 있습니다")
    end = res.get("actual_end") or d["end"]
    if res.get("host_name") and data["host"].get("name", "").strip("ㅇ○ ") == "":     # 계획서에 시장 이름이 없을 때: 회의록에서 찾은 이름
        data = {**data, "host": {**data["host"], "name": res["host_name"]}}
    doc = Doc("result.hwpx")
    tops = doc.orig
    if len(tops) != TOPS:
        raise BuildError(f"결과보고 원본 문단 수({len(tops)})가 예상({TOPS})과 다릅니다")
    expect_text(tops[P["att_from"]], "붙임", "붙임 목록")

    fill_approval(doc, data)
    fill_cover(doc, data, d, res, end)
    fill_body_head(doc, data)
    fill_review(doc, res)
    fill_overview(doc, data, d, end)
    fill_suggestions(doc, data, res)
    fill_plan(doc, data, res)
    ms = res.get("minutes") or []
    if not ms:
        doc.warnings.append("회의록 발언이 없어 붙임 1 회의록 표를 견본 그대로 둠 — 확인 필요")
    else:
        fill_minutes(doc, data, ms)
    fill_roster(doc, data, res)
    tops[P["photo_head"]].set("pageBreak", "1")                     # 붙임 3 사진은 늘 새 쪽(견본)
    return doc.save(out_path, f'{ev["title"]} 결과보고', {}, keep_layout=True)
