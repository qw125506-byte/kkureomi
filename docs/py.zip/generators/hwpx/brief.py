# -*- coding: utf-8 -*-
"""② 보고요지 — templates/brief.hwpx(사용자 견본 「(견본) 요지」)를 복제해 내용만 바꾼다.

견본 구성(4쪽): 담당 라인 / 표지(로고·제목 표·시장님 하실 일·개요 상자·부서) /
본문(제목 표·개요·행사흐름 표) / 참석자 명단(소속·성명·비고(직위) ×2) / 메모 쪽.
"""
import math

from core import calc
from core.hwpx import (Doc, BuildError, N, Q, bp, cell, cell_ps, expect_text, rebuild_rows, remove,
                       set_cell_lines, set_only, set_runs, tr_cells)
from generators.hwpx.plan import lead_lines, org_lines

T_STAFF = "1330516321"      # 담당 라인(과장·팀장·담당자)
T_COVER_TITLE = "1212474899"
T_BODY_TITLE = "1212474905"
T_FLOW = "1109685857"
T_ROSTER = "1212474908"
R_BOX = "2042525792"        # 표지 개요 상자(도형)
R_TASKS = "2065959607"      # 표지 「시장님 하실 일」 띠(도형)
BOX_RATIO = 0.84            # 상자 안 글꼴은 어림값보다 넓다(견본 줄 길이로 맞춘 값)
MIN_SCALE = 0.8             # 자간으로 못 맞추면 글자 크기를 이만큼까지 줄인다
P = dict(box=8, dept=13, date=20, place=21, attend=22, staff=23, summary=24,
         roster_head=29, roster=31, memo=32)
TOPS = 36
CELL_PAD = 250               # 명단 칸 좌우 여백(원본 510)
ROSTER_ROWS = 5             # 견본 명단 한 쪽 행 수(2명씩)


def split_label(label):
    """「시장님, 관내 12개 대학 총장」 → ("(시장님", ", 관내 12개 대학 총장)") — 견본처럼 앞 무리만 굵게"""
    if not label:
        return "", ""
    head, sep, rest = label.partition(",")
    return f"({head.strip()}", (f", {rest.strip()})" if sep else ")")


def fit(p, avail, ratio=None, squeeze=None, min_scale=MIN_SCALE):
    """한 줄에 들어가게: 자간을 줄여 보고(fit_line), 그래도 넘치면 자간을 줄인 채 글자 크기도 조금 줄인다
    (견본 「교육대학교」처럼). 그래도 안 되면 그대로 둔다(줄바꿈)."""
    if bp.fit_line(p, avail, ratio=ratio, squeeze=squeeze):
        return True
    runs = [r for r in p.findall("hp:run", N) if "".join(bp.t_text(t) for t in r.findall("hp:t", N))]
    before = [r.get("charPrIDRef") for r in runs]
    sq = squeeze or bp.MAX_SQUEEZE
    for r, c in zip(runs, before):
        sp = bp._cp_metrics(c)[2]
        r.set("charPrIDRef", bp.charpr_variant(c, spacing=max(bp.FIT_MIN_SPACING, sp - sq)))
    w = bp.line_width(p)
    target = (avail - bp._para_margin(p)) * (ratio or bp.FIT_TARGET)
    scale = min(1, round(target / w - 0.005, 2)) if w else 1
    if scale < min_scale:
        for r, c in zip(runs, before):
            r.set("charPrIDRef", c)
        return False
    for r, c in zip(runs, before):
        sp = bp._cp_metrics(c)[2]
        r.set("charPrIDRef", bp.charpr_variant(c, spacing=max(bp.FIT_MIN_SPACING, sp - sq), scale=scale))
    return True


def fit_cell(tc, min_scale=MIN_SCALE):
    for p in cell_ps(tc):
        if bp.p_text(p).strip():
            fit(p, bp.cell_avail(tc), ratio=bp.CELL_TARGET, squeeze=bp.CELL_SQUEEZE, min_scale=min_scale)


def fit_attend(p, runs_at, avail, label, ratio=None):
    """참석 줄이 한 줄에 들어가게: 조금 좁혀 보고, 그래도 넘치면 괄호 안을 줄인다(인원은 그대로)."""
    a, b = runs_at
    head, tail = split_label(label)
    set_runs(p, {a: head, b: tail})
    if label and not bp.fit_line(p, avail, ratio=ratio, squeeze=6):
        head, tail = split_label(bp.short_detail(label))
        set_runs(p, {a: head, b: tail})
        fit(p, avail, ratio=ratio)


def rect_avail(doc, rid):
    rect = doc.sec.xpath(".//hp:rect[@id='%s']" % rid, namespaces=N)[0]
    return int(rect.find("hp:sz", N).get("width", "0")) - 566       # 글상자 안쪽 여백(양쪽 283)


def pos_lines(pos):
    """직위: 두 글자는 띄어 쓰고(총 장), 나머지는 한 줄 그대로"""
    pos = (pos or "").strip()
    return [" ".join(pos)] if len(pos) == 2 else [pos]


def fill_staff(doc, data):
    staff = data["org"].get("staff") or []
    tbl = doc.tbl(T_STAFF)
    rows = tbl.findall("hp:tr", N)
    if not staff:
        doc.warnings.append("담당 라인(org.staff)이 없어 비워 둠")
        staff = [{"role": "", "name": ""}]

    def fill(tr, s, i):
        c = tr_cells(tr)
        set_cell_lines(c[0], [s["role"]])
        set_cell_lines(c[1], [f'{s["name"]}({s["tel"]})' if s.get("tel") else s["name"]])
    rebuild_rows(tbl, 0, rows[0], rows[1], rows[-1], staff, fill)


def set_title(tbl, title):
    p = cell_ps(cell(tbl, 1, 0))[0]
    set_only(p, title)
    bp.fit_line(p, bp.cell_avail(cell(tbl, 1, 0)), ratio=bp.CELL_TARGET, squeeze=bp.CELL_SQUEEZE)


def fill_cover(doc, data, d):
    ev, tops = data["event"], doc.orig
    set_title(doc.tbl(T_COVER_TITLE), ev["title"])
    box = list(tops[P["box"]].iter(Q("p")))
    tasks, when, place, attend, staff, summary = box[1:7]
    avail, R = rect_avail(doc, R_BOX), BOX_RATIO
    if d["mayor_tasks"]:
        set_runs(tasks, {3: f' 하실 일 : {d["mayor_tasks"]}'}, expect={2: "시장님"})
        fit(tasks, rect_avail(doc, R_TASKS), ratio=1.0, min_scale=0.7)   # 띠는 한 줄 높이라 꼭 한 줄로
    else:
        remove(tasks)
    set_runs(when, {4: f'  {d["date_text"]} ', 5: f'{ev["start"]} ~ {d["end"]} ({calc.fmt_duration(d["total_minutes"])})'},
             expect={3: "(일"})
    fit(when, avail, ratio=R)
    set_runs(place, {4: f' {ev["venue"]}'}, expect={3: "(장"})
    fit(place, avail, ratio=R)
    set_runs(attend, {6: f' {d["headcount_text"]}'}, expect={5: "석)"})
    fit_attend(attend, (8, 9), avail, ev.get("attendee_label"), ratio=R)
    if d["staff_text"]:
        set_runs(staff, {3: d["staff_text"].removeprefix("※ ")}, expect={2: "※"})
        fit(staff, avail, ratio=R)
    else:
        remove(staff)
    set_runs(summary, {4: ev.get("summary", "")}, expect={3: "(내"})
    fit(summary, avail, ratio=R)
    set_runs(tops[P["dept"]], {0: f'({data["org"]["dept"]})'}, expect={0: "("})


def fill_overview(doc, data, d):
    ev, tops = data["event"], doc.orig
    set_title(doc.tbl(T_BODY_TITLE), ev["title"])
    avail = bp.body_avail(doc.sec)
    set_runs(tops[P["date"]], {3: f' {d["date_text"]} ', 4: f'{ev["start"]} ~ {d["end"]} ({calc.fmt_duration(d["total_minutes"])})'},
             expect={2: "(일"})
    fit(tops[P["date"]], avail)
    set_runs(tops[P["place"]], {2: ev["venue"]}, expect={1: "(장"})
    fit(tops[P["place"]], avail)
    set_runs(tops[P["attend"]], {2: d["headcount_text"]}, expect={1: "(참"})
    fit_attend(tops[P["attend"]], (4, 5), avail, ev.get("attendee_label"))
    if d["staff_text"]:
        set_runs(tops[P["staff"]], {0: "      " + d["staff_text"]}, expect={0: "※"})
        fit(tops[P["staff"]], avail)
    else:
        remove(tops[P["staff"]])
    set_runs(tops[P["summary"]], {3: ev.get("summary", "")}, expect={2: "(내"})
    fit(tops[P["summary"]], avail)


def fill_flow(doc, d):
    tbl = doc.tbl(T_FLOW)
    rows = tbl.findall("hp:tr", N)

    def fill(tr, r, i):
        c = tr_cells(tr)
        set_cell_lines(c[0], [f'{r["start"]}~{r["end"]}'])
        set_cell_lines(c[1], [calc.fmt_minutes(r["minutes"])])
        set_cell_lines(c[2], [f'▪ {r["item"]}'])
        lead = lead_lines(r["lead"])
        set_cell_lines(c[3], lead if isinstance(lead, list) else [lead])
    rebuild_rows(tbl, 1, rows[1], rows[2], rows[-1], d["program"], fill)


def fill_roster(doc, data):
    """참석자 명단: 한 행에 2명(왼쪽 앞 절반, 오른쪽 뒤 절반), 칸은 모두 가운데 정렬(견본)."""
    people = data["attendees"]
    tops = doc.orig
    if not people:                      # 명단이 없으면 명단 쪽을 빼고 메모 쪽이 새 쪽에서 시작
        for k in range(P["roster_head"], P["roster"] + 1):
            remove(tops[k])
        return
    tbl = doc.tbl(T_ROSTER)
    rows = tbl.findall("hp:tr", N)
    half = math.ceil(len(people) / 2)
    pairs = [(people[r], people[half + r] if half + r < len(people) else None) for r in range(half)]
    lines = [(org_lines_one(p["org"]), [p["name"]], pos_lines(p.get("position"))) for p in people]
    set_roster_widths(tbl, [max(text_w(x, 0.93 if i == 0 else 1.05) for ls in col for x in ls) for i, col in enumerate(zip(*lines))])

    def fill(tr, pair, i):
        c = tr_cells(tr)
        for side, p in zip((0, 3), pair):
            for k, ls in enumerate((org_lines_one(p["org"]), [p["name"]], pos_lines(p.get("position"))) if p else ([""],) * 3):
                set_cell_lines(c[side + k], ls)
                for q in cell_ps(c[side + k]):
                    if k == 1:                                  # 성명: 왼쪽 여백(1000)을 없애 칸 가운데에 놓는다
                        q.set("paraPrIDRef", bp.parapr_variant(q.get("paraPrIDRef"), left=0))
                    elif len(ls) == 1:                          # 한 줄 칸은 가운데 모음(균등 분할로 벌어지지 않게)
                        q.set("paraPrIDRef", bp.parapr_variant(q.get("paraPrIDRef"), align="CENTER"))
                fit_cell(c[side + k], min_scale=0.7)
    for tc in tr_cells(rows[0]).values():                       # 머리글도 칸 폭에 한 줄로(안 되면 낱말 사이 띄움을 줄임)
        for q in cell_ps(tc):
            if not fit(q, bp.cell_avail(tc), ratio=0.85, squeeze=bp.CELL_SQUEEZE):
                set_only(q, " ".join(bp.p_text(q).split()))
                fit(q, bp.cell_avail(tc), ratio=0.85, squeeze=bp.CELL_SQUEEZE)
    rebuild_rows(tbl, 1, rows[1], rows[2], rows[-1], pairs, fill)
    body = tbl.findall("hp:tr", N)[1:]
    # 견본은 한 쪽에 5행이 꽉 찬다 — 행 수에 맞춰 행 높이를 늘리거나 줄여 표가 쪽을 채우게 한다
    k = min(ROSTER_ROWS / len(body), 2.5)
    for tr in body:
        for tc in tr.findall("hp:tc", N):
            sz = tc.find("hp:cellSz", N)
            sz.set("height", str(int(int(sz.get("height")) * k)))
    sz = tbl.find("hp:sz", N)
    sz.set("height", str(sum(int(tr.find("hp:tc/hp:cellSz", N).get("height")) for tr in tbl.findall("hp:tr", N))))


def org_lines_one(org):
    """소속은 한 줄(대학·대학교는 견본처럼 두 줄: 상명 / 대 학 교)"""
    ls = org_lines(org, width=99)
    return ls if isinstance(ls, list) else [ls]


def text_w(s, k=0.93):
    return sum(bp.char_w(ch) for ch in s) * 1200 * k            # 12pt, 자간을 조금 줄인 폭(성명·직위는 줄이지 않음)


def set_roster_widths(tbl, need):
    """소속·성명·직위 세 열의 폭을 내용 길이에 맞춘다(한 줄로 들어가게). 표 전체 폭은 그대로, 좌우 두 묶음은 같게."""
    total = int(tbl.find("hp:sz", N).get("width"))
    side = total // 2
    pad = 2 * CELL_PAD + 100                                     # 칸 좌우 여백 + 여유
    floor = [4000, 4400, 4900]                                   # 성명·비고(직위) 머리글이 들어갈 최소 폭
    want = [max(f, n + pad) for f, n in zip(floor, need)]
    if sum(want) > side:                                         # 모자라면 소속 칸만 줄임(자간·크기 맞춤이 받아 줌) — 성명·직위는 그대로
        want[0] = max(side - want[1] - want[2], 5000)
        want[2] = side - want[0] - want[1]
    else:                                                        # 남으면 소속 칸이 가져감
        want[0] += side - sum(want)
    want = [int(w) for w in want]
    want[0] += side - sum(want)
    im = tbl.find("hp:inMargin", N)                              # 표 기본 칸 여백(칸 여백을 따로 안 쓰는 칸은 이것을 씀)
    im.set("left", str(CELL_PAD))
    im.set("right", str(CELL_PAD))
    for tr in tbl.findall("hp:tr", N):
        for tc in tr.findall("hp:tc", N):
            cm = tc.find("hp:cellMargin", N)                     # 칸 좌우 여백을 줄여 글 자리를 넓힌다
            cm.set("left", str(CELL_PAD))
            cm.set("right", str(CELL_PAD))
            col = int(tc.find("hp:cellAddr", N).get("colAddr"))
            tc.find("hp:cellSz", N).set("width", str(want[col % 3] + (total - 2 * side if col >= 3 and col % 3 == 0 else 0)))


def generate(data, out_path):
    d = data["derived"]
    doc = Doc("brief.hwpx")
    if len(doc.orig) != TOPS:
        raise BuildError(f"보고요지 원본 문단 수({len(doc.orig)})가 예상({TOPS})과 다릅니다")
    expect_text(doc.orig[P["roster_head"]], "명단", "참석자 명단 제목")
    expect_text(doc.orig[P["memo"]], "메", "메모 쪽 제목")
    fill_staff(doc, data)
    fill_cover(doc, data, d)
    fill_overview(doc, data, d)
    fill_flow(doc, d)
    fill_roster(doc, data)
    doc.orig[P["memo"]].set("pageBreak", "1")    # 메모는 늘 새 쪽(견본 4쪽)
    return doc.save(out_path, f'{data["event"]["title"]} 요지', keep_layout=True)
