# -*- coding: utf-8 -*-
"""② 보고요지 — templates/brief.hwpx(2026 대학 총장과의 간담회 요지)를 복제해 내용만 바꾼다.

원본 구성: 담당 라인 / 표지(제목·시장님 하실 일·개요 상자·부서) / 본문(제목·개요·행사흐름 표) /
참석자 현황 표(사진) / (참고) 자료 3쪽. 참고 자료는 행사마다 달라 공통 데이터에 없으므로 뺀다.
"""
import math

from core import calc
from core.hwpx import (Doc, BuildError, N, Q, cell, cell_ps, clone, expect_text, plain_twin, bf_image,
                       rebuild_rows, remove, renumber, set_cell_lines, set_only, set_runs, tr_cells)

T_STAFF = "1330516321"      # 담당 라인(과장·팀장·담당자)
T_COVER_TITLE = "1736115372"
T_BODY_TITLE = "1109685855"
T_FLOW = "1109685857"
T_ROSTER = "1112986373"
P = dict(cover_box=10, dept=17, date=30, place=31, attend=32, staff=33, summary=34,
         roster_head=39, ref_from=41, ref_to=47)
TOPS = 48
ORIGINAL_SLOGAN = "지역&대학의 상생발전을 위한"   # 원본 머리문구 그림(붓글씨)·Univ City 로고의 내용


def set_title_cell(tbl):
    """제목 칸: 1문단 = 빈 여백 줄, 2문단 = 제목 줄"""
    return cell_ps(cell(tbl, 1, 0))[1]


def _label_tail(label):
    """'시장님, 관내 12개 대학 총장' → '관내 12개 대학 총장'"""
    return label.split(",")[-1].strip() if label else ""


def fill_staff(doc, data):
    staff = data["org"].get("staff") or []
    tbl = doc.tbl(T_STAFF)
    rows = tbl.findall("hp:tr", N)
    if not staff:
        doc.warnings.append("담당 라인(org.staff)이 없어 비워 둠")
        staff = [{"role": "", "name": ""}]

    def fill(tr, s, i):
        c = tr_cells(tr)
        set_cell_lines(c[0], [s["role"]])
        set_cell_lines(c[1], [f'{s["name"]}({s["tel"]})' if s.get("tel") else s["name"]])
    rebuild_rows(tbl, 0, rows[0], rows[1], rows[-1], staff, fill)


def fill_cover(doc, data, d):
    ev, tops = data["event"], doc.orig
    set_only(set_title_cell(doc.tbl(T_COVER_TITLE)), ev["title"])
    box = list(tops[P["cover_box"]].iter(Q("p")))
    tasks, when, place, attend, staff, summary = box[1], box[2], box[3], box[4], box[5], box[6]
    if d["mayor_tasks"]:
        set_runs(tasks, {3: f' 하실 일 : {d["mayor_tasks"]}'}, expect={2: "시장님"})
    else:
        remove(tasks)
    set_runs(when, {4: f'  {d["date_text"]} ', 5: f'{ev["start"]} ~ {d["end"]} ({calc.fmt_duration(d["total_minutes"])})'},
             expect={3: "(일"})
    set_runs(place, {4: f' {ev["venue"]}'}, expect={3: "(장"})
    label = ev.get("attendee_label")
    set_runs(attend, {6: f' {d["headcount_text"]}', 8: f"({label})" if label else "", 9: ""}, expect={5: "석)"})
    set_runs(staff, {2: d["staff_text"]})
    set_runs(summary, {4: ev.get("summary", "")}, expect={3: "(내"})
    set_runs(tops[P["dept"]], {0: f'({data["org"]["dept"]})'}, expect={0: "("})


def fill_overview(doc, data, d):
    ev, tops = data["event"], doc.orig
    set_only(set_title_cell(doc.tbl(T_BODY_TITLE)), ev["title"])
    set_runs(tops[P["date"]], {3: f' {d["date_text"]} ', 4: f'{ev["start"]} ~ {d["end"]} ({calc.fmt_duration(d["total_minutes"])})'},
             expect={2: "(일"})
    set_runs(tops[P["place"]], {2: ev["venue"]}, expect={1: "(장"})
    label = ev.get("attendee_label")
    set_runs(tops[P["attend"]], {2: d["headcount_text"], 4: f"({label})" if label else "", 5: ""}, expect={1: "(참"})
    set_runs(tops[P["summary"]], {3: ev.get("summary", ""), 4: ""}, expect={2: "(내"})
    if d["staff_text"]:
        set_runs(tops[P["staff"]], {0: "      " + d["staff_text"]})
    else:
        remove(tops[P["staff"]])


def fill_flow(doc, d):
    tbl = doc.tbl(T_FLOW)
    rows = tbl.findall("hp:tr", N)

    def fill(tr, r, i):
        c = tr_cells(tr)
        set_cell_lines(c[0], [f'{r["start"]}~{r["end"]}'])
        set_cell_lines(c[1], [calc.fmt_minutes(r["minutes"])])
        set_cell_lines(c[2], [f'▪ {r["item"]}'])
        set_cell_lines(c[3], [r["lead"]])
    rebuild_rows(tbl, 1, rows[1], rows[2], rows[-1], d["program"], fill)


def fill_roster(doc, data):
    """참석자 현황: 한 행에 2명(왼쪽 앞 절반, 오른쪽 뒤 절반).
    사진이 하나라도 있으면 셋째 칸은 사진(칸 배경 그림), 없으면 「직 위」 칸으로 쓴다."""
    people = data["attendees"]
    if not people:                      # 명단이 없으면 참석자 현황 쪽을 뺌
        remove(doc.orig[P["roster_head"]])
        remove(doc.orig[P["roster_head"] + 1])
        return {}
    use_photo = any(p.get("photo") for p in people)
    tail = _label_tail(data["event"].get("attendee_label"))
    set_runs(doc.orig[P["roster_head"]], {1: f"{tail} 현황" if tail and use_photo else "참석자 현황"})
    tbl = doc.tbl(T_ROSTER)
    rows = tbl.findall("hp:tr", N)
    head, body = rows[0], rows[1:]
    if not use_photo:
        hc = tr_cells(head)
        set_cell_lines(hc[2], ["직   위"])
        set_cell_lines(hc[5], ["직   위"])
    half = math.ceil(len(people) / 2)
    photos = {}
    for tr in body:
        tbl.remove(tr)
    for r in range(half):
        tr = clone(body[min(r, len(body) - 1)])
        c = tr_cells(tr)
        for side, k in ((0, r), (3, half + r)):
            p = people[k] if k < len(people) else None
            set_cell_lines(c[side], [p["org"] if p else ""])
            set_cell_lines(c[side + 1], [p["name"] if p else ""])
            ph = c[side + 2]
            bf = ph.get("borderFillIDRef")
            img = bf_image(doc.header, bf)
            if p and p.get("photo") and img and r < len(body):
                photos[img] = p["photo"]
                set_cell_lines(ph, [""])
                continue
            if p and p.get("photo"):
                doc.warnings.append(f'사진 칸이 모자라 {p["name"]} 사진을 넣지 못함(원본 사진 칸 {len(body) * 2}개)')
            if img:
                ph.set("borderFillIDRef", plain_twin(doc.header, bf))
            set_cell_lines(ph, ["" if use_photo or not p else p["position"]])
        tbl.append(tr)
    renumber(tbl)
    return photos


def generate(data, out_path):
    d = data["derived"]
    doc = Doc("brief.hwpx")
    if len(doc.orig) != TOPS:
        raise BuildError(f"보고요지 원본 문단 수({len(doc.orig)})가 예상({TOPS})과 다릅니다")
    expect_text(doc.orig[P["roster_head"]], "현황", "참석자 현황 제목")
    expect_text(doc.orig[P["ref_from"]], "(참고)", "참고 자료 시작")
    ref = doc.orig[P["ref_from"]:P["ref_to"] + 1]

    if data["event"].get("slogan") != ORIGINAL_SLOGAN:
        doc.warnings.append(f"표지·본문의 머리문구 그림과 Univ City 로고는 원본 그림(「{ORIGINAL_SLOGAN}」)입니다. 다른 행사면 한글에서 바꾸세요.")
    fill_staff(doc, data)
    fill_cover(doc, data, d)
    fill_overview(doc, data, d)
    fill_flow(doc, d)
    photos = fill_roster(doc, data)
    for p in ref:                       # (참고) 자료 쪽: 행사별 자료라 뺌
        remove(p)
    return doc.save(out_path, f'{data["event"]["title"]} 요지', photos)
