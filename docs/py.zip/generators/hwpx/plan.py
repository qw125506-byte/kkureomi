# -*- coding: utf-8 -*-
"""① 개최 계획서 — 공통 행사데이터를 간담회개최계획-hwpx 스킬의 content.json 형식으로 바꿔 그대로 만든다.

계획서 생성 로직은 스킬(build_plan.py)에 이미 완성되어 있으므로 다시 짜지 않고 입력만 변환한다.
대응 관계는 examples/스키마_대응표.md 참고.
"""
import textwrap

from core import calc
from core.hwpx import TEMPLATES, bp


def two_lines(s):
    """결재란 한 칸 두 줄: 청년정책팀장 → [청년정책, 팀장]"""
    return [s[:-2], s[-2:]] if len(s) > 4 else [s]


def org_lines(org):
    """명단 소속 두 줄: 국립공주대학교 → [국립공주, 대학교]"""
    for tail in ("대학교", "대학"):
        if org.endswith(tail) and len(org) > len(tail):
            return [org[:-len(tail)], tail]
    return org


def wrap(s, width):
    return textwrap.wrap(s, width=width, break_long_words=False) or [""]


def to_content(data):
    ev, org, d = data["event"], data["org"], data["derived"]
    title = f'{ev["title"]} 개최 계획(안)'
    label = ev.get("attendee_label")
    tail = label.split(",")[-1].strip() if label else ""
    main, staff = calc.attendee_summary(data)
    dur = calc.fmt_duration(d["total_minutes"])
    when = f'{d["date_text"]} {ev["start"]} ~ {d["end"]}'
    people = data["attendees"]
    use_photo = any(p.get("photo") for p in people)

    shorts = [p.get("org_short") or p["org"] for p in people]
    comp_lines, cur = [], ""
    for s in shorts:
        nxt = f"{cur}, {s}" if cur else s
        if len(nxt) > 44:
            comp_lines.append(cur + ",")
            cur = s
        else:
            cur = nxt
    comp_lines.append(cur)

    roster = []
    for p in people:
        row = {"소속": org_lines(p["org"]), "성명": p["name"]}
        if use_photo:
            if p.get("photo"):
                row["사진"] = p["photo"]
        else:
            row["비고"] = p["position"]
        roster.append(row)

    return {
        "_출처": "문서꾸러미 공통 행사데이터에서 변환",
        "기본": {"기관명": org["city"], "부서": org["dept"], "파일제목": title},
        "결재": {
            "문서번호": org["dept"],
            "결재선": [two_lines(x) for x in (org.get("approval_line") or [])[1:]],
            "협조": ", ".join(org.get("cooperation") or []),
            **({"보존기간": org["retention"]} if org.get("retention") else {}),
            **({"공개여부": org["disclosure"]} if org.get("disclosure") else {}),
        },
        "표지": {
            "머리문구": ev.get("slogan", ""),
            "제목": title,
            "일시": f"{when}({dur})",
            "장소": ev.get("venue_short") or ev["venue"],
            "참석대상": main,
            "참석보충": staff,
            "주요내용": ev.get("summary", ""),
        },
        "본문제목": title,
        "취지": wrap(ev.get("intent", ""), 33)[:2],
        "추진목적": ev.get("purpose") or [],
        "행사개요": {
            "일시": f"{when} ({dur})",
            "장소": ev["venue"],
            "주재": ev.get("chair", ""),
            "참석": {
                "인원": d["headcount_text"],
                "상세": f"({label})" if label else "",
                "보충": (f'배석({d["staff_count"]}명) : {ev["staff_note"]}' if ev.get("staff_note")
                       else (f'배석({d["staff_count"]}명)' if d["staff_count"] else "")),
            },
            "참석구성": {"제목": f"【 {tail} 현황 】", "줄": comp_lines} if tail and people else None,
            "주요안건": ev.get("agenda") or [],
        },
        "행사흐름": {"행": [{"시간": f'{r["start"]}~{r["end"]}', "소요": calc.fmt_minutes(r["minutes"]),
                          "내용": r["item"], "비고": r["lead"]} for r in d["program"]], "주석": ""},
        "소요예산": {
            "예산액": d["budget_text"],
            "합계": calc.won(d["budget_total"]),
            "항목": [{"구분": r["item"], "산출기초": r["basis"], "금액": calc.won(r["amount"]),
                    "통계목": r.get("account", "")} for r in d["budget_rows"]],
            "주석": "",
        },
        "행정사항": {"행": [{"내용": a["task"], "관련부서": a.get("dept", ""), "비고": calc.fmt_due(a.get("due"))}
                        for a in data.get("admin_tasks") or []], "주석": ""},
        "향후계획": {"행": [{"내용": f["task"], "비고": calc.fmt_due(f.get("due"))}
                        for f in data.get("follow_up") or []], "주석": ""},
        "붙임": [{"제목": "참석자 명단", "형식": "명단", "명단": roster}] if people else [],
    }


def generate(data, out_path):
    content = to_content(data)
    r = bp.build(content, out_path, TEMPLATES / "plan.hwpx")
    r["warnings"] = []
    r["path"] = str(out_path)
    return r
