# -*- coding: utf-8 -*-
"""① 개최 계획서 — 공통 행사데이터를 간담회개최계획-hwpx 스킬의 content.json 형식으로 바꿔 그대로 만든다.

계획서 생성 로직은 스킬(build_plan.py)에 이미 완성되어 있으므로 다시 짜지 않고 입력만 변환한다.
대응 관계는 examples/스키마_대응표.md 참고.
"""
import re
import textwrap

from core import calc
from core.hwpx import TEMPLATES, bp


TITLES = ("팀장", "과장", "국장", "실장", "단장", "소장")


def two_lines(s):
    """결재란 한 칸 두 줄(견본 표기): 청년정책팀장 → [청년정책, 팀장], ㅇㅇ팀장 → [ㅇㅇ, 팀장]"""
    return [s[:-2], s[-2:]] if len(s) > 2 and s.endswith(TITLES) else [s]


ROSTER_WIDTH = 5                 # 명단 소속 칸 한 줄 글자 수(13pt, 칸 폭 기준)
WORD_STARTS = ("대학교", "대학", "협의회", "연합회", "협회", "센터", "재단", "진흥원", "연구원", "위원회", "조합",
               "지원", "창업", "교육", "산업", "경제", "기업", "청년", "문화", "복지")
WORD_ENDS = ("천안", "충남", "충청", "아산", "한국", "국립", "청년", "창업", "㈜")


def org_lines(org, width=ROSTER_WIDTH):
    """명단 소속을 칸 폭에 맞게 낱말 사이에서 나눈다(글자 중간에서 끊기지 않게).
    국립공주대학교 → [국립공주, 대학교], 천안창업지원센터 → [천안창업, 지원센터], 천안청년창업협의회 → [천안청년, 창업협의회]"""
    org = org.strip()
    for tail in ("대학교", "대학"):                 # 대학은 견본처럼 늘 두 줄(상 명 / 대 학 교)
        if org.endswith(tail) and len(org) > len(tail) and len(org) - len(tail) <= width:
            return [org[:-len(tail)], tail]
    if len(org) <= width:
        return org
    if " " in org:                                   # 띄어쓰기가 있으면 그 자리에서
        a, b = org.rsplit(" ", 1)
        if len(a) <= width and len(b) <= width:
            return [a, b]
    lo, hi = max(1, len(org) - width), min(width, len(org) - 1)
    if lo > hi:                                      # 두 줄로도 모자라면 앞에서부터 width씩
        return [org[k:k + width] for k in range(0, len(org), width)]

    def score(k):
        sc = -abs(k - len(org) / 2) * 0.1
        if org[k:].startswith(WORD_STARTS):
            sc += 3
        if org[:k].endswith(WORD_ENDS):
            sc += 2
        return sc
    k = max(range(lo, hi + 1), key=score)
    return [org[:k], org[k:]]


def cover_attend(main):
    """표지 참석대상은 한 줄로 짧게(견본: 「13명(시장님, 관내 12개 대학 총장)」).
    설명이 길면 첫 무리만 남기고 「등」 — 자세한 구성은 본문 Ⅱ 행사개요에 그대로 있다."""
    m = re.match(r"^(.*?)\((.*)\)$", main)
    if not m or len(main) <= 26:
        return main
    parts = [x.strip() for x in m.group(2).split(",")]
    return f"{m.group(1)}({parts[0]} 등)" if len(parts) > 1 else main


def lead_lines(lead):
    """행사흐름 비고(진행자): 「시장님, 참석자」 → 「시장님」(참석자는 빼고 진행하는 사람만).
    그래도 여럿이면 한 줄에 하나씩(좁은 칸에서 낱말이 잘리지 않게)"""
    parts = [x.strip() for x in str(lead or "").split(",") if x.strip()]
    kept = [x for x in parts if x not in ("참석자", "참석자 전원", "전원")] or parts
    return kept if len(kept) > 1 else (kept[0] if kept else "")


POSITIONS = ("부총장", "총장", "대표이사", "대표", "회장", "센터장", "원장", "위원장", "이사장", "단장", "소장", "교수")


def box_title(label):
    """Ⅱ 참석 구성 상자 제목: 「시장님, 관내 12개 대학 총장」 → 「관내 12개 대학」(직위는 뺀다).
    참석자가 여러 무리(쉼표로 여럿)면 「참석 기관」."""
    if not label:
        return ""
    parts = [x.strip() for x in label.split(",") if x.strip() and "시장" not in x]
    if len(parts) != 1:
        return "참석 기관"
    words = parts[0].split()
    while len(words) > 1 and words[-1] in POSITIONS:
        words.pop()
    return " ".join(words)


def roster_title(label):
    """붙임 명단 제목: 「시장님, 관내 12개 대학 총장」 → 「관내 12개 대학 총장 명단」(최종 계획서 표기), 여러 무리면 「참석자 명단」"""
    parts = [x.strip() for x in (label or "").split(",") if x.strip() and "시장" not in x]
    return f"{parts[0]} 명단" if len(parts) == 1 else "참석자 명단"


def wrap(s, width):
    return textwrap.wrap(s, width=width, break_long_words=False) or [""]


def to_content(data):
    ev, org, d = data["event"], data["org"], data["derived"]
    title = f'{ev["title"]} 개최 계획(안)'
    label = ev.get("attendee_label")
    tail = box_title(label)
    main, staff = calc.attendee_summary(data)
    dur = calc.fmt_duration(d["total_minutes"])
    when = f'{d["date_text"]} {ev["start"]} ~ {d["end"]}'
    people = data["attendees"]
    use_photo = any(p.get("photo") for p in people)

    shorts = [p.get("org_short") or p["org"] for p in people]
    comp_lines, cur = [], ""
    for s in shorts:
        nxt = f"{cur}, {s}" if cur else s
        if len(nxt) > 40:                         # 상자 앞뒤 여백을 두고 한 줄에 들어가는 길이
            comp_lines.append(cur + ",")
            cur = s
        else:
            cur = nxt
    comp_lines.append(cur)

    roster = []
    for p in people:
        row = {"소속": org_lines(p["org"]), "성명": p["name"]}
        if use_photo:
            if p.get("photo"):
                row["사진"] = p["photo"]
        else:
            row["비고"] = p["position"]
        roster.append(row)

    return {
        "_출처": "문서꾸러미 공통 행사데이터에서 변환",
        "기본": {"기관명": org["city"], "부서": org["dept"], "파일제목": title},
        "결재": {
            "문서번호": org["dept"],
            "결재선": [two_lines(x) for x in (org.get("approval_line") or [])[1:]],
            "협조": ", ".join(org.get("cooperation") or []),
            **({"보존기간": org["retention"]} if org.get("retention") else {}),
            **({"공개여부": org["disclosure"]} if org.get("disclosure") else {}),
        },
        "표지": {
            "머리문구": ev.get("slogan", ""),
            "제목": title,
            "일시": f"{when}({dur})",
            "장소": ev.get("venue_short") or ev["venue"],
            "참석대상": cover_attend(main),
            "참석보충": staff,
            "주요내용": ev.get("summary", ""),
        },
        "본문제목": title,
        "취지": wrap(ev.get("intent", ""), 33)[:2],
        "추진목적": ev.get("purpose") or [],
        "행사개요": {
            "일시": f"{when} ({dur})",
            "장소": ev["venue"],
            "주재": "",                     # 천안시 최종 계획서 양식에는 (주 재) 줄이 없다
            "참석": {
                "인원": d["headcount_text"],
                "상세": f"({label})" if label else "",
                "보충": (f'배석({d["staff_count"]}명) : {ev["staff_note"]}' if ev.get("staff_note")
                       else (f'배석({d["staff_count"]}명)' if d["staff_count"] else "")),
            },
            "참석구성": {"제목": f"【 {tail} 현황 】", "줄": comp_lines} if tail and people else None,
            "주요안건": ev.get("agenda") or [],
        },
        "행사흐름": {"행": [{"시간": f'{r["start"]}~{r["end"]}', "소요": calc.fmt_minutes(r["minutes"]),
                          "내용": r["item"], "비고": lead_lines(r["lead"])} for r in d["program"]], "주석": ""},
        "소요예산": {
            "예산액": d["budget_text"],
            "합계": calc.won(d["budget_total"]),
            "항목": [{"구분": r["item"], "산출기초": r["basis"], "금액": calc.won(r["amount"]),
                    "통계목": r.get("account", "")} for r in d["budget_rows"]],
            "주석": "",
        },
        "행정사항": {"행": [{"내용": a["task"], "관련부서": a.get("dept", ""), "비고": calc.fmt_due(a.get("due"))}
                        for a in data.get("admin_tasks") or []], "주석": ""},
        "향후계획": {"행": [{"내용": f["task"], "비고": calc.fmt_due(f.get("due"))}
                        for f in data.get("follow_up") or []], "주석": ""},
        "붙임": [{"제목": roster_title(label), "형식": "명단", "명단": roster}] if people else [],
    }


def generate(data, out_path):
    content = to_content(data)
    r = bp.build(content, out_path, TEMPLATES / "plan.hwpx")
    r["warnings"] = []
    r["path"] = str(out_path)
    return r
