# -*- coding: utf-8 -*-
"""회의록 → 결과보고 데이터(result) 자동 작성.

회의록 파일 하나만 받으면 입력 칸 없이 결과보고에 필요한 값을 만든다.
- 공통(규칙): 녹음 정보(「오후 1:57 ・ 83분 30초」)로 실제 종료 시각, 「참석자 N 00:05」 묶음으로 붙임 회의록 표,
  계획서의 안건·향후계획으로 회의내용·향후계획 줄
- AI(Claude, 이름은 가린 뒤 전송): 기관별 건의사항·관련부서(추정), 시장님 총평, 핵심 결과, 발언 요약 회의록
- AI를 못 쓰면 건의사항·총평 자리에 「[확인 필요]」를 넣어 담당자가 채우게 한다(지어내지 않음).
"""
import re

from ai.client import ask_json, prompt
from core import calc

S = {"type": "string"}
CHECK = "[확인 필요]"

RESULT_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["suggestions", "mayor_summary", "highlights", "minutes"],
    "properties": {
        "suggestions": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["org", "title", "detail", "depts"],
            "properties": {"org": S, "title": S, "detail": {"type": "array", "items": S},
                           "depts": {"type": "array", "items": S}}}},
        "mayor_summary": {"type": "array", "items": S},
        "highlights": {"type": "array", "items": S},
        "minutes": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["org", "position", "name", "lines", "key", "depts"],
            "properties": {"org": S, "position": S, "name": S, "lines": {"type": "array", "items": S},
                           "key": {"type": "array", "items": S}, "depts": {"type": "array", "items": S}}}},
    },
}


# ---------- 녹취 읽기(규칙) ----------
HEAD = re.compile(r"(오전|오후)\s*(\d{1,2}):(\d{2})\s*[・·•]?\s*(\d+)\s*분\s*(?:(\d+)\s*초)?")
TURN = re.compile(r"^(참석자\s*\d+|[가-힣A-Za-z ]{1,12})\s+(\d{1,2}:\d{2}(?::\d{2})?)\s*$")


def recording_end(text):
    """「오후 1:57 ・ 83분 30초」 → 종료 시각 HH:MM(녹음 끝). 못 찾으면 None"""
    m = HEAD.search(text[:500])
    if not m:
        return None
    ap, h, mi, mins, secs = m.groups()
    h = int(h) % 12 + (12 if ap == "오후" else 0)
    total = h * 60 + int(mi) + int(mins)          # 초는 버림(원본 결과보고와 같은 분 단위)
    return calc.to_hhmm(total)


# 발언자 줄: 녹음 앱(「홍길동 00:12」「참석자 1 00:05」), 속기록(「[홍길동 / 천안시장]」), 「홍길동(천안시장):」
TURN_BRACKET = re.compile(r"^[\[【]\s*([가-힣]{2,4})\s*[/|·]\s*([^\]】]{1,30}?)\s*[\]】]\s*$")
TURN_COLON = re.compile(r"^([가-힣]{2,4})\s*\(([^)]{1,30})\)\s*[:：]\s*(.*)$")
NOISE = re.compile(r"^(?:\d+\.\s|※|[\[【][^/\]】]*[\]】]$|-{3,}|={3,})")


def _speaker(line):
    """(이름, 직위 또는 "", 같은 줄의 발언) — 발언자 줄이 아니면 None"""
    m = TURN.match(line)
    if m:
        return re.sub(r"\s+", " ", m.group(1)).strip(), "", ""
    m = TURN_BRACKET.match(line)
    if m:
        return m.group(1), m.group(2).strip(), ""
    m = TURN_COLON.match(line)
    if m:
        return m.group(1), m.group(2).strip(), m.group(3).strip()
    return None


def turns(text, roles=None):
    """[(화자, [줄…])] — 같은 화자가 이어 말하면 하나로 묶는다. roles(dict)를 주면 {화자: 직위}를 채운다."""
    out, cur = [], None
    for raw in text.splitlines():
        line = raw.strip().lstrip("﻿")
        sp = _speaker(line)
        if sp:
            who, role, rest = sp
            if roles is not None and role:
                roles.setdefault(who, role)
            if out and out[-1][0] == who:
                cur = out[-1][1]
            else:
                cur = []
                out.append((who, cur))
            if rest:
                cur.append(rest)
            continue
        if cur is not None and line and not NOISE.match(line):
            cur.append(line)
    return [(w, ls) for w, ls in out if ls]


CITY_ROLE = re.compile(r"(시장|부시장|국장|실장|과장|팀장|주무관|담당|사회자|비서|단장)$")
ORG_SUFFIX = [("센터장", "센터장", -1), ("협의회장", "회장", -1), ("협회장", "회장", -1)]


def attendee_from_role(name, role):
    """「㈜그린로직 대표」 → {org, position, name}. 시 쪽 직위(과장·국장·시장…)면 None"""
    if not role or CITY_ROLE.search(role) and not re.search(r"(센터|협의회|협회|㈜|주식회사|대학)", role):
        return None
    for suf, pos, cut in ORG_SUFFIX:
        if role.endswith(suf):
            return {"org": role[:cut], "position": pos, "name": name}
    if " " in role:
        org, pos = role.rsplit(" ", 1)
        return {"org": org, "position": pos, "name": name}
    return {"org": role, "position": "", "name": name}


def rule_minutes(text):
    return [{"org": "", "position": who, "name": "", "lines": lines} for who, lines in turns(text)]


# ---------- AI 없이 요약(규칙) ----------
# 회의록 발언자가 이름으로 적혀 있고 참석자 명단과 맞으면, 요청 문장을 뽑아 보고서 문체로 바꾼다.
# 문장은 회의록에 있는 것만 쓴다(지어내지 않음). 「참석자 1」처럼 이름이 없으면 쓰지 않는다.
REQ_END = re.compile(r"\s*(?:(?:해|하여)?\s*주(?:시기 바랍니다|십시오|셨으면 (?:합니다|좋겠습니다)|시면 좋겠습니다|시길 바랍니다)"
                     r"|[을를]?\s*(?:제안|건의|요청)드립니다|[이가]?\s*(?:있|했|되|됐)(?:었)?으면 좋겠습니다)\.?$")
REQUEST = re.compile(r"주시기 바랍니다|주십시오|주셨으면|주시면 좋겠|요청드|건의드|제안드|(?:있|했|되|됐)(?:었)?으면 좋겠")
ENDINGS = [(r"(?:해|하여)? 주(?:시기 바랍니다|십시오|셨으면 (?:합니다|좋겠습니다)|시면 좋겠습니다|시길 바랍니다)\.?$", lambda m: ("해" if m.group(0).lstrip().startswith(("해", "하여")) else "") + " 줄 것을 요청함"),
           (r"([을를]?) ?(제안|건의|요청)드립니다\.?$", lambda m: f"{m.group(1)} {m.group(2)}함".replace("  ", " ")),
           (r"(있|했|되|됐)(었)?으면 좋겠습니다\.?$", lambda m: f"{m.group(1)}{m.group(2) or ''}으면 좋겠다는 의견임"),
           (r"어렵습니다\.?$", "어려움"), (r"겠습니다\.?$", "겠음"), (r"했습니다\.?$", "했음"), (r"었습니다\.?$", "었음"),
           (r"았습니다\.?$", "았음"), (r"있습니다\.?$", "있음"), (r"없습니다\.?$", "없음"), (r"합니다\.?$", "함"),
           (r"입니다\.?$", "임"), (r"됩니다\.?$", "됨"), (r"드립니다\.?$", "드림"), (r"습니다\.?$", "음")]
DEPT_WORDS = [("입주|공간|사무실|오피스|장비", "일자리경제과"), ("판로|구매|판매|부스|축제", "기업지원과"),
              ("투자|자금|융자|보증", "기업지원과"), ("주거|월세|주택", "주택과"), ("실증|시설", "미래전략과"),
              ("안내|창구|통합", "일자리경제과"), ("소통|협의|정례", "일자리경제과"), ("교통|주차|버스|전철", "교통정책과")]


def _bieup_to_mieum(m):
    """「봅니다」→「봄」: 끝 글자 받침 ㅂ → ㅁ"""
    ch = m.group(1)
    code = ord(ch) - 0xAC00
    return chr(0xAC00 + code - 1) if code % 28 == 17 else m.group(0)


def report_style(s, mayor=False):
    """「~해 주시기 바랍니다.」 → 「~해 줄 것을 요청함」(시장님 말씀은 「~해 주기 바람」), 「~합니다.」 → 「~함」"""
    s = s.strip()
    if mayor:
        new = re.sub(r"(?:해|하여)? 주(?:시기 바랍니다|십시오|셨으면 합니다|시길 바랍니다)\.?$",
                     lambda m: ("해" if m.group(0).lstrip().startswith(("해", "하여")) else "") + " 주기 바람", s)
        if new != s:
            return new
    for pat, rep in ENDINGS:
        new = re.sub(pat, rep, s)
        if new != s:
            return new
    new = re.sub(r"([가-힣])니다\.?$", _bieup_to_mieum, s)      # 봅니다 → 봄, 줍니다 → 줌
    return new.rstrip(".")


def request_title(s, limit=26):
    """요청 문장 → 짧은 제목(뒤쪽 핵심을 살림): 「…실증할 수 있는 기회를 마련해 주셨으면 합니다」 → 「작은 규모라도 실증할 수 있는 기회 마련」"""
    t = REQ_END.sub("", s.strip())
    ws = t.split()
    if len(ws) >= 2 and re.search(r"[가-힣]{2,}[을를]$", ws[-2]) and not re.search(r"[할될볼받]을$", ws[-2]):
        ws[-2] = ws[-2][:-1]                                          # 목적어 조사만: 기회를 마련 → 기회 마련
    t = " ".join(ws)
    t = re.sub(r"([가-힣]+)어$", lambda m: m.group(1) + "기", t)         # 열어 → 열기, 만들어 → 만들기
    t = re.sub(r"(\S+[을를ㄹ]?) 수$", r"\1 수 있도록", t)               # 확인받을 수 → 확인받을 수 있도록
    t = re.split(r"[,，]\s*", t)[-1] if len(t) > limit else t           # 길면 마지막 마디만
    words, out = t.split(), []
    for w in reversed(words):                                        # 그래도 길면 뒤에서부터 낱말 단위로
        if out and len(" ".join([w] + out)) > limit:
            break
        out.insert(0, w)
    return " ".join(out).strip(" ,")


def sentences(lines):
    out = []
    for l in lines:
        out += [x.strip() for x in re.split(r"(?<=[.?!])\s+", l) if x.strip()]
    return out


def rule_summary(text, data, orgs):
    host = data["host"]
    roles = {}
    ts = turns(text, roles)
    who = {a["name"]: a for a in data["attendees"] if a.get("name")}
    for name, role in roles.items():          # 속기록에 「[김민준 / ㈜그린로직 대표]」처럼 소속이 적혀 있으면 명단에 없어도 참석자로
        if name not in who:
            a = attendee_from_role(name, role)
            if a:
                who[name] = a
    staff = {s["name"]: s.get("position") or s.get("role") for s in (data.get("staff_present") or []) + (data["org"].get("staff") or [])
             if s.get("name")}
    staff.update({n: r for n, r in roles.items() if n not in who and n not in staff})
    if not ts or not any(w in who for w, _ in ts):
        return None
    names = [w for w, _ in ts]
    mayor_name = host["name"]
    by_role = [n for n, r in roles.items() if re.search(r"(?<!부)시장(님)?$", r)]
    if mayor_name not in names and by_role:
        mayor_name = by_role[0]
    first_is_mc = names[0] not in who and names[0] != mayor_name and not roles.get(names[0])
    mc = names[0] if first_is_mc else None                       # 이름만 있는 첫 발언자 = 사회자
    if mayor_name not in names:          # 시장 이름을 모르면: 명단에 없는 사람 중 가장 많이 말한 사람
        cand = [w for w in dict.fromkeys(names) if w not in who and w not in staff and w != mc]
        if cand:
            mayor_name = max(cand, key=lambda w: (names.count(w), sum(len(ls) for x, ls in ts if x == w)))
    by_org, mayor, minutes = {}, [], []
    for name, lines in ts:
        sents = sentences(lines)
        if name in who:
            a = who[name]
            org = a.get("org_short") or a["org"]
            body = [s for s in sents if not (name in s and s.endswith("입니다."))]      # 자기소개 빼기
            reqs = [s for s in body if REQUEST.search(s)]
            ctx = [s for s in body if s not in reqs]
            for i, r in enumerate(reqs):
                depts = list(dict.fromkeys(d for k, d in DEPT_WORDS if re.search(k, r)))[:2]
                detail = ([report_style(ctx[0])] if ctx and i == 0 else []) + [report_style(r)]
                by_org.setdefault(org, []).append({"org": org, "title": request_title(r), "detail": detail, "depts": depts,
                                                   "_who": name})
            mine = [x for x in by_org.get(org, []) if x.get("_who") == name]
            minutes.append({"org": a["org"], "position": a["position"], "name": name,
                            "lines": [report_style(s) for s in body],
                            "key": [x["title"] for x in mine] or [request_title(body[0])] if body else [],
                            "depts": list(dict.fromkeys(d for x in mine for d in x["depts"]))})
        elif name == mayor_name:
            mayor.append(sents)
            minutes.append({"org": "", "position": "시장님", "name": name, "lines": [report_style(s, mayor=True) for s in sents]})
        elif name != mc and staff.get(name) not in ("담당자", "사회자"):      # 사회자 진행 멘트는 뺀다
            minutes.append({"org": "", "position": staff.get(name, ""), "name": name, "lines": [report_style(s) for s in sents]})
    merged = {}
    for m in minutes:
        if m.get("org") and m["name"] in merged:
            prev = merged[m["name"]]
            prev["lines"] += m["lines"]
            prev["key"] = list(dict.fromkeys(prev.get("key", []) + m.get("key", [])))
            prev["depts"] = list(dict.fromkeys(prev.get("depts", []) + m.get("depts", [])))
        else:
            merged[m["name"] if m.get("org") else id(m)] = m
    minutes = list(merged.values())
    for ss in by_org.values():
        for x in ss:
            x.pop("_who", None)
    sugg = []
    for o in orgs:
        sugg += by_org.get(o) or [{"org": o}]
    sugg += [s for o, ss in by_org.items() if o not in orgs for s in ss]
    closing = mayor[-1] if len(mayor) > 1 else (mayor[0] if mayor else [])
    highlights = [ss[0]["title"] for ss in by_org.values()][:4]
    return {"suggestions": sugg, "mayor_summary": [report_style(s, mayor=True) for s in closing] or [f"{CHECK} 시장님 총평"],
            "highlights": highlights or [f"{CHECK} 핵심 결과"], "minutes": minutes,
            **({"host_name": mayor_name} if mayor_name and mayor_name != host["name"] else {})}


# ---------- 결과 만들기 ----------
def build_result(minutes_text, data, use_ai=None, client=None):
    """(result 사전, 메모 목록). data는 load_event() 결과."""
    from ai import client as aic
    use_ai = aic.available() if use_ai is None else use_ai
    ev = data["event"]
    notes = []
    end = recording_end(minutes_text)
    if end and calc.to_min(end) > calc.to_min(ev["start"]):
        notes.append(f"실제 종료 시각 {end}(회의록 녹음 정보로 계산)")
    else:
        end = data["derived"]["end"]
        notes.append(f"회의록에 녹음 시간이 없어 계획 종료 시각 {end}을 씀 — 확인 필요")

    orgs = []
    for a in data["attendees"]:
        o = a.get("org_short") or a["org"]
        if o not in orgs:
            orgs.append(o)
    res = {
        "actual_end": end,
        "contents": list(ev.get("agenda") or [p["item"] for p in data["program"]]),
        "opinion_subject": "기관",
        "plan_lines": [f["task"] for f in data.get("follow_up") or []] or [f"{CHECK} 향후계획"],
        "next_steps": "관련부서 검토 후 처리 예정" if data.get("follow_up") else f"{CHECK} 향후계획",
        "summary": ev.get("summary") or ", ".join(ev.get("agenda") or [])[:40],
        "photos": [],
    }

    ai_ok = False
    if use_ai:
        try:
            user = (f"기관 목록(이 순서로 모두): {', '.join(orgs) or '(명단 없음)'}\n주빈: {data['host']['position']}\n"
                    f"행사: {ev['title']}\n\n[회의록]\n{minutes_text}")
            r = ask_json("result", prompt("result"), user, RESULT_SCHEMA, data=data, client=client, max_tokens=32000)
            sugg = []
            for o in orgs:
                mine = [s for s in r["suggestions"] if s["org"] == o and s["title"]]
                sugg += mine or [{"org": o}]
            sugg += [s for s in r["suggestions"] if s["org"] not in orgs and s["title"]]
            res.update(suggestions=sugg, mayor_summary=r["mayor_summary"], highlights=r["highlights"],
                       minutes=r["minutes"] or rule_minutes(minutes_text))
            n = sum(1 for s in sugg if s.get("title"))
            notes.append(f"AI가 회의록을 정리함: 건의사항 {n}건, 총평 {len(r['mayor_summary'])}줄 — 관련부서는 추정, 회의록과 대조 필요")
            ai_ok = True
        except Exception as e:  # noqa: BLE001 — AI가 안 되면 규칙으로
            notes.append(f"AI 정리 실패({type(e).__name__}: {str(e)[:60]}) — 녹취 그대로 정리")

    if not ai_ok:
        r = rule_summary(minutes_text, data, orgs)
        if r:
            res.update(r)
            n = sum(1 for s in r["suggestions"] if s.get("title"))
            notes.append(f"AI 없이 규칙으로 정리: 발언자를 참석자 명단과 맞춰 건의사항 {n}건·총평 {len(r['mayor_summary'])}줄을 "
                         "회의록 문장에서 뽑음 — 관련부서는 낱말로 추정, 회의록과 대조 필요")
            return res, notes
        res.update(
            suggestions=[{"org": o, "title": f"{CHECK} 건의사항", "detail": ["회의록에서 해당 기관 발언을 정리해 주세요."]}
                         for o in orgs] or [{"org": CHECK, "title": f"{CHECK} 건의사항"}],
            mayor_summary=[f"{CHECK} 시장님 총평을 회의록에서 정리해 주세요."],
            highlights=[f"{CHECK} 핵심 결과"],
            minutes=rule_minutes(minutes_text),
        )
        notes.append(f"AI 없이 정리: 회의록 {len(res['minutes'])}개 발언 묶음을 붙임에 넣고, 건의사항·총평은 「{CHECK}」로 둠")
    return res, notes
