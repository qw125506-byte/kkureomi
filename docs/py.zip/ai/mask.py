# -*- coding: utf-8 -*-
"""비식별 — 외부 AI로 보내기 전에 사람 이름·연락처를 가리고, 돌아온 글에서 되돌린다.

- 행사데이터에 있는 사람(주빈·참석자·배석·담당자·회의록 발언자) 이름 → 「참석자A」「참석자B」…
  띄어 쓴 이름(「홍 길 동」)도 같이 가린다.
- 전화번호·이메일·주민등록번호 모양 → [연락처] [이메일] [주민번호] (되돌리지 않음)
- 명단에 없는 이름이라도 「홍길동 총장님」처럼 성씨로 시작하는 세 글자 + 띄어쓰기 + 직함 꼴이면 한 번 더 가린다.
기관명·직위는 그대로 둔다(문장 작성에 필요하고 개인정보가 아님).
"""
import re

PHONE = re.compile(r"(?<!\d)(0\d{1,2}[-.\s]?\d{3,4}[-.\s]?\d{4})(?!\d)")
EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
RRN = re.compile(r"(?<!\d)\d{6}-[1-4]\d{6}(?!\d)")
TITLES = "총장|부총장|시장|부시장|과장|팀장|국장|실장|단장|교수|대표|위원장|위원|원장|센터장|이사장|회장|주무관|담당"
HONORIFIC = re.compile(rf"(?<![가-힣])([가-힣]{{2,4}})(?=\s(?:{TITLES})님?)")
# 흔한 성씨(명단에 없는 이름을 직함 앞에서 찾을 때, 첫 글자가 성씨인 2~4자만 이름으로 본다)
SURNAMES = set("김이박최정강조윤장임한오서신권황안송류전홍고문양손배백허유남심노하곽성차주우구민진나지엄채원천방공현함변염여추도소석선설마길연위표명기반왕금옥육인맹제모탁국어은편용예봉경")
NOT_NAMES = {"오히려", "주셔서", "이렇게", "그렇게", "저렇게", "어떻게", "이러한", "그러한", "여러분", "지금은", "모두가",
             "우리가", "제가요", "함께한", "이번에", "정말로", "조금더", "한번더", "이것은", "그것은"}
LABELS = [f"참석자{chr(ord('A') + i)}" for i in range(26)] + [f"참석자{i}" for i in range(27, 400)]


def known_names(data):
    names = []
    if not data:
        return names
    if data.get("host"):
        names.append(data["host"]["name"])
    for key in ("attendees", "staff_present"):
        names += [p["name"] for p in data.get(key) or []]
    names += [s["name"] for s in (data.get("org") or {}).get("staff") or []]
    res = data.get("result") or {}
    names += [p["name"] for p in res.get("present_extra") or []]
    names += [m["name"] for m in res.get("minutes") or []]
    seen, out = set(), []
    for n in names:
        n = (n or "").replace(" ", "")
        if len(n) >= 2 and n not in seen:
            seen.add(n)
            out.append(n)
    return out


def _protected_words(data):
    """가리면 안 되는 말(기관명·도시명 등) — 직함 앞에 와도 이름으로 보지 않는다."""
    words = set()
    if data:
        org = data.get("org") or {}
        for w in (org.get("city"), org.get("dept"), org.get("team")):
            if w:
                words.add(w)
                words.add(w.rstrip("시"))
        for a in data.get("attendees") or []:
            words |= {a.get("org", ""), a.get("org_short", "")}
    return {w for w in words if w}


def mask(text, data=None, table=None):
    """(가린 글, 대응표 {라벨: 원래 이름}) — table을 넘기면 같은 라벨을 이어서 쓴다."""
    table = dict(table or {})
    rev = {v: k for k, v in table.items()}

    def label_for(name):
        if name not in rev:
            lab = LABELS[len(rev)]
            rev[name] = lab
            table[lab] = name
        return rev[name]

    s = RRN.sub("[주민번호]", text)
    s = EMAIL.sub("[이메일]", s)
    s = PHONE.sub("[연락처]", s)
    for name in sorted(known_names(data), key=len, reverse=True):
        lab = label_for(name)
        s = s.replace(name, lab)
        s = s.replace(" ".join(name), lab)          # 띄어 쓴 이름
    protect = _protected_words(data)
    def guess(m):
        w = m.group(1)
        if (len(w) != 3 or w in protect or w in NOT_NAMES or w.startswith("참석자") or w[0] not in SURNAMES
                or w.endswith(("대", "청", "과", "원", "시"))):
            return w
        return label_for(w)
    s = HONORIFIC.sub(guess, s)
    return s, table


def unmask(obj, table):
    """문자열·목록·사전 안의 라벨을 원래 이름으로 되돌린다(긴 라벨부터)."""
    if isinstance(obj, str):
        for lab in sorted(table, key=len, reverse=True):
            obj = obj.replace(lab, table[lab])
        return obj
    if isinstance(obj, list):
        return [unmask(x, table) for x in obj]
    if isinstance(obj, dict):
        return {k: unmask(v, table) for k, v in obj.items()}
    return obj


def leaked(text, data):
    """가린 글에 명단의 이름·연락처가 남았는지(검사용)"""
    left = [n for n in known_names(data) if n in text]
    left += PHONE.findall(text) + EMAIL.findall(text)
    return left
