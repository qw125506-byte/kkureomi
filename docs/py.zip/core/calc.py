# -*- coding: utf-8 -*-
"""공통 계산 — 식순 시각, 날짜·요일, 금액(한글), 참석 인원, 시장님 하실 일.

문서 생성기는 시간·금액·인원을 직접 계산하지 않고 이 모듈만 쓴다(문서 간 불일치 방지).
표준 라이브러리만 사용한다.
"""
import datetime

WEEK = "월화수목금토일"


# ---------- 시각 ----------
def to_min(hhmm):
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def to_hhmm(minutes):
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def program_times(event, program):
    """식순마다 no·start·end를 붙인 목록과 전체 종료 시각을 돌려준다."""
    cur = to_min(event["start"])
    rows = []
    for i, p in enumerate(program, 1):
        end = cur + p["minutes"]
        lead = p.get("lead") or ("시장님" if p.get("is_mayor") else "사회자")   # 진행자를 비우면 기본값
        rows.append({**p, "lead": lead, "no": i, "start": to_hhmm(cur), "end": to_hhmm(end)})
        cur = end
    return rows, to_hhmm(cur)


def total_minutes(program):
    return sum(p["minutes"] for p in program)


def fmt_minutes(m):
    """5 → 5’ (원본 행사흐름 표 표기)"""
    return f"{m}’"


def fmt_duration(m):
    """60 → 1시간, 90 → 1시간 30분, 45 → 45분"""
    h, mm = divmod(m, 60)
    if h and mm:
        return f"{h}시간 {mm}분"
    return f"{h}시간" if h else f"{mm}분"


# ---------- 날짜 ----------
def weekday(iso):
    return WEEK[datetime.date.fromisoformat(iso).weekday()]


def fmt_date(iso, with_weekday=True):
    """2026-08-12 → 2026. 8. 12.(수)"""
    d = datetime.date.fromisoformat(iso)
    s = f"{d.year}. {d.month}. {d.day}."
    return s + f"({WEEK[d.weekday()]})" if with_weekday else s


def fmt_due(due):
    """행정사항·향후계획 기한: 2026-07-10 → ~ 7. 10.일한 / 「행사당일」 등은 그대로"""
    if not due:
        return ""
    try:
        d = datetime.date.fromisoformat(due)
    except ValueError:
        return due
    return f"~ {d.month}. {d.day}.일한"


def fmt_when(event, end=None):
    """2026. 8. 12.(수) 14:00 ~ 15:00 (1시간)"""
    s = f'{fmt_date(event["date"])} {event["start"]}'
    if end:
        dur = to_min(end) - to_min(event["start"])
        s += f" ~ {end} ({fmt_duration(dur)})"
    return s


# ---------- 금액 ----------
_DIGITS = "영일이삼사오육칠팔구"


def won_korean(n):
    """5450000 → 금오백사십오만원. 십·백·천 앞의 '일'은 생략(공문서 관례: 금오십만원)."""
    if n == 0:
        return "금영원"
    units, big = ["", "십", "백", "천"], ["", "만", "억", "조"]
    out, g = "", 0
    while n:
        part, n = n % 10000, n // 10000
        s = ""
        for i in range(3, -1, -1):
            d = part // (10 ** i) % 10
            if d:
                s += ("" if d == 1 and i > 0 else _DIGITS[d]) + units[i]
        if s:
            out = s + big[g] + out
        g += 1
    return f"금{out}원"


def won(n):
    """5450000 → 5,450,000"""
    return format(n, ",")


def budget_amount(row):
    return row["unit"] * row["qty"] * row.get("persons", 1)


def budget_basis(row):
    """산출기초 문구: 9,000원 × 1식 × 50명"""
    s = f'{won(row["unit"])}원 × {row["qty"]}{row.get("qty_unit", "식")}'
    if row.get("persons"):
        s += f' × {row["persons"]}명'
    return s


def budget_total(budget):
    return sum(budget_amount(r) for r in budget or [])


def fmt_budget_total(budget):
    """금5,450,000원(금오백사십오만원)"""
    t = budget_total(budget)
    return f"금{won(t)}원({won_korean(t)})"


# ---------- 인원 ----------
def attendee_count(data):
    """참석 인원 = 주빈 1 + 참석자(배석 제외)"""
    return 1 + sum(1 for a in data["attendees"] if a.get("group", "참석") == "참석")


def staff_count(data):
    ev = data["event"]
    if ev.get("staff_count") is not None:
        return ev["staff_count"]
    return len(data.get("staff_present") or []) + sum(1 for a in data["attendees"] if a.get("group") == "배석")


def attendee_summary(data):
    """("13명(시장님, 관내 12개 대학 총장)", "※ 배석(8명) : 실·국장(본청 내 4급 간부)")"""
    ev = data["event"]
    n = ev.get("headcount") or f"{attendee_count(data)}명"
    main = f"{n}({ev['attendee_label']})" if ev.get("attendee_label") else n
    sc = staff_count(data)
    staff = ""
    if sc:
        staff = f"※ 배석({sc}명)" + (f" : {ev['staff_note']}" if ev.get("staff_note") else "")
    return main, staff


# ---------- 보고요지 ----------
def mayor_tasks(program):
    """식순의 mayor_task를 순서대로 모은다: 인사말씀, 열린토의, 기념촬영"""
    return ", ".join(p["mayor_task"] for p in program if p.get("mayor_task"))


# ---------- 한 번에 ----------
def derive(data):
    """문서 생성기가 쓰는 계산값 묶음"""
    rows, end = program_times(data["event"], data["program"])
    main, staff = attendee_summary(data)
    budget = data.get("budget") or []
    return {
        "program": rows,
        "end": end,
        "total_minutes": total_minutes(data["program"]),
        "date_text": fmt_date(data["event"]["date"]),
        "when_text": fmt_when(data["event"], end),
        "attendee_count": attendee_count(data),
        "headcount_text": data["event"].get("headcount") or f"{attendee_count(data)}명",
        "attendee_text": main,
        "staff_text": staff,
        "staff_count": staff_count(data),
        "budget_rows": [{**r, "amount": budget_amount(r), "basis": budget_basis(r)} for r in budget],
        "budget_total": budget_total(budget),
        "budget_text": fmt_budget_total(budget) if budget else "",
        "mayor_tasks": mayor_tasks(data["program"]),
    }
