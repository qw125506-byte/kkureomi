# -*- coding: utf-8 -*-
"""HWPX 공통 도구 — 원본 양식을 열고, 글자·표 행을 바꾸고, 원본 서식 그대로 저장한다.

기본 도구(글자 칸 교체, 표 행 복제, 사용하지 않는 그림 정리 등)는 이미 검증된
간담회개최계획-hwpx/scripts/build_plan.py 것을 그대로 가져다 쓴다(복사하지 않음).
"""
import copy
import importlib.util
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from lxml import etree

ROOT = Path(__file__).resolve().parent.parent
TEMPLATES = ROOT / "templates"

_spec = importlib.util.spec_from_file_location("build_plan", ROOT / "간담회개최계획-hwpx" / "scripts" / "build_plan.py")
bp = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(bp)

N, HP, HH, OPF, Q = bp.N, bp.HP, bp.HH, bp.OPF, bp.Q
BuildError = bp.BuildError
# build_plan 도구 다시 내보내기
set_only, set_value, set_cell_lines, clone, insert_after, remove = (
    bp.set_only, bp.set_value, bp.set_cell_lines, bp.clone, bp.insert_after, bp.remove)
find_tbl, owner_p, cell, cell_ps, tr_cells, renumber, rebuild_rows, row_height, merge_same = (
    bp.find_tbl, bp.owner_p, bp.cell, bp.cell_ps, bp.tr_cells, bp.renumber, bp.rebuild_rows, bp.row_height, bp.merge_same)
p_text, text_ts, set_t, t_text, drop_lineseg, all_text, plain_twin, bf_image = (
    bp.p_text, bp.text_ts, bp.set_t, bp.t_text, bp.drop_lineseg, bp.all_text, bp.plain_twin, bp.bf_image)


# ---------- 글자 ----------
def runs(p):
    """문단 바로 아래 run 목록"""
    return p.findall("hp:run", N)


def run_text(r):
    return "".join(t_text(t) for t in r.findall("hp:t", N))


def set_run(r, s):
    ts = r.findall("hp:t", N)
    if not ts:
        ts = [etree.SubElement(r, Q("t"))]
    set_t(ts[0], s)
    for t in ts[1:]:
        set_t(t, "")


def set_runs(p, values, expect=None):
    """values: {run 번호: 글}. expect: {run 번호: 들어 있어야 할 글 조각} — 양식이 바뀌면 바로 알 수 있게."""
    rs = runs(p)
    for i, frag in (expect or {}).items():
        if i >= len(rs) or frag not in run_text(rs[i]):
            raise BuildError(f"양식 확인 실패: run {i}에 「{frag}」가 없습니다 (문단: {p_text(p)[:40]!r})")
    for i, s in values.items():
        set_run(rs[i], s)
    drop_lineseg(p)


def full_text(el):
    """요소 안 모든 글자(표 안 포함)"""
    return "".join(t_text(t) for t in el.iter(Q("t")))


def p_with(el, frag):
    """요소 안에서 frag 글이 든 첫 문단"""
    for p in el.iter(Q("p")):
        if frag in "".join(t_text(t) for t in text_ts(p)):
            return p
    raise BuildError(f"양식 확인 실패: 「{frag}」가 든 문단이 없습니다")


def expect_text(el, frag, what):
    if frag not in full_text(el):
        raise BuildError(f"양식 확인 실패: {what}에 「{frag}」가 없습니다 — templates/ 원본이 바뀌었는지 확인")


def josa(word, pair):
    """받침에 따라 조사 고르기: josa('간담회', '을/를') → '를'"""
    a, b = pair.split("/")
    ch = (word or " ").rstrip()[-1:]
    if not ch or not ("가" <= ch <= "힣"):
        return b if pair in ("을/를", "이/가", "은/는", "과/와") else a
    has = (ord(ch) - 0xAC00) % 28 != 0
    return a if has else b


def spaced(s):
    """천안시 → 천 안 시 (원본 표지의 띄어 쓴 기관명)"""
    return " ".join(s.replace(" ", ""))


# ---------- 문서 ----------
class Doc:
    """원본 HWPX 하나를 열어 section0·header·content.hpf를 다룬다."""

    def __init__(self, name):
        self.path = TEMPLATES / name
        self.zin = zipfile.ZipFile(self.path)
        raw = self.zin.read("Contents/section0.xml")
        bp._used_ids.update(re.findall(r'\bid="(\d+)"', raw.decode("utf8")))
        self.sec = etree.fromstring(raw)
        self.header = etree.fromstring(self.zin.read("Contents/header.xml"))
        bp.HEADER["root"], bp.HEADER["changed"] = self.header, False   # 자간 자동 맞춤(fit_line)이 이 문서 모양을 쓰게
        bp._spaced.clear()
        bp._paras.clear()
        self.hpf = etree.fromstring(self.zin.read("Contents/content.hpf"))
        self.warnings = []
        self.orig = self.sec.findall("hp:p", N)   # 처음 문단 목록(지우거나 끼워도 번호가 밀리지 않게 이것을 씀)

    @property
    def tops(self):
        return self.sec.findall("hp:p", N)

    def tbl(self, tid):
        return find_tbl(self.sec, tid)

    def save(self, out_path, title, photos=None, keep_layout=False):
        """photos: {원본 그림 id: 새 사진 경로}. 쓰지 않는 원본 그림은 지운다.
        keep_layout: 손대지 않은 문단의 줄 배치 캐시를 남긴다(종이 기준 글상자가 많은 결과보고용).
        기본은 모두 지워 한글이 새로 배치하게 한다(보고요지·시나리오·보도자료에서 확인한 방식)."""
        sec = self.sec
        # 줄 배치 캐시(linesegarray): 글을 바꾼 문단은 set_only/set_runs가 이미 지웠다.
        # 손대지 않은 빈 문단·글상자 문단의 캐시는 남겨야 쪽 안 흐름이 원본과 같아진다
        # (지우면 높이가 달라져 종이 기준으로 놓인 글상자 밑으로 제목·소제목이 숨는다).
        # 표가 든 문단은 행 수가 바뀌었을 수 있어 지운다.
        for p in sec.iter(Q("p")):
            if not keep_layout or p.find("hp:run/hp:tbl", N) is not None:
                drop_lineseg(p)
        left = [s for s in all_text(sec) if "\n" in s]
        if left:
            raise BuildError("문단 안에 줄바꿈이 남았습니다: %s" % left[:2])
        sec_xml = bp.ser(sec)
        removed = bp.prune_images(sec_xml.decode("utf8"), self.header, self.hpf)
        added = bp.put_photos(photos or {}, self.hpf, removed)
        t = self.hpf.find(".//opf:title", N)
        if t is not None:
            t.text = title
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        for m in self.hpf.iter("{%s}meta" % OPF):
            if m.get("name") == "ModifiedDate":
                m.text = now
        parts = {
            "Contents/section0.xml": sec_xml,
            "Contents/header.xml": bp.ser(self.header),
            "Contents/content.hpf": bp.ser(self.hpf),
            "Preview/PrvText.txt": "\r\n".join(all_text(sec))[:1000].encode("utf8"),
            "Preview/PrvImage.png": bp.white_png(),
        }
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        names = [i.filename for i in self.zin.infolist()]
        with zipfile.ZipFile(out_path, "w") as zout:
            for n in ["mimetype"] + [x for x in names if x != "mimetype"]:
                if n in removed:
                    continue
                data = parts.get(n)
                if data is None:
                    data = self.zin.read(n)
                zi = zipfile.ZipInfo(n, date_time=self.zin.getinfo(n).date_time)
                zi.compress_type = zipfile.ZIP_STORED if n == "mimetype" else zipfile.ZIP_DEFLATED
                zout.writestr(zi, data)
            for n, data in added.items():
                zi = zipfile.ZipInfo(n, date_time=datetime.now().timetuple()[:6])
                zi.compress_type = zipfile.ZIP_DEFLATED
                zout.writestr(zi, data)
        return {"path": str(out_path), "removed_images": removed, "warnings": self.warnings,
                "lines": all_text(sec)}


def read_text(path):
    """만든 HWPX에서 글자만 뽑는다(시험·일치 검사용)"""
    with zipfile.ZipFile(path) as z:
        sec = etree.fromstring(z.read("Contents/section0.xml"))
    return all_text(sec)
