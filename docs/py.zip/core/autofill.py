# -*- coding: utf-8 -*-
"""자동 작성 — 담당자가 비워 둔 문구를 채워 입력 칸을 줄인다.

- 계획서 문구: 개최 취지, 추진목적, 주요안건, 표지 주요내용
- 보도자료(행사 전 미리 배포용): 계획서 내용(행사명·일시·장소·참석·식순·취지)으로 예고 기사
AI(Claude)를 쓸 수 있으면 AI로, 아니면 정해진 문형(규칙)으로 쓴다. 이미 적힌 값은 건드리지 않는다.
숫자·날짜·이름은 행사데이터에서만 가져오고, 데이터에 없는 사실(인용문·성과 등)은 쓰지 않는다.
"""
import copy

from core import calc

AM_PM = lambda h: ("오전" if h < 12 else "오후")  # noqa: E731


def _spoken_time(hhmm):
    """14:00 → 오후 2시, 10:30 → 오전 10시 30분"""
    h, m = map(int, hhmm.split(":"))
    hh = h - 12 if h > 12 else h
    return f"{AM_PM(h)} {hh}시" + (f" {m}분" if m else "")


def _josa(word, pair):
    a, b = pair.split("/")
    ch = (word or " ").rstrip("」』”’)")[-1:]
    if not ("가" <= ch <= "힣"):
        return b
    return a if (ord(ch) - 0xAC00) % 28 else b


def _guests(data, counts=True):
    """참석 설명에서 주빈을 뺀 참석자 말. counts=False면 「20명」 같은 인원을 뺀다."""
    import re
    label = data["event"].get("attendee_label") or ""
    parts = [x.strip() for x in label.split(",") if x.strip() and "시장" not in x]
    if not counts:
        parts = [re.sub(r"\s*\d+\s*명", "", x).strip() for x in parts]
    return ", ".join(parts)


def _topic(data):
    """취지의 중심 안건: 토의 순서가 있으면 그것, 없으면 첫 안건(끝의 「등」은 뺌)"""
    disc = next((p for p in data["program"] if p.get("type") == "discussion"), None)
    t = (disc.get("desc") or disc["item"]) if disc else _middle_items(data)[0]
    return t[:-2] if t.endswith(" 등") else t


def _middle_items(data):
    """여는·닫는 순서를 뺀 식순(안건이 될 만한 것)"""
    items = [p["item"] for p in data["program"]]
    skip = ("개회", "폐회", "마무리", "인사말씀", "기념촬영", "참석자 소개")
    mid = [i for i in items if not any(s in i for s in skip)]
    return mid or items


# ---------- 규칙 ----------
def rule_plan_text(data):
    ev = data["event"]
    mid = _middle_items(data)
    guests = _guests(data, counts=False) or "참석자"
    topic = _topic(data)
    intent = f"{guests}{_josa(guests, '과/와')} 함께 {topic}{_josa(topic, '을/를')} 통해 현장 의견을 듣고 협력 방안을 논의하고자 함."
    return {
        "intent": intent,
        "purpose": [f"{guests}{_josa(guests, '과/와')}의 소통 자리를 마련하여 현장 의견을 직접 청취",
                    f"{topic}{_josa(topic, '을/를')} 통한 협력 기반 강화"],
        "agenda": mid,
        "summary": ", ".join(mid[:2]) + " 등",
    }


PRESS_PARAS = 9            # 보도자료 본문은 늘 이 아홉 문단(견본 구조): 개최·참석·진행·보고·토의·안건·목적·후속·맺음


def _kind(title):
    """행사 이름의 끝말(간담회·회의 …). 모르면 「행사」"""
    last = (title or "").split()[-1] if (title or "").split() else ""
    return last if last.endswith(("간담회", "회의", "설명회", "토론회", "행사", "협의회", "포럼", "세미나")) else "행사"


def _ko_headcount(text):
    """「30명 내외」→「30여 명」, 「13명」→「13명」"""
    import re
    m = re.match(r"\s*(\d+)\s*명\s*(내외|여|안팎)?", text or "")
    if not m:
        return text or ""
    return f"{m.group(1)}여 명" if m.group(2) else f"{m.group(1)}명"


def _rel_day(due, base):
    """기한 날짜를 보도문 말로: 같은 달 → 「이달 28일」, 다음 달 → 「다음 달 6일」, 그 밖 → 「12월 3일」"""
    import re
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", due or "")
    if not m:
        return re.sub(r"\s+", "", due or "")           # 「연     중」→「연중」
    y, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
    diff = (y - base[0]) * 12 + mo - base[1]
    return {0: f"이달 {dd}일", 1: f"다음 달 {dd}일"}.get(diff, f"{mo}월 {dd}일")


def _plain(s):
    import re
    return re.sub(r"\s+", " ", re.sub(r"\s*\([^)]*\)", "", s or "")).strip()


def _clause(intent):
    """취지 문장(「…하고자 함.」)을 기사 말로: 「…논의하기 위해」"""
    t = (intent or "").strip()
    return (t[:-len("하고자 함.")] + "하기 위해") if t.endswith("하고자 함.") else t.rstrip(".")


def _kind_of(item):
    """식순 이름으로 순서의 성격: video / report / talk / mayor / close / open"""
    if any(w in item for w in ("동영상", "영상")):
        return "video"
    if any(w in item for w in ("토의", "토론", "청취", "수렴", "건의")):
        return "talk"
    if any(w in item for w in ("보고", "안내", "소개", "설명", "발표")) and "참석자" not in item:
        return "report"
    if "말씀" in item:
        return "mayor"
    if any(w in item for w in ("폐회", "촬영")):
        return "close"
    return "open" if any(w in item for w in ("개회", "참석자")) else "report"


def _da(line):
    """회의록 줄(「…함」「…하겠음」)을 기사 말(「…한다」「…하겠다」)로"""
    t = (line or "").strip().rstrip(".")
    for a, b in (("어려움", "어렵다"), ("쉬움", "쉽다"), ("요청함", "요청했다"), ("건의함", "건의했다"),
                 ("겠음", "겠다"), ("었음", "었다"), ("했음", "했다"), ("있음", "있다"), ("없음", "없다"), ("많음", "많다"), ("높음", "높다")):
        if t.endswith(a):
            return t[:-len(a)] + b
    if t.endswith("함"):
        return t[:-1] + "한다"
    if t.endswith("임"):
        return t[:-1] + "이다"
    if t.endswith("음"):
        return t[:-1] + "다"
    return t


def _request(title):
    """건의 제목(「입주 기간을 2년까지 연장」)을 요청 말로: 「…연장해 달라고 요청했다」"""
    t = (title or "").strip()
    if t.endswith("기"):
        return f"{t}{_josa(t, '을/를')} 요청했다"
    return f"{t}해 달라고 요청했다"


def _suggest_sentence(org, items):
    """한 기관의 건의(1~2개)를 한 문장으로: 「그린로직은 …다며 …해 달라고 요청하고, … 건의했다.」"""
    first = items[0]
    ctx = next((x for x in first.get("detail") or [] if not x.rstrip(".").endswith(("요청함", "건의함"))), "")
    head = f"{org}{_josa(org, '은/는')} "
    s = head + (f"{_da(ctx)}며 " if ctx else "") + _request(first["title"])
    if len(items) > 1:
        s = s[:-len("요청했다")] + "요청하고, " + _request(items[1]["title"]).replace("요청했다", "건의했다")
    return s + "."


def _result_press(data, kind, pos):
    """회의록에서 읽은 결과(data.result)로 ④~⑧을 쓴다: 건의 문단 셋, 시 답변, 시장 발언"""
    res = data.get("result") or {}
    sugg = [x for x in res.get("suggestions") or [] if x.get("title")]
    if not sugg:
        return None
    orgs = list(dict.fromkeys(x["org"] for x in sugg))
    by = {o: [x for x in sugg if x["org"] == o] for o in orgs}
    lead = [_suggest_sentence(o, by[o][:2]) for o in orgs[:4]]
    first = lead[:2]
    second = lead[2:4]
    used = {id(x) for o in orgs[:4] for x in by[o][:2]}
    rest = [x["title"] for x in sugg if id(x) not in used][:5]
    p4 = "참석자들이 가장 먼저 꺼낸 이야기는 현장의 애로였다. " + " ".join(first) if first else ""
    p5 = (("건의는 이어졌다. " + " ".join(second)) if second else "")
    p6 = (f"이 밖에도 {' '.join('▲' + t for t in rest)} 등 모두 {len(sugg)}건의 건의가 이어졌다." if rest
          else f"이날 {kind}에서는 모두 {len(sugg)}건의 건의가 나왔다.")
    ms = [x for x in res.get("mayor_summary") or [] if x]
    ans = [x for x in ms if "하겠" in x][:2]
    p7 = (f"시는 이 자리에서 {', '.join(_da(x)[:-1] + '다고' for x in ans)} 답했다."
          if ans else "시는 이날 나온 건의를 관련 부서와 검토해 답변하겠다고 밝혔다.")
    return [p4, p5, p6, p7], ms


def rule_press(data):
    """행사 종료 시점 기준의 결과형 보도자료(규칙). 늘 같은 아홉 문단(PRESS_PARAS)으로 쓴다.
    계획·식순·참석·취지·후속조치(데이터)에 있는 사실만 풀어 쓴다 — 데이터에 없는 건의 내용·숫자·발언 인용은 만들지 않는다."""
    ev, org, d = data["event"], data["org"], data["derived"]
    y, m, dd = map(int, ev["date"].split("-"))
    city, host = org["city"], data["host"]
    title = f"{ev['slogan']} {ev['title']}".strip() if ev.get("slogan") else ev["title"]
    kind = _kind(ev["title"])
    stem = city[:-1] if city.endswith("시") else city                # 천안시장 → 시장(「시는 … 시장 주재로」)
    pos = host["position"].replace(stem, "", 1).strip() or host["position"]
    guests = _guests(data, counts=False)
    nouns = "·".join(x.strip() for x in guests.split(",") if x.strip() and "공무원" not in x) or guests
    n = _ko_headcount(d["headcount_text"])
    venue = ev.get("venue_short") or ev["venue"]
    rows = d["program"]

    # 제목·부제(한 줄 길이): 견본 「천안시, "…"… …」 / 「- 청년 창업가·지원기관 30여 명과 …간담회 -」
    head = f"{city}, {title}"
    ptitle = head if len(head) <= 36 else f"{city}, {ev['title']}"
    subtitle = f"{nouns} {n}{_josa(n, '과/와')} {ev['title']}" if nouns else f"{city}, {m}월 {dd}일 {venue}"

    orgs = [a["org"].replace("㈜", "").replace("(주)", "").strip() for a in data.get("attendees") or []]
    orgs = list(dict.fromkeys(x for x in orgs if x))
    staff = list(dict.fromkeys(x["position"] for x in data.get("staff_present") or []))
    mid = [_plain(x).removesuffix(" 등").strip() for x in _middle_items(data)]
    mid = [x for x in mid if x]
    flow = (f"{mid[0]}에 이어 {', '.join(mid[1:])}" if len(mid) > 1 else mid[0]) if mid else "준비한 순서"
    agenda = [_plain(x).removesuffix(" 등") for x in (ev.get("agenda") or mid)]
    purposes = [_plain(x) for x in (ev.get("purpose") or [])]
    mayor_tasks = d.get("mayor_tasks") or ""
    fu = data.get("follow_up") or []

    def lead_of(r):
        who = (r.get("lead") or "").split(",")[0].strip()
        return pos if who == "시장님" else who

    reports = [r for r in rows if _kind_of(r["item"]) in ("video", "report") and r.get("type") != "attendees"]
    talks = [r for r in rows if _kind_of(r["item"]) == "talk" or r.get("type") == "discussion"]

    # ① 개최(리드): 육하원칙 + 취지
    why = _clause(ev.get("intent") or "") or f"{ev['title']}의 취지를 살리기 위해"
    p1 = (f"시는 {m}월 {dd}일 {ev['venue']}에서 {pos} 주재로 '{title}'{_josa(title, '을/를')} 열었다고 밝혔다. "
          f"이번 {kind}는 {why} 마련됐다.")
    # ② 참석
    shown = ", ".join(orgs[:8])
    p2 = (f"이날 {kind}에는 {shown + (' 등 ' if shown else '')}{guests} {n}이 참석했다." if guests
          else f"이날 {kind}에는 {n}이 참석했다.")
    if staff:
        p2 += f" 시에서는 {', '.join(staff[:6])} 등 관계 공무원이 배석해 현장의 목소리를 함께 들었다."
    # ③ 진행과 시장의 역할
    p3 = f"{kind}{_josa(kind, '은/는')} {flow} 순으로 {calc.fmt_duration(d['total_minutes'])} 동안 진행됐다."
    if mayor_tasks:
        p3 += f" {host['name']} {pos}은 {mayor_tasks} 순서에 직접 나서 참석자들과 소통했다."
    # ④ 보고·영상
    sents = []
    for r in reports[:3]:
        who = lead_of(r)
        item = _plain(r["item"]).removesuffix(" 등")
        if _kind_of(r["item"]) == "video":
            sents.append(f"참석자들은 '{item}' 순서에서 {r['minutes']}분간 영상을 함께 시청하며 시의 정책 방향을 공유했다.")
        else:
            sents.append(f"'{item}' 순서는 {who + '이 ' if who else ''}{r['minutes']}분간 맡아 시의 추진 상황과 계획을 설명했다.")
    p4 = " ".join(sents) or f"본 순서에 앞서 {kind}의 취지와 진행 순서가 참석자들에게 안내됐다."
    # ⑤ 토의
    if talks:
        r = talks[0]
        topic = _plain(r.get("desc") or r["item"]).removesuffix(" 등")
        who = lead_of(r)
        p5 = (f"이어진 '{topic}' 순서에서는 {who + ' 주재로 ' if who else ''}{r['minutes']}분 동안 "
              f"{nouns + ' 등 ' if nouns else ''}참석자들이 현장의 의견을 허심탄회하게 나눴다.")
        if len(talks) > 1:
            p5 += f" 이어 '{_plain(talks[1]['item'])}' 순서도 {talks[1]['minutes']}분간 이어졌다."
    else:
        p5 = f"{kind}에서는 참석자들이 현장의 의견을 자유롭게 나누는 시간도 마련됐다."
    # ⑥ 안건
    p6 = (f"이날 다룬 주요 안건은 {', '.join(agenda[:4])} 등이다." if agenda
          else f"이날 {kind}에서는 {ev.get('summary', '')} 등을 다뤘다.")
    # ⑦ 목적
    if purposes:
        goals = ", ".join(purposes[:2])
        tail = " 두 가지를" if len(purposes) > 1 else _josa(goals, "을/를")
        p7 = f"시는 이번 {kind}의 목적으로 {goals}{tail} 들었다."
    else:
        p7 = f"시는 이번 {kind}를 통해 현장의 의견을 직접 듣는 소통의 자리를 이어 가겠다는 입장이다."
    # ⑧ 후속 조치
    if fu:
        steps = []
        for x in fu:
            task = _plain(x.get("task"))
            steps.append(f"{_rel_day(x.get('due'), (y, m))}까지 {task}" if x.get("due") and "-" in x["due"] else
                         f"{_rel_day(x.get('due'), (y, m))} {task}" if x.get("due") else task)
        p8 = f"시는 이날 나온 의견을 후속 조치로 이어 가기 위해 {', '.join(steps)} 등의 일정을 차례로 추진한다."
    else:
        p8 = "시는 이날 나온 의견을 관련 부서와 검토해 시정에 반영해 나갈 방침이다."
    # ⑨ 맺음
    who9 = nouns or "시민"
    p9 = f"시는 앞으로도 {who9}{_josa(who9, '과/와')} 소통하는 자리를 꾸준히 마련해 현장의 목소리가 시정에 반영되도록 힘쓸 방침이다."
    rp = _result_press(data, kind, pos)
    if rp:                                                             # 회의록(결과)이 있으면 ④~⑦·시장 발언을 실제 내용으로
        (p4, p5, p6, p7), ms = rp
        end = (data.get("result") or {}).get("actual_end")
        if end:                                                        # 실제 끝난 시각으로 진행 시간을 다시 계산
            real = calc.to_min(end) - calc.to_min(ev["start"])
            if real > 0:
                p3 = p3.replace(calc.fmt_duration(d["total_minutes"]), calc.fmt_duration(real))
        if ms:
            first = _da(ms[0])
            if len(ms) > 1:
                last = _da(ms[-1])
                pm = f"{host['name']} {pos}은 {first}며 {last[:-1]}다고 강조했다.".replace("다며 ", "다며 ")
                pm = f"{host['name']} {pos}은 {first[:-1]}다며 {last[:-1]}다고 강조했다."
            else:
                pm = f"{host['name']} {pos}은 {first[:-1]}다고 말했다."
        else:
            pm = p9
        return {"title": ptitle, "subtitle": subtitle, "body": [p1, p2, p3, p4, p5, p6, p7, pm, p8]}
    return {"title": ptitle, "subtitle": subtitle, "body": [p1, p2, p3, p4, p5, p6, p7, p8, p9]}


# ---------- 채우기 ----------
def autofill(data, use_ai=None):
    """비어 있는 문구를 채운 새 데이터와 메모 목록을 돌려준다. data는 load_event() 결과(derived 포함)."""
    from ai import client as aic
    out = copy.deepcopy(data)
    ev = out["event"]
    notes = []
    use_ai = aic.available() if use_ai is None else use_ai

    need_plan = [k for k in ("intent", "purpose", "agenda", "summary") if not ev.get(k)]
    if need_plan:
        filled, how = None, "규칙"
        if use_ai:
            try:
                from ai.extract import write_intent
                r = write_intent(out)
                filled = rule_plan_text(out)
                filled.update({k: r[k] for k in ("intent", "summary") if r.get(k)})
                how = "AI"
            except Exception as e:  # noqa: BLE001 — AI가 안 되면 규칙으로
                notes.append(f"AI 문구 작성 실패({type(e).__name__}) — 규칙 문형으로 작성")
        filled = filled or rule_plan_text(out)
        for k in need_plan:
            ev[k] = filled[k]
        notes.append(f"계획서 문구({', '.join(need_plan)})를 자동 작성({how}) — 확인 필요")

    press = out.get("press") or {}
    if not press.get("body"):
        out["press"] = {**press, **rule_press(out)}                # 늘 같은 구조여야 해서 AI가 아닌 규칙으로 씀
        notes.append("행사 종료 시점 기준의 '결과형 보도자료'를 계획 내용으로 미리 작성(규칙)")
    return out, notes
