# -*- coding: utf-8 -*-
"""자동 작성 — 담당자가 비워 둔 문구를 채워 입력 칸을 줄인다.

- 계획서 문구: 개최 취지, 추진목적, 주요안건, 표지 주요내용
- 보도자료(행사 전 미리 배포용): 계획서 내용(행사명·일시·장소·참석·식순·취지)으로 예고 기사
AI(Claude)를 쓸 수 있으면 AI로, 아니면 정해진 문형(규칙)으로 쓴다. 이미 적힌 값은 건드리지 않는다.
숫자·날짜·이름은 행사데이터에서만 가져오고, 데이터에 없는 사실(인용문·성과 등)은 쓰지 않는다.
"""
import copy

from core import calc

AM_PM = lambda h: ("오전" if h < 12 else "오후")  # noqa: E731


def _spoken_time(hhmm):
    """14:00 → 오후 2시, 10:30 → 오전 10시 30분"""
    h, m = map(int, hhmm.split(":"))
    hh = h - 12 if h > 12 else h
    return f"{AM_PM(h)} {hh}시" + (f" {m}분" if m else "")


def _josa(word, pair):
    a, b = pair.split("/")
    ch = (word or " ").rstrip("」』”’)")[-1:]
    if not ("가" <= ch <= "힣"):
        return b
    return a if (ord(ch) - 0xAC00) % 28 else b


def _guests(data, counts=True):
    """참석 설명에서 주빈을 뺀 참석자 말. counts=False면 「20명」 같은 인원을 뺀다."""
    import re
    label = data["event"].get("attendee_label") or ""
    parts = [x.strip() for x in label.split(",") if x.strip() and "시장" not in x]
    if not counts:
        parts = [re.sub(r"\s*\d+\s*명", "", x).strip() for x in parts]
    return ", ".join(parts)


def _topic(data):
    """취지의 중심 안건: 토의 순서가 있으면 그것, 없으면 첫 안건(끝의 「등」은 뺌)"""
    disc = next((p for p in data["program"] if p.get("type") == "discussion"), None)
    t = (disc.get("desc") or disc["item"]) if disc else _middle_items(data)[0]
    return t[:-2] if t.endswith(" 등") else t


def _middle_items(data):
    """여는·닫는 순서를 뺀 식순(안건이 될 만한 것)"""
    items = [p["item"] for p in data["program"]]
    skip = ("개회", "폐회", "마무리", "인사말씀", "기념촬영", "참석자 소개")
    mid = [i for i in items if not any(s in i for s in skip)]
    return mid or items


# ---------- 규칙 ----------
def rule_plan_text(data):
    ev = data["event"]
    mid = _middle_items(data)
    guests = _guests(data, counts=False) or "참석자"
    topic = _topic(data)
    intent = f"{guests}{_josa(guests, '과/와')} 함께 {topic}{_josa(topic, '을/를')} 통해 현장 의견을 듣고 협력 방안을 논의하고자 함."
    return {
        "intent": intent,
        "purpose": [f"{guests}{_josa(guests, '과/와')}의 소통 자리를 마련하여 현장 의견을 직접 청취",
                    f"{topic}{_josa(topic, '을/를')} 통한 협력 기반 강화"],
        "agenda": mid,
        "summary": ", ".join(mid[:2]) + " 등",
    }


def rule_press(data):
    """행사 전 예고 보도자료(규칙). 인용문은 만들지 않는다."""
    ev, org, d = data["event"], data["org"], data["derived"]
    y, m, dd = map(int, ev["date"].split("-"))
    city, title = org["city"], ev["title"]
    host = data["host"]
    guests = _guests(data)
    who = f"{host['position']}{_josa(host['position'], '과/와')} {guests} 등" if guests else host["position"]
    head = f"{ev['slogan']} " if ev.get("slogan") else ""
    body = [f"{city}{_josa(city, '은/는')} {m}월 {dd}일 {_spoken_time(ev['start'])} {ev['venue']}에서 {who}이 참석한 가운데 "
            f"「{title}」{_josa(title, '을/를')} 개최한다고 밝혔다."]
    intent = (ev.get("intent") or "").strip()
    if intent.endswith("하고자 함."):
        body.append(f"이번 간담회는 {intent[:-len('하고자 함.')]}하기 위해 마련됐다.")
    mid = _middle_items(data)
    if mid:
        mid = [x[:-2] if x.endswith(" 등") else x for x in mid]
        body.append(f"간담회는 {', '.join(mid)} 순으로 {calc.fmt_duration(d['total_minutes'])} 동안 진행될 예정이다.")
    if data.get("follow_up"):
        body.append(f"{city}{_josa(city, '은/는')} 간담회에서 나온 의견을 관련 부서와 검토해 시정에 반영할 계획이다.")
    return {
        "title": f"{head}{title} 개최".strip(),
        "subtitle": f"{city}, {m}월 {dd}일 {ev.get('venue_short') or ev['venue']}에서 {d['headcount_text']} 참석",
        "body": body,
    }


# ---------- 채우기 ----------
def autofill(data, use_ai=None):
    """비어 있는 문구를 채운 새 데이터와 메모 목록을 돌려준다. data는 load_event() 결과(derived 포함)."""
    from ai import client as aic
    out = copy.deepcopy(data)
    ev = out["event"]
    notes = []
    use_ai = aic.available() if use_ai is None else use_ai

    need_plan = [k for k in ("intent", "purpose", "agenda", "summary") if not ev.get(k)]
    if need_plan:
        filled, how = None, "규칙"
        if use_ai:
            try:
                from ai.extract import write_intent
                r = write_intent(out)
                filled = rule_plan_text(out)
                filled.update({k: r[k] for k in ("intent", "summary") if r.get(k)})
                how = "AI"
            except Exception as e:  # noqa: BLE001 — AI가 안 되면 규칙으로
                notes.append(f"AI 문구 작성 실패({type(e).__name__}) — 규칙 문형으로 작성")
        filled = filled or rule_plan_text(out)
        for k in need_plan:
            ev[k] = filled[k]
        notes.append(f"계획서 문구({', '.join(need_plan)})를 자동 작성({how}) — 확인 필요")

    press = out.get("press") or {}
    if not press.get("body"):
        how, p = "규칙", None
        if use_ai:
            try:
                from ai.extract import write_press
                p = write_press({k: v for k, v in out.items() if k != "result"})   # 행사 전 예고 기사
                how = "AI"
            except Exception as e:  # noqa: BLE001
                notes.append(f"AI 보도자료 작성 실패({type(e).__name__}) — 규칙 문형으로 작성")
        out["press"] = {**press, **(p or rule_press(out))}
        notes.append(f"보도자료(행사 전 예고)를 계획 내용으로 자동 작성({how}) — 배포 전 확인 필요")
    return out, notes
