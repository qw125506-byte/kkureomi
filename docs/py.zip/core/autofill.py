# -*- coding: utf-8 -*-
"""자동 작성 — 담당자가 비워 둔 문구를 채워 입력 칸을 줄인다.

- 계획서 문구: 개최 취지, 추진목적, 주요안건, 표지 주요내용
- 보도자료(행사 전 미리 배포용): 계획서 내용(행사명·일시·장소·참석·식순·취지)으로 예고 기사
AI(Claude)를 쓸 수 있으면 AI로, 아니면 정해진 문형(규칙)으로 쓴다. 이미 적힌 값은 건드리지 않는다.
숫자·날짜·이름은 행사데이터에서만 가져오고, 데이터에 없는 사실(인용문·성과 등)은 쓰지 않는다.
"""
import copy

from core import calc

AM_PM = lambda h: ("오전" if h < 12 else "오후")  # noqa: E731


def _spoken_time(hhmm):
    """14:00 → 오후 2시, 10:30 → 오전 10시 30분"""
    h, m = map(int, hhmm.split(":"))
    hh = h - 12 if h > 12 else h
    return f"{AM_PM(h)} {hh}시" + (f" {m}분" if m else "")


def _josa(word, pair):
    a, b = pair.split("/")
    ch = (word or " ").rstrip("」』”’)")[-1:]
    if not ("가" <= ch <= "힣"):
        return b
    return a if (ord(ch) - 0xAC00) % 28 else b


def _guests(data, counts=True):
    """참석 설명에서 주빈을 뺀 참석자 말. counts=False면 「20명」 같은 인원을 뺀다."""
    import re
    label = data["event"].get("attendee_label") or ""
    parts = [x.strip() for x in label.split(",") if x.strip() and "시장" not in x]
    if not counts:
        parts = [re.sub(r"\s*\d+\s*명", "", x).strip() for x in parts]
    return ", ".join(parts)


def _topic(data):
    """취지의 중심 안건: 토의 순서가 있으면 그것, 없으면 첫 안건(끝의 「등」은 뺌)"""
    disc = next((p for p in data["program"] if p.get("type") == "discussion"), None)
    t = (disc.get("desc") or disc["item"]) if disc else _middle_items(data)[0]
    return t[:-2] if t.endswith(" 등") else t


def _middle_items(data):
    """여는·닫는 순서를 뺀 식순(안건이 될 만한 것)"""
    items = [p["item"] for p in data["program"]]
    skip = ("개회", "폐회", "마무리", "인사말씀", "기념촬영", "참석자 소개")
    mid = [i for i in items if not any(s in i for s in skip)]
    return mid or items


# ---------- 규칙 ----------
def rule_plan_text(data):
    ev = data["event"]
    mid = _middle_items(data)
    guests = _guests(data, counts=False) or "참석자"
    topic = _topic(data)
    intent = f"{guests}{_josa(guests, '과/와')} 함께 {topic}{_josa(topic, '을/를')} 통해 현장 의견을 듣고 협력 방안을 논의하고자 함."
    return {
        "intent": intent,
        "purpose": [f"{guests}{_josa(guests, '과/와')}의 소통 자리를 마련하여 현장 의견을 직접 청취",
                    f"{topic}{_josa(topic, '을/를')} 통한 협력 기반 강화"],
        "agenda": mid,
        "summary": ", ".join(mid[:2]) + " 등",
    }


PRESS_PARAS = 10           # 보도자료 본문은 늘 이 열 문단(견본 구조): 개최·참석·진행·내용 넷·시 답변·시장 발언·향후계획


def _kind(title):
    """행사 이름의 끝말(간담회·회의 …). 모르면 「행사」"""
    last = (title or "").split()[-1] if (title or "").split() else ""
    return last if last.endswith(("간담회", "회의", "설명회", "토론회", "행사", "협의회", "포럼", "세미나")) else "행사"


def _ko_headcount(text):
    """「30명 내외」→「30여 명」, 「13명」→「13명」"""
    import re
    m = re.match(r"\s*(\d+)\s*명\s*(내외|여|안팎)?", text or "")
    if not m:
        return text or ""
    return f"{m.group(1)}여 명" if m.group(2) else f"{m.group(1)}명"


def _rel_day(due, base):
    """기한 날짜를 보도문 말로: 같은 달 → 「이달 28일」, 다음 달 → 「다음 달 6일」, 그 밖 → 「12월 3일」"""
    import re
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", due or "")
    if not m:
        return re.sub(r"\s+", "", due or "")           # 「연     중」→「연중」
    y, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
    diff = (y - base[0]) * 12 + mo - base[1]
    return {0: f"이달 {dd}일", 1: f"다음 달 {dd}일"}.get(diff, f"{mo}월 {dd}일")


def _plain(s):
    import re
    return re.sub(r"\s+", " ", re.sub(r"\s*\([^)]*\)", "", s or "")).strip()


def _clause(intent):
    """취지 문장(「…하고자 함.」)을 기사 말로: 「…논의하기 위해」"""
    t = (intent or "").strip()
    return (t[:-len("하고자 함.")] + "하기 위해") if t.endswith("하고자 함.") else t.rstrip(".")


def _kind_of(item):
    """식순 이름으로 순서의 성격: video / report / talk / mayor / close / open"""
    if any(w in item for w in ("동영상", "영상")):
        return "video"
    if any(w in item for w in ("토의", "토론", "청취", "수렴", "건의")):
        return "talk"
    if any(w in item for w in ("보고", "안내", "소개", "설명", "발표")) and "참석자" not in item:
        return "report"
    if "말씀" in item:
        return "mayor"
    if any(w in item for w in ("폐회", "촬영")):
        return "close"
    return "open" if any(w in item for w in ("개회", "참석자")) else "report"


def _da(line):
    """회의록 줄(「…함」「…하겠음」)을 기사 말(「…한다」「…하겠다」)로"""
    t = (line or "").strip().rstrip(".")
    if t.endswith("야 함"):
        return t[:-1] + "한다"
    for a, b in (("않음", "않는다"), ("어려움", "어렵다"), ("쉬움", "쉽다"), ("요청함", "요청했다"), ("건의함", "건의했다"),
                 ("겠음", "겠다"), ("었음", "었다"), ("했음", "했다"), ("있음", "있다"), ("없음", "없다"), ("많음", "많다"), ("높음", "높다")):
        if t.endswith(a):
            return t[:-len(a)] + b
    if t.endswith("함"):
        return t[:-1] + "하다"
    if t.endswith("임"):
        return t[:-1] + "이다"
    if t.endswith("음"):
        return t[:-1] + "다"
    return t


def _request(title):
    """건의 제목(「입주 기간을 2년까지 연장」)을 요청 말로: 「…연장해 달라고 요청했다」"""
    import re
    t = re.sub(r"\s*등$", "", (title or "").strip())
    if t.endswith("기") or not re.search(r"[을를]\s", t):      # 목적어가 없는 이름꼴이면 「…를 요청했다」
        return f"{t}{_josa(t, '을/를')} 요청했다"
    return f"{t}해 달라고 요청했다"


def _suggest_sentence(org, items):
    """한 기관의 건의(1~2개)를 한 문장으로: 「그린로직은 …다며 …해 달라고 요청하고, … 건의했다.」"""
    first = items[0]
    ctx = next((x for x in first.get("detail") or [] if not x.rstrip(".").endswith(("요청함", "건의함"))), "")
    s = f"{org}{_josa(org, '은/는')} " + (f"{_da(ctx)}며 " if ctx else "") + _request(first["title"])
    if len(items) > 1:
        s = s[:-len("요청했다")] + "요청하고, " + _request(items[1]["title"]).replace("요청했다", "건의했다")
    return s + "."


def _headline(data, kind):
    """제목: 견본처럼 행사의 뜻을 담은 말머리 + 함께한 사람 — 「천안시, "창업 다음 단계까지 함께"… 청년 창업가와 머리 맞대」"""
    import re
    ev, city = data["event"], data["org"]["city"]
    label = ev.get("attendee_label") or ""
    groups = [re.sub(r"\s*\d+\s*명", "", x).strip() for x in label.split(",") if x.strip() and "시장" not in x and "공무원" not in x]
    partner = re.sub(r"^관내\s*\d*\s*개?\s*", "", groups[0]).strip() if groups else "시민"
    slogan = (ev.get("slogan") or "").strip()
    if slogan.endswith("위한"):
        base = slogan[:-len("위한")].rstrip()
        base = re.sub(r"[을를]$", "", base).replace("&", "·").replace("의 ", " ")
        motto = f"{base}, 함께 만든다"
        if len(f'{city}, "{motto}"… {partner}{_josa(partner, "과/와")} 머리 맞대') > 37:      # 제목은 한 줄(견본 37자)
            motto = f"{base}, 함께"
    else:
        words = [w for w in re.sub(r"^\d{4}\s*", "", ev["title"]).split() if not w.endswith(("간담회", "회의", "행사"))]
        topic = words[0] if words else ev["title"]
        motto = f"{topic} 끝까지 함께"
    return f'{city}, "{motto}"… {partner}{_josa(partner, "과/와")} 머리 맞대'


def _attendee_sentence(data, kind, n):
    """참석 문장: 「이날 간담회에는 그린로직, … 등 청년 창업가와 천안창업지원센터, … 관계자, 관계 공무원 등 30여 명이 참석했다.」"""
    import re
    label = data["event"].get("attendee_label") or ""
    groups = [re.sub(r"\s*\d+\s*명", "", x).strip() for x in label.split(",") if x.strip() and "시장" not in x]
    people = data.get("attendees") or []

    def short(o):
        return o.replace("㈜", "").replace("(주)", "").strip()
    if not people:
        return f"이날 {kind}에는 {', '.join(groups) + ' ' if groups else ''}{n}이 참석했다."
    from collections import Counter
    main_pos = Counter(a["position"] for a in people).most_common(1)[0][0]
    main = list(dict.fromkeys(short(a["org"]) for a in people if a["position"].endswith(main_pos)))
    rest = list(dict.fromkeys(short(a["org"]) for a in people if not a["position"].endswith(main_pos)))
    kinds = {o[-2:] for o in main}                       # 대학교·대학교처럼 같은 종류 기관은 한 무리(총장·부총장 섞여도)
    main += [o for o in rest if o[-2:] in kinds]
    rest = [o for o in rest if o[-2:] not in kinds]
    officials = any("공무원" in g for g in groups)
    g1 = next((g for g in groups if "공무원" not in g), "")
    parts = f"{', '.join(main[:6])}{' 등 ' if len(main) > 6 or g1 else ' '}{g1}".strip()
    if rest:
        parts += f"{_josa(g1 or main[-1], '과/와')} {', '.join(rest[:4])} 관계자"
    if officials:
        parts += ", 관계 공무원"
    tail = f"{parts} 등 {n}" if (officials or rest) else f"{parts} {n}"
    return f"이날 {kind}에는 {tail}이 참석했다."


def _result_paras(data, kind, pos, host):
    """회의록에서 읽은 결과(data.result)로 내용 문단 넷·시 답변·시장 발언을 쓴다. 없으면 None"""
    res = data.get("result") or {}
    sugg = [x for x in res.get("suggestions") or [] if x.get("title")]
    if not sugg:
        return None
    orgs = list(dict.fromkeys(x["org"] for x in sugg))
    by = {o: [x for x in sugg if x["org"] == o] for o in orgs}
    lines = [_suggest_sentence(o, by[o][:2]) for o in orgs[:6]]
    used = {id(x) for o in orgs[:6] for x in by[o][:2]}
    import re
    rest = [re.sub(r"\s*등$", "", x["title"]) for x in sugg if id(x) not in used][:5]
    p4 = "참석자들은 현장에서 겪는 애로부터 짚었다. " + " ".join(lines[:2]) if lines[:2] else ""
    p5 = "이어 건의가 잇따랐다. " + " ".join(lines[2:4]) if lines[2:4] else "참석자들의 건의는 이어졌다."
    p6 = " ".join(lines[4:6]) if lines[4:6] else "참석자들은 이 밖에도 현장에서 느낀 다양한 의견을 이어 갔다."
    p7 = (f"이 밖에도 {' '.join('▲' + t for t in rest)} 등 모두 {len(sugg)}건의 건의가 이어졌다." if rest
          else f"이날 {kind}에서는 모두 {len(sugg)}건의 건의가 나왔다.")
    ms = [x for x in res.get("mayor_summary") or [] if x]
    ans = [x for x in ms if "하겠" in x][:2]
    ans = [x for x in ans if x != ms[-1]] or ans
    p8 = (f"시는 이 자리에서 {', '.join(_da(x)[:-1] + '다고' for x in ans)} 답했다."
          if ans else "시는 이날 나온 건의를 관련 부서와 검토해 답변하겠다고 밝혔다.")
    name = f"{host['name']} {host['position']}"
    q = [f'"{_da(x)}"' for x in (ms[0], ms[-1])] if len(ms) > 1 else [f'"{_da(x)}"' for x in ms[:1]]
    p9 = (f"{name}은 {q[0]}며 {q[1]}고 말했다." if len(q) > 1 else f"{name}은 {q[0]}고 말했다.") if q else ""
    return [p4, p5, p6, p7, p8, p9]


def rule_press(data):
    """행사 종료 시점 기준의 결과형 보도자료(규칙). 늘 같은 열 문단(PRESS_PARAS)으로 쓴다.
    계획·식순·참석·취지·후속조치(데이터)와 회의록에서 읽은 결과(data.result)에 있는 사실만 풀어 쓴다 —
    데이터에 없는 건의 내용·숫자·발언은 만들지 않는다."""
    ev, org, d = data["event"], data["org"], data["derived"]
    y, m, dd = map(int, ev["date"].split("-"))
    city, host = org["city"], data["host"]
    title = f"{ev['slogan']} {ev['title']}".strip() if ev.get("slogan") else ev["title"]
    kind = _kind(ev["title"])
    stem = city[:-1] if city.endswith("시") else city                # 천안시장 → 시장(「시는 … 시장 주재로」)
    pos = host["position"].replace(stem, "", 1).strip() or host["position"]
    guests = _guests(data, counts=False)
    nouns = "·".join(x.strip() for x in guests.split(",") if x.strip() and "공무원" not in x) or guests
    n = _ko_headcount(d["headcount_text"])
    venue = ev.get("venue_short") or ev["venue"]
    rows = d["program"]

    ptitle = _headline(data, kind)
    subtitle = f"{nouns} {n}{_josa(n, '과/와')} {ev['title']}" if nouns else f"{city}, {m}월 {dd}일 {venue}"

    mid = [_plain(x).removesuffix(" 등").strip() for x in _middle_items(data)]
    mid = [x for x in mid if x]
    flow = (f"{mid[0]}에 이어 {', '.join(mid[1:])}" if len(mid) > 1 else mid[0]) if mid else "준비한 순서"
    fu = data.get("follow_up") or []

    def lead_of(r):
        who = (r.get("lead") or "").split(",")[0].strip()
        return pos if who == "시장님" else who

    # ① 개최(리드) ② 참석 ③ 진행
    p1 = f"시는 {m}월 {dd}일 {ev['venue']}에서 {pos} 주재로 '{title}'{_josa(title, '을/를')} 열었다고 밝혔다."
    p2 = _attendee_sentence(data, kind, n)
    total = d["total_minutes"]
    end = (data.get("result") or {}).get("actual_end")
    if end and calc.to_min(end) > calc.to_min(ev["start"]):                # 회의록의 실제 종료 시각
        total = calc.to_min(end) - calc.to_min(ev["start"])
    p3 = f"{kind}{_josa(kind, '은/는')} {flow} 순으로 {calc.fmt_duration(total)} 동안 진행됐다."

    # ⑩ 향후계획
    if fu:
        steps = []
        for x in fu:
            task = _plain(x.get("task"))
            steps.append(f"{_rel_day(x.get('due'), (y, m))}까지 {task}" if x.get("due") and "-" in x["due"] else
                         f"{_rel_day(x.get('due'), (y, m))} {task}" if x.get("due") else task)
        p10 = f"시는 이날 나온 의견을 후속 조치로 이어 가기 위해 {', '.join(steps)} 등의 일정을 차례로 추진한다."
    else:
        p10 = "시는 이날 나온 의견을 관련 부서와 검토해 시정에 반영해 나갈 방침이다."

    rp = _result_paras(data, kind, pos, host)
    if rp:                                                              # 회의록이 있으면 ④~⑨를 실제 내용으로
        p9 = rp[5] or "시는 앞으로도 현장의 목소리가 시정에 반영되도록 힘쓸 방침이다."
        return {"title": ptitle, "subtitle": subtitle, "body": [p1, p2, p3, rp[0], rp[1], rp[2], rp[3], rp[4], p9, p10]}

    # 회의록이 없을 때: 계획·식순·취지로 쓸 수 있는 내용만(없는 건의·인용은 쓰지 않는다)
    reports = [r for r in rows if _kind_of(r["item"]) in ("video", "report") and r.get("type") != "attendees"]
    talks = [r for r in rows if _kind_of(r["item"]) == "talk" or r.get("type") == "discussion"]
    sents = []
    for r in reports[:3]:
        item = _plain(r["item"]).removesuffix(" 등")
        who = lead_of(r)
        if _kind_of(r["item"]) == "video":
            sents.append(f"참석자들은 '{item}' 순서에서 {r['minutes']}분간 영상을 함께 시청하며 시의 정책 방향을 공유했다.")
        else:
            sents.append(f"'{item}' 순서는 {who + '이 ' if who else ''}{r['minutes']}분간 맡아 시의 추진 상황과 계획을 설명했다.")
    p4 = " ".join(sents) or f"본 순서에 앞서 {kind}의 취지와 진행 순서가 참석자들에게 안내됐다."
    if talks:
        r = talks[0]
        topic = _plain(r.get("desc") or r["item"]).removesuffix(" 등")
        who = lead_of(r)
        p5 = (f"이어진 '{topic}' 순서에서는 {who + ' 주재로 ' if who else ''}{r['minutes']}분 동안 "
              f"{nouns + ' 등 ' if nouns else ''}참석자들이 현장의 의견을 허심탄회하게 나눴다.")
        if len(talks) > 1:
            p5 += f" 이어 '{_plain(talks[1]['item'])}' 순서도 {talks[1]['minutes']}분간 이어졌다."
    else:
        p5 = f"{kind}에서는 참석자들이 현장의 의견을 자유롭게 나누는 시간도 마련됐다."
    agenda = [_plain(x).removesuffix(" 등") for x in (ev.get("agenda") or mid)]
    p6 = (f"이날 다룬 주요 안건은 {', '.join(agenda[:4])} 등이다." if agenda
          else f"이날 {kind}에서는 {ev.get('summary', '')} 등을 다뤘다.")
    why = _clause(ev.get("intent") or "")
    purposes = [_plain(x) for x in (ev.get("purpose") or [])]
    if purposes:
        goals = ", ".join(purposes[:2])
        tail = " 두 가지를" if len(purposes) > 1 else _josa(goals, "을/를")
        p7 = f"시는 이번 {kind}의 목적으로 {goals}{tail} 들었다."
    else:
        p7 = f"이번 {kind}는 {why} 마련됐다." if why else f"시는 이번 {kind}를 통해 현장의 의견을 직접 듣는 소통의 자리를 이어 가겠다는 입장이다."
    p8 = (f"이번 {kind}는 {why} 마련됐다." if why else "") + f" 시는 이날 나온 현장의 목소리를 정책 수립의 기초 자료로 삼겠다는 입장이다."
    p8 = p8.strip()
    mt = d.get("mayor_tasks") or ""
    p9 = (f"{host['name']} {host['position']}은 {mt} 순서에 직접 나서 참석자들과 소통했다." if mt
          else f"시는 앞으로도 {nouns or '시민'}{_josa(nouns or '시민', '과/와')} 소통하는 자리를 꾸준히 마련할 방침이다.")
    return {"title": ptitle, "subtitle": subtitle, "body": [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10]}


# ---------- 채우기 ----------
def autofill(data, use_ai=None):
    """비어 있는 문구를 채운 새 데이터와 메모 목록을 돌려준다. data는 load_event() 결과(derived 포함)."""
    from ai import client as aic
    out = copy.deepcopy(data)
    ev = out["event"]
    notes = []
    use_ai = aic.available() if use_ai is None else use_ai

    need_plan = [k for k in ("intent", "purpose", "agenda", "summary") if not ev.get(k)]
    if need_plan:
        filled, how = None, "규칙"
        if use_ai:
            try:
                from ai.extract import write_intent
                r = write_intent(out)
                filled = rule_plan_text(out)
                filled.update({k: r[k] for k in ("intent", "summary") if r.get(k)})
                how = "AI"
            except Exception as e:  # noqa: BLE001 — AI가 안 되면 규칙으로
                notes.append(f"AI 문구 작성 실패({type(e).__name__}) — 규칙 문형으로 작성")
        filled = filled or rule_plan_text(out)
        for k in need_plan:
            ev[k] = filled[k]
        notes.append(f"계획서 문구({', '.join(need_plan)})를 자동 작성({how}) — 확인 필요")

    press = out.get("press") or {}
    if not press.get("body"):
        out["press"] = {**press, **rule_press(out)}                # 늘 같은 구조여야 해서 AI가 아닌 규칙으로 씀
        notes.append("행사 종료 시점 기준의 '결과형 보도자료'를 계획 내용으로 미리 작성(규칙)")
    return out, notes
