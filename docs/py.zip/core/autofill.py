# -*- coding: utf-8 -*-
"""자동 작성 — 담당자가 비워 둔 문구를 채워 입력 칸을 줄인다.

- 계획서 문구: 개최 취지, 추진목적, 주요안건, 표지 주요내용
- 보도자료(행사 전 미리 배포용): 계획서 내용(행사명·일시·장소·참석·식순·취지)으로 예고 기사
AI(Claude)를 쓸 수 있으면 AI로, 아니면 정해진 문형(규칙)으로 쓴다. 이미 적힌 값은 건드리지 않는다.
숫자·날짜·이름은 행사데이터에서만 가져오고, 데이터에 없는 사실(인용문·성과 등)은 쓰지 않는다.
"""
import copy

from core import calc

AM_PM = lambda h: ("오전" if h < 12 else "오후")  # noqa: E731


def _spoken_time(hhmm):
    """14:00 → 오후 2시, 10:30 → 오전 10시 30분"""
    h, m = map(int, hhmm.split(":"))
    hh = h - 12 if h > 12 else h
    return f"{AM_PM(h)} {hh}시" + (f" {m}분" if m else "")


def _josa(word, pair):
    a, b = pair.split("/")
    ch = (word or " ").rstrip("」』”’)")[-1:]
    if not ("가" <= ch <= "힣"):
        return b
    return a if (ord(ch) - 0xAC00) % 28 else b


def _guests(data, counts=True):
    """참석 설명에서 주빈을 뺀 참석자 말. counts=False면 「20명」 같은 인원을 뺀다."""
    import re
    label = data["event"].get("attendee_label") or ""
    parts = [x.strip() for x in label.split(",") if x.strip() and "시장" not in x]
    if not counts:
        parts = [re.sub(r"\s*\d+\s*명", "", x).strip() for x in parts]
    return ", ".join(parts)


def _topic(data):
    """취지의 중심 안건: 토의 순서가 있으면 그것, 없으면 첫 안건(끝의 「등」은 뺌)"""
    disc = next((p for p in data["program"] if p.get("type") == "discussion"), None)
    t = (disc.get("desc") or disc["item"]) if disc else _middle_items(data)[0]
    return t[:-2] if t.endswith(" 등") else t


def _middle_items(data):
    """여는·닫는 순서를 뺀 식순(안건이 될 만한 것)"""
    items = [p["item"] for p in data["program"]]
    skip = ("개회", "폐회", "마무리", "인사말씀", "기념촬영", "참석자 소개")
    mid = [i for i in items if not any(s in i for s in skip)]
    return mid or items


# ---------- 규칙 ----------
def rule_plan_text(data):
    ev = data["event"]
    mid = _middle_items(data)
    guests = _guests(data, counts=False) or "참석자"
    topic = _topic(data)
    intent = f"{guests}{_josa(guests, '과/와')} 함께 {topic}{_josa(topic, '을/를')} 통해 현장 의견을 듣고 협력 방안을 논의하고자 함."
    return {
        "intent": intent,
        "purpose": [f"{guests}{_josa(guests, '과/와')}의 소통 자리를 마련하여 현장 의견을 직접 청취",
                    f"{topic}{_josa(topic, '을/를')} 통한 협력 기반 강화"],
        "agenda": mid,
        "summary": ", ".join(mid[:2]) + " 등",
    }


CHECK = "[확인 필요"
PRESS_PARAS = 9            # 보도자료 본문은 늘 이 아홉 문단(견본 구조): 개최·참석·진행·논의 셋·시 답변·시장 발언·향후계획


def _kind(title):
    """행사 이름의 끝말(간담회·회의 …). 모르면 「행사」"""
    last = (title or "").split()[-1] if (title or "").split() else ""
    return last if last.endswith(("간담회", "회의", "설명회", "토론회", "행사", "협의회", "포럼", "세미나")) else "행사"


def _ko_headcount(text):
    """「30명 내외」→「30여 명」, 「13명」→「13명」"""
    import re
    m = re.match(r"\s*(\d+)\s*명\s*(내외|여|안팎)?", text or "")
    if not m:
        return text or ""
    return f"{m.group(1)}여 명" if m.group(2) else f"{m.group(1)}명"


def _rel_day(due, base):
    """기한 날짜를 보도문 말로: 같은 달 → 「이달 28일」, 다음 달 → 「다음 달 6일」, 그 밖 → 「12월 3일」"""
    import re
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", due or "")
    if not m:
        return re.sub(r"\s+", "", due or "")           # 「연     중」→「연중」
    y, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
    diff = (y - base[0]) * 12 + mo - base[1]
    return {0: f"이달 {dd}일", 1: f"다음 달 {dd}일"}.get(diff, f"{mo}월 {dd}일")


def _plain(s):
    import re
    return re.sub(r"\s+", " ", re.sub(r"\s*\([^)]*\)", "", s or "")).strip()


def rule_press(data):
    """행사 종료 시점 기준의 결과형 보도자료(규칙). 늘 같은 아홉 문단(PRESS_PARAS)으로 쓴다.
    계획·식순·참석·후속조치(데이터)로 쓸 수 있는 문단은 쓰고, 행사에서 나온 결과(건의·답변·시장 발언)는
    데이터에 있으면(result) 쓰고 없으면 [확인 필요: 무엇을 쓸지] 자리표시로 둔다 — 지어내지 않는다."""
    ev, org, d, res = data["event"], data["org"], data["derived"], data.get("result") or {}
    press = data.get("press") or {}
    y, m, dd = map(int, ev["date"].split("-"))
    city, host = org["city"], data["host"]
    title = f"{ev['slogan']} {ev['title']}".strip() if ev.get("slogan") else ev["title"]
    kind = _kind(ev["title"])
    stem = city[:-1] if city.endswith("시") else city                # 천안시장 → 시장(「시는 … 시장 주재로」)
    pos = host["position"].replace(stem, "", 1).strip() or host["position"]
    guests = _guests(data, counts=False)
    nouns = "·".join(x.strip() for x in guests.split(",") if x.strip() and "공무원" not in x) or guests
    n = _ko_headcount(d["headcount_text"])
    venue = ev.get("venue_short") or ev["venue"]

    # 제목·부제(한 줄 길이): 견본 「천안시, "…"… …」 / 「- 청년 창업가·지원기관 30여 명과 …간담회 -」
    head = f"{city}, {title}"
    ptitle = head if len(head) <= 36 else f"{city}, {ev['title']}"
    subtitle = f"{nouns} {n}{_josa(n, '과/와')} {ev['title']}" if nouns else f"{city}, {m}월 {dd}일 {venue}"

    orgs = [a["org"].replace("㈜", "").replace("(주)", "").strip() for a in data.get("attendees") or []]
    orgs = list(dict.fromkeys(x for x in orgs if x))
    shown = ", ".join(orgs[:6])
    who = shown
    mid = [_plain(x).removesuffix(" 등").strip() for x in _middle_items(data)]
    mid = [x for x in mid if x]
    flow = (f"{mid[0]}에 이어 {', '.join(mid[1:])}" if len(mid) > 1 else mid[0]) if mid else "준비한 순서"
    hints = [_plain(x).removesuffix(" 등") for x in (ev.get("agenda") or mid)]
    hint = lambda i: hints[i] if i < len(hints) else hints[-1] if hints else "주요 안건"          # noqa: E731
    contents = []                                                  # 결과보고의 회의내용 줄은 문장이 아니라 보도 문단으로 쓰지 않는다
    fu = data.get("follow_up") or []

    body = [
        f"시는 {m}월 {dd}일 {ev['venue']}에서 {pos} 주재로 '{title}'{_josa(title, '을/를')} 열었다고 밝혔다.",
        f"이날 {kind}에는 {who + ' 등 ' if who else ''}{guests} {n}이 참석했다." if guests else f"이날 {kind}에는 {n}이 참석했다.",
        f"{kind}{_josa(kind, '은/는')} {flow} 순으로 {calc.fmt_duration(d['total_minutes'])} 동안 진행됐다.",
        contents[0] if len(contents) > 0 else
        f"참석자들은 '{hint(0)}'{_josa(hint(0), '과/와')} 관련해 {CHECK}: 가장 먼저·가장 많이 나온 의견과 건의 내용]을 제기했다.",
        contents[1] if len(contents) > 1 else
        f"'{hint(1)}' 분야에서도 {CHECK}: 요구·건의 내용]이 잇따랐다.",
        contents[2] if len(contents) > 2 else
        f"이 밖에도 {CHECK}: 그 밖의 건의 항목과 건수]의 건의가 이어졌다.",
        f"시는 이날 나온 건의사항을 관련 부서와 검토해 그 결과를 참석자들에게 회신하겠다고 밝혔다."
        if any("회신" in (x.get("task") or "") for x in fu) else
        f"시는 이 자리에서 {CHECK}: 시가 밝힌 검토·답변 내용]이라고 답했다.",
    ]
    if not press.get("quote"):                                    # 시장 발언(인용문)은 데이터가 줄 때만 쓰고 없으면 자리표시
        body.append(f'{host["name"]} {host["position"]}은 "{CHECK}: 현장에서 한 발언을 그대로 옮겨 적으세요]"라고 말했다.')
    if fu:
        steps = []
        for x in fu:
            task = _plain(x.get("task"))
            steps.append(f"{_rel_day(x.get('due'), (y, m))}까지 {task}" if x.get("due") and "-" in x["due"] else
                         f"{_rel_day(x.get('due'), (y, m))} {task}" if x.get("due") else task)
        body.append(f"시는 {', '.join(steps)} 등 후속 조치를 추진해 시정에 반영해 나갈 방침이다.")
    else:
        body.append("시는 이날 나온 의견을 관련 부서와 검토해 시정에 반영해 나갈 방침이다.")
    return {"title": ptitle, "subtitle": subtitle, "body": body}


# ---------- 채우기 ----------
def autofill(data, use_ai=None):
    """비어 있는 문구를 채운 새 데이터와 메모 목록을 돌려준다. data는 load_event() 결과(derived 포함)."""
    from ai import client as aic
    out = copy.deepcopy(data)
    ev = out["event"]
    notes = []
    use_ai = aic.available() if use_ai is None else use_ai

    need_plan = [k for k in ("intent", "purpose", "agenda", "summary") if not ev.get(k)]
    if need_plan:
        filled, how = None, "규칙"
        if use_ai:
            try:
                from ai.extract import write_intent
                r = write_intent(out)
                filled = rule_plan_text(out)
                filled.update({k: r[k] for k in ("intent", "summary") if r.get(k)})
                how = "AI"
            except Exception as e:  # noqa: BLE001 — AI가 안 되면 규칙으로
                notes.append(f"AI 문구 작성 실패({type(e).__name__}) — 규칙 문형으로 작성")
        filled = filled or rule_plan_text(out)
        for k in need_plan:
            ev[k] = filled[k]
        notes.append(f"계획서 문구({', '.join(need_plan)})를 자동 작성({how}) — 확인 필요")

    press = out.get("press") or {}
    if not press.get("body"):
        out["press"] = {**press, **rule_press(out)}                # 늘 같은 구조여야 해서 AI가 아닌 규칙으로 씀
        notes.append("행사 종료 시점 기준의 '결과형 보도자료'를 계획 내용으로 미리 작성(규칙)")
    return out, notes
