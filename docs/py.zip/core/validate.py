# -*- coding: utf-8 -*-
"""검증기 — (a) 데이터 검산 (b) 만든 문서끼리·데이터와 일치 (c) 파일 구조 (d) 원본 글 잔존.

결과는 [{level: 오류|주의|통과, area, doc, item, expected, actual}] 목록이고, report_md()가 보고서로 만든다.
"""
import json
import datetime
import re
import zipfile
from pathlib import Path

from lxml import etree

from core import calc
from core.hwpx import read_text as hwpx_text

WEEK = "월화수목금토일"
DOC_NAMES = {"plan": "① 계획서", "brief": "② 보고요지", "scenario": "③ 시나리오", "press": "④ 보도자료",
             "ppt": "⑤ 진행PPT", "result": "⑥ 결과보고"}
# 원본 양식에만 있는 글(만든 문서에 남으면 원본 내용이 섞인 것)
RESIDUE = {
    "plan": [],
    "brief": ["2026년 대학 총장 초청 간담회", "연린", "글로컬"],
    "scenario": ["초정", "참식", "2026 청년정책 주요방향"],
    "press": ["유니브시티", "오륜문"],
    "result": ["2026년 대학 총장 초청 간담회", "상생·협력을 위한"],
    "ppt": ["2026. 00. 00.", "ㅇㅇㅇ"],
}
# 원본 양식 속 실명(이 PC에만 있는 목록, 배포본에는 넣지 않음 — 배포본 양식은 이름을 지워 둠)
_LOCAL = Path(__file__).with_name("residue_local.json")
if _LOCAL.exists():
    for _k, _v in json.loads(_LOCAL.read_text(encoding="utf-8")).items():
        RESIDUE.setdefault(_k, []).extend(_v)


def F(level, area, item, doc="", expected="", actual=""):
    return {"level": level, "area": area, "doc": DOC_NAMES.get(doc, doc), "item": item,
            "expected": str(expected), "actual": str(actual)}


# ---------- (a) 데이터 검산 ----------
def check_data(data):
    out, ev, d = [], data["event"], data["derived"]
    if ev.get("end") and ev["end"] != d["end"]:
        out.append(F("오류", "검산", "식순 합계와 종료 시각", "", f'{ev["start"]}~{ev["end"]}',
                     f'식순 합계 {d["total_minutes"]}분 → {d["end"]}'))
    else:
        out.append(F("통과", "검산", f'식순 {len(data["program"])}개 합계 {d["total_minutes"]}분 = {ev["start"]}~{d["end"]}'))
    for r in data.get("budget") or []:
        if r["unit"] <= 0:
            out.append(F("오류", "검산", f'예산 「{r["item"]}」 단가가 0원'))
    if data.get("budget"):
        out.append(F("통과", "검산", f'예산 {len(data["budget"])}항목 합계 {d["budget_text"]}'))
    label = ev.get("attendee_label") or ""
    m = re.search(r"(\d+)개", label)
    n_att = len([a for a in data["attendees"] if a.get("group", "참석") == "참석"])
    if m and n_att and int(m.group(1)) != n_att:
        out.append(F("주의", "검산", "참석 설명의 기관 수와 명단 수", "", f"{m.group(1)}개", f"명단 {n_att}명"))
    if ev.get("staff_count") is not None and data.get("staff_present") and ev["staff_count"] != len(data["staff_present"]):
        out.append(F("주의", "검산", "배석 인원과 배석 명단 수", "", f'{ev["staff_count"]}명', f'명단 {len(data["staff_present"])}명'))
    date = datetime.date.fromisoformat(ev["date"])
    for a in data.get("admin_tasks") or []:
        try:
            due = datetime.date.fromisoformat(a.get("due", ""))
        except ValueError:
            continue
        if due > date:
            out.append(F("주의", "검산", f'행정사항 「{a["task"]}」 기한이 행사일 뒤', "", f"~{ev['date']}", a["due"]))
    for a in data.get("follow_up") or []:
        try:
            due = datetime.date.fromisoformat(a.get("due", ""))
        except ValueError:
            continue
        if due < date:
            out.append(F("주의", "검산", f'향후계획 「{a["task"]}」 기한이 행사일 앞', "", f"{ev['date']}~", a["due"]))
    res = data.get("result") or {}
    if res.get("actual_end") and res["actual_end"] != d["end"]:
        out.append(F("통과", "검산", f'실제 종료 {res["actual_end"]} (계획 {d["end"]}) — 결과보고는 실제 시각 사용'))
    return out


# ---------- (b) 문서 간 일치 ----------
def doc_text(path):
    p = str(path)
    return "\n".join(hwpx_text(p) if p.endswith(".hwpx") else _pptx_text(p))


def _pptx_text(p):
    from generators.ppt import read_text
    return read_text(p)


def expectations(data):
    """문서마다 반드시 들어 있어야 할 값"""
    ev, d = data["event"], data["derived"]
    res = data.get("result") or {}
    venue_any = [ev["venue"]] + ([ev["venue_short"]] if ev.get("venue_short") else [])
    items = [p["item"] for p in data["program"]]
    e = {
        "plan": {"행사명": [ev["title"]], "날짜": [d["date_text"]], "시작": [ev["start"]], "종료": [d["end"]],
                 "장소": venue_any, "참석 인원": [d["headcount_text"]], "식순": items},
        "brief": {"행사명": [ev["title"]], "날짜": [d["date_text"]], "시작": [ev["start"]], "종료": [d["end"]],
                  "장소": venue_any, "참석 인원": [d["headcount_text"]], "식순": items},
        "scenario": {"행사명": [ev["title"]], "날짜": [d["date_text"]], "시작": [ev["start"]], "장소": venue_any,
                     "식순": items},
        "ppt": {"행사명": [ev["title"]], "날짜": [d["date_text"]], "시작": [ev["start"]], "장소": venue_any, "식순": items},
        "result": {"행사명": [ev["title"]], "날짜": [d["date_text"]],
                   "종료(실제)": [res.get("actual_end") or d["end"]], "참석 인원": [d["headcount_text"]]},
        "press": {},
    }
    return e


def check_docs(data, files):
    """files: {doc_key: 경로}"""
    out = []
    exp = expectations(data)
    data_text = json.dumps({k: v for k, v in data.items() if k != "derived"}, ensure_ascii=False)
    for key, path in files.items():
        t = doc_text(path)
        for what, vals in exp.get(key, {}).items():
            if what == "식순":
                flat = re.sub(r"\s+", "", t)             # 칸 폭에 맞춰 줄바꿈된 식순 이름도 같은 이름으로 본다
                miss = [v for v in vals if re.sub(r"\s+", "", v) not in flat]
                if miss:
                    out.append(F("오류", "일치", "식순 이름", key, " / ".join(vals), "없음: " + ", ".join(miss)))
                continue
            if not any(v in t for v in vals):
                out.append(F("오류", "일치", what, key, " 또는 ".join(vals), "문서에 없음"))
        # 문서 안 날짜의 요일이 맞는지
        for m in re.finditer(r"(\d{4})\. (\d{1,2})\. (\d{1,2})\.\(([월화수목금토일])\)", t):
            y, mo, dd, wd = int(m.group(1)), int(m.group(2)), int(m.group(3)), m.group(4)
            try:
                real = WEEK[datetime.date(y, mo, dd).weekday()]
            except ValueError:
                continue
            if real != wd:
                out.append(F("오류", "일치", "날짜 요일", key, f"{m.group(0)[:-3]}({real})", m.group(0)))
        # 다른 행사일 표기가 섞였는지(같은 해의 다른 날짜로 된 「일시」)
        for res_ in RESIDUE.get(key, []):
            if res_ and res_ in t and res_ not in data_text:        # 입력한 값에 있는 글이면 원본 잔존이 아님
                out.append(F("주의", "원본 잔존", f"원본 양식의 글 「{res_}」가 남음", key))
        if "[확인 필요]" in t:
            out.append(F("주의", "확인 필요", f'「[확인 필요]」 {t.count("[확인 필요]")}곳', key))
        if not any(f["doc"] == DOC_NAMES[key] and f["level"] == "오류" for f in out):
            out.append(F("통과", "일치", "공통 데이터 값과 일치", key))
    return out


# ---------- (c) 파일 구조 ----------
def check_structure(files):
    out = []
    for key, path in files.items():
        p = Path(path)
        try:
            with zipfile.ZipFile(p) as z:
                bad = z.testzip()
                if bad:
                    raise ValueError(f"압축 손상: {bad}")
                names = z.namelist()
                if p.suffix == ".hwpx":
                    if names[0] != "mimetype" or z.getinfo("mimetype").compress_type != zipfile.ZIP_STORED:
                        raise ValueError("mimetype이 첫 항목·무압축이 아님")
                    if z.read("mimetype") != b"application/hwp+zip":
                        raise ValueError("mimetype 내용 이상")
                    for n in names:
                        if n.endswith((".xml", ".hpf")):
                            etree.fromstring(z.read(n))
                else:
                    if "[Content_Types].xml" not in names:
                        raise ValueError("[Content_Types].xml 없음")
                    for n in names:
                        if n.endswith(".rels"):
                            base = n.replace("_rels/", "").replace(".rels", "")
                            folder = base.rsplit("/", 1)[0] if "/" in base else ""
                            for tgt in re.findall(r'Target="([^"]+)"', z.read(n).decode("utf-8")):
                                if tgt.startswith("http") or 'TargetMode="External"' in tgt:
                                    continue
                                full = tgt.lstrip("/") if tgt.startswith("/") else _norm(f"{folder}/{tgt}" if folder else tgt)
                                if full not in names:
                                    raise ValueError(f"관계 대상 없음: {n} → {tgt}")
                        elif n.endswith(".xml"):
                            etree.fromstring(z.read(n))
            out.append(F("통과", "구조", "파일 구조 정상", key))
        except Exception as e:  # noqa: BLE001
            out.append(F("오류", "구조", "파일 구조", key, "정상", e))
    return out


def _norm(path):
    parts = []
    for s in path.split("/"):
        if s == "..":
            if parts:
                parts.pop()
        elif s and s != ".":
            parts.append(s)
    return "/".join(parts)


def run_all(data, files):
    return check_data(data) + check_structure(files) + check_docs(data, files)


def report_md(data, files, findings, seconds=None):
    ev = data["event"]
    err = sum(f["level"] == "오류" for f in findings)
    warn = sum(f["level"] == "주의" for f in findings)
    lines = [f'# 검증 보고 — {ev["title"]}', "",
             f'- 만든 시각: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M")}',
             f"- 문서 {len(files)}종: " + ", ".join(DOC_NAMES[k] for k in files),
             f"- 결과: **오류 {err}건, 주의 {warn}건**"]
    if seconds is not None:
        lines.append(f"- 생성에 걸린 시간: {seconds:.1f}초")
    lines += ["", "| 결과 | 구분 | 문서 | 항목 | 기대값 | 실제 |", "|---|---|---|---|---|---|"]
    order = {"오류": 0, "주의": 1, "통과": 2}
    for f in sorted(findings, key=lambda f: order[f["level"]]):
        cells = [f["level"], f["area"], f["doc"], f["item"], f["expected"], f["actual"]]
        lines.append("| " + " | ".join(c.replace("|", "/").replace("\n", " ") for c in cells) + " |")
    meta = (data.get("_meta") or {}).get("확인필요") or []
    if meta:
        lines += ["", "## 데이터의 확인 필요 메모", ""] + [f"- {m}" for m in meta]
    return "\n".join(lines) + "\n"
