# -*- coding: utf-8 -*-
"""내려받는 문서 모양 그대로 보는 미리보기(HTML) — 한글·PowerPoint 없이 브라우저에서.

- HWPX: 글꼴·크기·굵기·색, 문단 정렬·줄간격·들여쓰기, 표(칸 합치기·테두리·배경), 그림(로고 등),
  글상자를 A4 쪽 모양으로 그린다. 쪽 나눔은 문서에 적힌 「쪽 나누기」 기준(자동 쪽 넘김은 한글과 다를 수 있음).
- PPTX: 장표 크기 그대로 도형·글상자·그림·배경을 제자리에 그린다.
정확한 인쇄 모양은 내려받아 한글·PowerPoint에서 확인한다(화면 안내 문구).
"""
import base64
import html
import re
import zipfile
from pathlib import Path

from lxml import etree

HP = "{http://www.hancom.co.kr/hwpml/2011/paragraph}"
HH = "{http://www.hancom.co.kr/hwpml/2011/head}"
HC = "{http://www.hancom.co.kr/hwpml/2011/core}"
PX = 75.0                     # HWPUNIT(1/7200인치) → 화면 px(96dpi)
SERIF = re.compile(r"바탕|명조|Batang|Myeongjo|신명|궁서|Times", re.I)
PUA = {"": "☑", "": "■", "": "●", "": "▪", "": "▶", "": "", "": "•"}
MIME = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif", "bmp": "image/bmp"}


def esc(s):
    return html.escape(s or "", quote=True)


def px(v):
    try:
        return round(int(float(v)) / PX, 1)
    except (TypeError, ValueError):
        return 0


# ====================================================================== HWPX
PLACED = "<!--placed-->"           # 쪽 기준으로 따로 놓았다는 표시


def fill_css(el):
    """채우기: 단색(winBrush) 또는 그러데이션(gradation) → CSS background"""
    g = el.find(".//" + HC + "gradation")
    if g is not None:
        cols = [c.get("value") for c in g.findall(HC + "color") if c.get("value")]
        if len(cols) >= 2:
            if g.get("type") in ("RADIAL", "CONICAL", "SQUARE"):
                return f"background:radial-gradient({', '.join(cols)})"
            return f"background:linear-gradient({int(g.get('angle', '0')) % 360}deg, {', '.join(cols)})"
    brush = el.find(".//" + HC + "winBrush")
    if brush is not None and brush.get("faceColor") not in (None, "none") and brush.get("alpha", "0") in ("0", ""):
        return f"background:{brush.get('faceColor')}"
    return ""


class Hwpx:
    def __init__(self, path):
        self.z = zipfile.ZipFile(path)
        self.floats, self.margin_l, self.margin_t, self.depth = [], 0, 0, 0
        self.anchors, self.anchor_top, self.margin_l_hu, self.margin_t_hu, self.content_w = [], 0, 0, 0, 0
        self.page_floats, self.seen_seg = [], False
        head = etree.fromstring(self.z.read("Contents/header.xml"))
        self.fonts = {}
        for ff in head.iter(HH + "fontface"):
            if ff.get("lang") == "HANGUL":
                self.fonts = {f.get("id"): f.get("face") for f in ff.iter(HH + "font")}
        self.char = {c.get("id"): self._char_css(c) for c in head.iter(HH + "charPr")}
        self.para = {p.get("id"): self._para_css(p) for p in head.iter(HH + "paraPr")}
        self.fill = {b.get("id"): self._fill_css(b) for b in head.iter(HH + "borderFill")}
        self.bins = {}
        hpf = etree.fromstring(self.z.read("Contents/content.hpf"))
        for it in hpf.iter("{*}item"):
            self.bins[it.get("id")] = it.get("href")

    # ---------- 글자·문단·테두리 모양 → CSS
    def _char_css(self, c):
        css = [f"font-size:{int(c.get('height', '1000')) / 100:.1f}pt"]
        col = c.get("textColor")
        if col and col not in ("#000000", "none"):
            css.append(f"color:{col}")
        ref = c.find(HH + "fontRef")
        face = self.fonts.get(ref.get("hangul")) if ref is not None else None
        if face:
            fb = "'HCR Batang','함초롬바탕','Batang',serif" if SERIF.search(face) else "'Malgun Gothic','맑은 고딕',sans-serif"
            css.append(f"font-family:'{face}',{fb}")
        if c.find(HH + "bold") is not None:
            css.append("font-weight:700")
        if c.find(HH + "italic") is not None:
            css.append("font-style:italic")
        ul = c.find(HH + "underline")
        if ul is not None and ul.get("type", "NONE") != "NONE":
            css.append("text-decoration:underline")
        sp = c.find(HH + "spacing")
        if sp is not None and sp.get("hangul", "0") not in ("0", ""):
            css.append(f"letter-spacing:{int(sp.get('hangul')) / 100:.2f}em")
        ratio = c.find(HH + "ratio")
        if ratio is not None and ratio.get("hangul", "100") not in ("100", ""):
            css.append(f"font-stretch:{max(50, min(200, int(ratio.get('hangul'))))}%")
        shade = c.get("shadeColor")
        if shade and shade not in ("none", "#FFFFFF"):
            css.append(f"background:{shade}")
        return ";".join(css)

    def _para_css(self, p):
        css = []
        al = p.find(HH + "align")
        h = (al.get("horizontal") if al is not None else "JUSTIFY") or "JUSTIFY"
        css.append({"CENTER": "text-align:center", "RIGHT": "text-align:right", "LEFT": "text-align:left",
                    "DISTRIBUTE": "text-align:justify;text-align-last:justify",
                    "DISTRIBUTE_SPACE": "text-align:justify;text-align-last:justify"}.get(h, "text-align:justify"))
        m = p.find(".//" + HH + "margin")
        if m is not None:
            get = {etree.QName(x).localname: int(x.get("value", "0")) for x in m}
            if get.get("left"):
                css.append(f"padding-left:{get['left'] / PX:.1f}px")
            if get.get("right"):
                css.append(f"padding-right:{get['right'] / PX:.1f}px")
            if get.get("intent"):
                css.append(f"text-indent:{get['intent'] / PX:.1f}px")
            if get.get("prev"):
                css.append(f"margin-top:{get['prev'] / PX / 2:.1f}px")
            if get.get("next"):
                css.append(f"margin-bottom:{get['next'] / PX / 2:.1f}px")
        ls = p.find(".//" + HH + "lineSpacing")
        if ls is not None and ls.get("type", "PERCENT") == "PERCENT":
            css.append(f"line-height:{max(100, int(ls.get('value', '160'))) / 100 * 1.0:.2f}")
        return ";".join(css)

    def _fill_css(self, b):
        css = []
        for side in ("left", "right", "top", "bottom"):
            e = b.find(HH + f"{side}Border")
            if e is None or e.get("type", "NONE") == "NONE":
                continue
            w = float(re.sub(r"[^\d.]", "", e.get("width", "0.1")) or 0.1)
            wpx = max(1, round(w * 3.78))
            style = {"DOUBLE": "double", "DASH": "dashed", "DOT": "dotted"}.get(e.get("type"), "solid")
            if style == "double":
                wpx = max(3, wpx)
            css.append(f"border-{side}:{wpx}px {style} {e.get('color', '#000')}")
        bg = fill_css(b)
        if bg:
            css.append(bg)
        return ";".join(css)

    # ---------- 그림
    def img(self, pic, block=False):
        im = pic.find(".//" + HC + "img")
        if im is None:
            return ""
        href = self.bins.get(im.get("binaryItemIDRef"))
        if not href:
            return ""
        ext = href.rsplit(".", 1)[-1].lower()
        if ext not in MIME:
            return ""
        try:
            data = self.z.read(href)
        except KeyError:
            return ""
        sz = pic.find(HP + "sz")
        if sz is None:
            sz = pic.find(HP + "curSz")
        w = px(sz.get("width")) if sz is not None else 0
        h = px(sz.get("height")) if sz is not None else 0
        style = f"width:{w}px;" if w else ""
        style += f"height:{h}px;" if h else ""
        src = f"data:{MIME[ext]};base64,{base64.b64encode(data).decode()}"
        return f'<img src="{src}" style="{style}{"display:block;" if block else ""}" alt="">'

    # ---------- 문단·표·글상자
    @staticmethod
    def sym(s):
        """한글 기호 글꼴 글자(사용자 정의 영역)를 화면에 보이는 글자로"""
        return "".join(PUA.get(c, "•") if "" <= c <= "" else c for c in (s or ""))

    def text(self, t):
        out = [esc(self.sym(t.text))]
        for ch in t:
            ln = etree.QName(ch).localname
            out.append({"tab": "&emsp;", "lineBreak": "<br>", "nbSpace": "&nbsp;", "fwSpace": "&emsp;"}.get(ln, ""))
            out.append(esc(self.sym(ch.tail)))
        return "".join(out)

    def object_pos(self, obj):
        pos = obj.find(HP + "pos")
        inline = pos is not None and pos.get("treatAsChar") == "1"
        align = (pos.get("horzAlign") if pos is not None else "LEFT") or "LEFT"
        return inline, align

    @staticmethod
    def small(obj):
        """글자 크기만 한 그림(☑ 같은 글머리 그림) — 글줄 안에 둔다"""
        sz = obj.find(HP + "sz")
        if sz is None:
            sz = obj.find(HP + "curSz")
        return sz is not None and int(sz.get("width", "0")) < 4000 and int(sz.get("height", "0")) < 4000

    def placed(self, obj, html_):
        """종이·쪽 기준으로 놓인 개체(로고·표지 글상자 등)는 그 자리에 절대 위치로. 아니면 None"""
        pos = obj.find(HP + "pos")
        if self.depth or pos is None or pos.get("treatAsChar") == "1" or pos.get("vertRelTo") not in ("PAPER", "PAGE"):
            return None                  # 글상자·표 칸 안의 개체는 흐름대로(바깥 상자 기준 좌표가 아님)
        x = int(pos.get("horzOffset", "0")) + (self.margin_l_hu if pos.get("horzRelTo") == "PAGE" else 0)
        y = int(pos.get("vertOffset", "0")) + (self.margin_t_hu if pos.get("vertRelTo") == "PAGE" else 0)
        # 기준 문단 위치(한글이 저장한 줄 위치로 계산)에서 얼마나 떨어졌는지로 놓는다 → 위쪽 높이가 조금 달라도 글과 어긋나지 않음
        if not self.seen_seg and etree.QName(obj).localname != "pic":
            return None                  # 줄 위치 정보가 없는 쪽의 글상자·표는 흐름대로(글을 가리지 않게)
        if not self.seen_seg:            # 그림(로고 등)은 쪽 기준 좌표 그대로
            self.page_floats.append(f'<div class="abs" style="left:{x / PX:.1f}px;top:{y / PX:.1f}px">{html_}</div>')
            return PLACED
        if not -3000 < y - self.anchor_top < 60000:
            return None                  # 기준 문단이 다른 쪽으로 넘어간 경우: 흐름대로 둔다
        return (f'<div class="anchor"><div class="abs" style="left:{(x - self.margin_l_hu) / PX:.1f}px;'
                f'top:{(y - self.anchor_top) / PX:.1f}px">{html_}</div></div>')

    def para_float(self, obj, html_):
        """문단 기준으로 떠 있는(글자처럼 취급하지 않는) 개체 → (가로, 세로, 높이) 정보와 함께 모아 둔다"""
        pos = obj.find(HP + "pos")
        if pos is None or pos.get("treatAsChar") == "1" or pos.get("vertRelTo") not in ("PARA", None):
            return False
        sz = obj.find(HP + "sz")
        w = int(sz.get("width", "0")) if sz is not None else 0
        h = int(sz.get("height", "0")) if sz is not None else 0
        x, y = int(pos.get("horzOffset", "0")), int(pos.get("vertOffset", "0"))
        al = pos.get("horzAlign", "LEFT")
        left = (f"left:calc(50% - {w / PX / 2:.1f}px + {x / PX:.1f}px)" if al == "CENTER" else
                f"right:{x / PX:.1f}px" if al == "RIGHT" else f"left:{x / PX:.1f}px")
        self.pfloats.append((y + h, f'<div class="abs" style="{left};top:{y / PX:.1f}px">{html_}</div>'))
        return True

    def absolute(self, html_):
        if html_ is not PLACED:
            self.anchors.append(html_)
        return ""

    def paragraph(self, p):
        if self.depth == 0:
            self.anchors = []
        html_ = self._paragraph(p)
        if self.depth == 0 and self.anchors:
            html_ = "".join(self.anchors) + html_
            self.anchors = []
        return html_

    def _paragraph(self, p):
        saved, self.pfloats = getattr(self, "pfloats", []), []
        try:
            body = self._paragraph_body(p)
            if self.pfloats:
                hgt = max(b for b, _ in self.pfloats) / PX
                body = f'<div class="pfloat" style="height:{hgt:.1f}px">{"".join(h for _, h in self.pfloats)}</div>' + body
            return body
        finally:
            self.pfloats = saved

    def _paragraph_body(self, p):
        inner, blocks = [], []
        for run in p.findall(HP + "run"):
            css = self.char.get(run.get("charPrIDRef"), "")
            for ch in run:
                ln = etree.QName(ch).localname
                if ln == "t":
                    inner.append(f'<span style="{css}">{self.text(ch) or ""}</span>')
                elif ln == "tbl":
                    inline, align = self.object_pos(ch)
                    t_html = self.table(ch, align)
                    a = self.placed(ch, t_html)
                    if a:
                        self.absolute(a)
                    elif not self.para_float(ch, t_html.replace("margin:4px auto", "margin:0").replace("margin:4px 0", "margin:0")):
                        blocks.append(t_html)
                elif ln == "pic":
                    inline, align = self.object_pos(ch)
                    a = self.placed(ch, self.img(ch))
                    if a:
                        self.absolute(a)
                    elif inline or self.small(ch):
                        inner.append(self.img(ch).replace('style="', 'style="vertical-align:middle;margin-right:3px;', 1))
                    elif self.para_float(ch, self.img(ch)):
                        pass
                    else:
                        blocks.append(f'<div class="obj" style="text-align:{align.lower()}">{self.img(ch, False)}</div>')
                elif ln in ("rect", "ellipse", "polygon") and ch.find(".//" + HP + "subList") is not None:
                    box = self.textbox(ch)
                    a = self.placed(ch, box)
                    if a:
                        self.absolute(a)
                    elif not self.para_float(ch, box.replace("margin:6px auto", "margin:0")):
                        blocks.append(box)
                elif ln == "line" and ch.find(HP + "pos") is not None and ch.find(HP + "pos").get("treatAsChar") == "1":
                    blocks.append('<hr class="shape-line">')
        body = "".join(inner)
        has_text = re.sub(r"<[^>]+>|&nbsp;|\s", "", body)
        out = ""
        if has_text or not blocks:
            first_css = self.char.get(p.findall(HP + "run")[0].get("charPrIDRef"), "") if p.findall(HP + "run") else ""
            size = re.search(r"font-size:([\d.]+)pt", first_css)
            minh = f"min-height:{float(size.group(1)) * 1.6:.0f}pt;" if size and not has_text else ""
            segs = p.findall(f"{HP}linesegarray/{HP}lineseg")
            if segs:                     # 한글이 저장해 둔 문단 높이(줄 위치)로 세로 간격을 맞춘다
                top = int(segs[0].get("vertpos", "0"))
                bot = max(int(g.get("vertpos", "0")) + int(g.get("vertsize", "0")) + int(g.get("spacing", "0")) for g in segs)
                if bot > top:
                    minh = f"min-height:{(bot - top) / PX:.1f}px;"
            out = f'<div class="p" style="{self.para.get(p.get("paraPrIDRef"), "")};{minh}">{body}</div>'
        return out + "".join(blocks)

    def sub(self, el):
        sl = el.find(".//" + HP + "subList")
        if sl is None:
            return ""
        self.depth += 1
        try:
            return "".join(self.paragraph(q) for q in sl.findall(HP + "p"))
        finally:
            self.depth -= 1

    def textbox(self, shp):
        sz = shp.find(HP + "sz")
        w = px(sz.get("width")) if sz is not None else 0
        ln = shp.find(HP + "lineShape")
        border = "1px solid #444" if ln is not None and ln.get("style", "NONE") not in ("NONE",) and ln.get("width", "0") != "0" else "none"
        bg = fill_css(shp) + ";"
        return f'<div class="box" style="width:{w}px;border:{border};{bg}">{self.sub(shp.find(HP + "drawText") if shp.find(HP + "drawText") is not None else shp)}</div>'

    def table(self, tbl, align="LEFT"):
        sz = tbl.find(HP + "sz")
        width = px(sz.get("width")) if sz is not None else 0
        margin = "margin:4px auto" if align == "CENTER" else ("margin:4px 0 4px auto" if align == "RIGHT" else "margin:4px 0")
        rows = []
        for tr in tbl.findall(HP + "tr"):
            cells = []
            for tc in tr.findall(HP + "tc"):
                span, csz = tc.find(HP + "cellSpan"), tc.find(HP + "cellSz")
                cm = tc.find(HP + "cellMargin")
                pad = (f"padding:{px(cm.get('top'))}px {px(cm.get('right'))}px {px(cm.get('bottom'))}px {px(cm.get('left'))}px"
                       if cm is not None else "padding:2px 4px")
                sl = tc.find(HP + "subList")
                va = {"CENTER": "middle", "BOTTOM": "bottom"}.get(sl.get("vertAlign") if sl is not None else "", "top")
                attrs = ""
                if span is not None and span.get("colSpan", "1") != "1":
                    attrs += f' colspan="{span.get("colSpan")}"'
                if span is not None and span.get("rowSpan", "1") != "1":
                    attrs += f' rowspan="{span.get("rowSpan")}"'
                w = px(csz.get("width")) if csz is not None else 0
                h = px(csz.get("height")) if csz is not None else 0
                style = f"{self.fill.get(tc.get('borderFillIDRef'), '')};{pad};vertical-align:{va};width:{w}px;height:{h}px"
                cells.append(f'<td{attrs} style="{style}">{self.sub(tc)}</td>')
            rows.append("<tr>" + "".join(cells) + "</tr>")
        zoom = ""
        if self.depth == 0 and self.content_w and width > self.content_w * 1.02:
            zoom = f"zoom:{self.content_w / width:.3f};"     # 쪽보다 넓은 표는 한글처럼 쪽 폭에 맞춰 줄인다
        return f'<table style="width:{width}px;{margin};{zoom}">' + "".join(rows) + "</table>"

    def render(self):
        names = sorted(n for n in self.z.namelist() if re.match(r"Contents/section\d+\.xml$", n))
        pages, page_w, pad = [], 794, "56px 75px"
        for n in names:
            sec = etree.fromstring(self.z.read(n))
            sp = sec.find(".//" + HP + "secPr")
            if sp is not None:
                pg = sp.find(HP + "pagePr")
                if pg is not None:
                    page_w = px(pg.get("width"))
                    if pg.get("landscape") == "NARROWLY" and int(pg.get("height", 0)) < int(pg.get("width", 0)):
                        page_w = px(pg.get("width"))
                    mg = pg.find(HP + "margin")
                    if mg is not None:
                        self.margin_l_hu = int(mg.get("left", 0))
                        self.content_w = px(int(pg.get("width", 0)) - int(mg.get("left", 0)) - int(mg.get("right", 0)))
                        self.margin_t_hu = int(mg.get("top", 0)) + int(mg.get("header", 0))
                        pad = (f"{px(int(mg.get('top', 0)) + int(mg.get('header', 0)))}px {px(mg.get('right'))}px "
                               f"{px(int(mg.get('bottom', 0)) + int(mg.get('footer', 0)))}px {px(mg.get('left'))}px")
            cur, last, bottom = [], -1, self.margin_t_hu
            self.page_floats, self.seen_seg = [], any(True for _ in sec.iter(HP + "lineseg"))
            for p in sec.findall(HP + "p"):
                seg = p.find(f"{HP}linesegarray/{HP}lineseg")
                vpos = int(seg.get("vertpos", "0")) if seg is not None else None
                new_page = p.get("pageBreak") == "1" or (vpos is not None and last > 0 and vpos < last - 2000)
                if new_page and cur:
                    pages.append("".join(self.page_floats) + "".join(cur))
                    cur, bottom, self.page_floats, self.seen_seg = [], self.margin_t_hu, [], False
                if vpos is not None:
                    self.seen_seg = True
                    segs = p.findall(f"{HP}linesegarray/{HP}lineseg")
                    last = max(vpos, int(segs[-1].get("vertpos", "0")))
                    self.anchor_top = self.margin_t_hu + vpos
                    bottom = self.margin_t_hu + max(int(g.get("vertpos", "0")) + int(g.get("vertsize", "0"))
                                                    + int(g.get("spacing", "0")) for g in segs)
                else:
                    self.anchor_top = bottom          # 줄 위치가 없으면 앞 문단 끝으로 어림
                cur.append(self.paragraph(p))
            pages.append("".join(self.page_floats) + "".join(cur))
            self.page_floats, self.seen_seg = [], False
        return page_w, pad, [pg for pg in pages if pg.strip()]


# 화면 폭이 좁으면 쪽·장표를 비율 그대로 줄여 보여 준다
FIT_JS = ("<script>(function(){function f(){var w=document.documentElement.clientWidth-24;"
          "document.querySelectorAll('.page,.slide,.no').forEach(function(e){e.style.zoom=1;"
          "e.style.zoom=Math.min(1,w/e.offsetWidth)})}addEventListener('resize',f);f()})()</script>")

HWPX_CSS = """
body{margin:0;background:#e9edf2;font-family:'Malgun Gothic',sans-serif;color:#000}
.bar{position:sticky;top:0;background:#14233d;color:#fff;padding:8px 16px;font-size:13px;z-index:9}
.bar b{color:#f5c518}
.page{position:relative;background:#fff;margin:18px auto;box-shadow:0 2px 10px rgba(0,0,0,.18);box-sizing:border-box;
  background-image:repeating-linear-gradient(to bottom,transparent 0,transparent 1121px,#d5dbe3 1121px,#d5dbe3 1123px)}
.anchor{position:relative;height:0}.pfloat{position:relative}.abs{position:absolute;z-index:2}
.p{white-space:pre-wrap;word-break:keep-all;overflow-wrap:anywhere;margin:0}
table{border-collapse:collapse;table-layout:fixed}
td{word-break:keep-all;overflow-wrap:anywhere;box-sizing:border-box}
td .p{line-height:1.35}
.box{box-sizing:border-box;margin:6px auto;padding:6px 10px;max-width:100%}
.obj{margin:2px 0}.obj img{max-width:100%}
hr.shape-line{border:0;border-top:1px solid #333;margin:6px 0}
@media (max-width:820px){.page{transform-origin:top left}}
"""


def hwpx_html(path, title=None):
    doc = Hwpx(path)
    w, pad, pages = doc.render()
    body = "".join(f'<div class="page" style="width:{w}px;padding:{pad};min-height:{w * 1.414:.0f}px">{pg}</div>' for pg in pages)
    name = esc(title or Path(path).name)
    return (f'<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            f"<title>{name}</title><style>{HWPX_CSS}</style>"
            f'<div class="bar"><b>미리보기</b> · {name} — 문서 내용·서식을 화면에 옮겨 그린 미리보기입니다. 줄바꿈·쪽 나눔 위치는 내려받은 파일과 조금 다를 수 있습니다.</div>'
            f"{body}{FIT_JS}</html>")


# ====================================================================== PPTX
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
P = "{http://schemas.openxmlformats.org/presentationml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
EMU = 9525.0


def _rels(z, part):
    d, f = part.rsplit("/", 1)
    rp = f"{d}/_rels/{f}.rels"
    if rp not in z.namelist():
        return {}
    out = {}
    for r in etree.fromstring(z.read(rp)):
        tgt = r.get("Target")
        if r.get("TargetMode") == "External":
            continue
        parts = (d + "/" + tgt).split("/")
        norm = []
        for x in parts:
            if x == "..":
                norm.pop()
            elif x and x != ".":
                norm.append(x)
        out[r.get("Id")] = "/".join(norm)
    return out


class Pptx:
    def __init__(self, path):
        self.z = zipfile.ZipFile(path)
        pres = etree.fromstring(self.z.read("ppt/presentation.xml"))
        sz = pres.find(P + "sldSz")
        self.w, self.h = int(sz.get("cx")) / EMU, int(sz.get("cy")) / EMU
        rels = _rels(self.z, "ppt/presentation.xml")
        self.slides = [rels[s.get(R + "id")] for s in pres.find(P + "sldIdLst")]
        self.theme = {}
        for n in self.z.namelist():
            if re.match(r"ppt/theme/theme\d+\.xml$", n):
                th = etree.fromstring(self.z.read(n))
                cs = th.find(".//" + A + "clrScheme")
                if cs is not None:
                    for c in cs:
                        v = c.find(A + "srgbClr")
                        sys_ = c.find(A + "sysClr")
                        self.theme[etree.QName(c).localname] = (v.get("val") if v is not None else
                                                                sys_.get("lastClr") if sys_ is not None else "000000")
                break
        self.clrmap = {"tx1": "dk1", "bg1": "lt1", "tx2": "dk2", "bg2": "lt2"}
        for n in self.z.namelist():
            if re.match(r"ppt/slideMasters/slideMaster\d+\.xml$", n):
                cm = etree.fromstring(self.z.read(n)).find(P + "clrMap")
                if cm is not None:
                    self.clrmap.update(dict(cm.attrib))
                break

    def color(self, el):
        if el is None:
            return None
        c = el.find(A + "srgbClr")
        if c is not None:
            return self._alpha("#" + c.get("val"), c)
        c = el.find(A + "schemeClr")
        if c is not None:
            name = self.clrmap.get(c.get("val"), c.get("val"))
            return self._alpha("#" + self.theme.get(name, "000000"), c)
        return None

    @staticmethod
    def _alpha(hexcolor, node):
        """색에 투명도(a:alpha, 1000분의 1 %)가 있으면 rgba()로 — 겹치는 반투명 원 같은 도형용"""
        al = node.find(A + "alpha")
        if al is None or len(hexcolor) != 7:
            return hexcolor
        r, g, b = (int(hexcolor[i:i + 2], 16) for i in (1, 3, 5))
        return f"rgba({r},{g},{b},{int(al.get('val', '100000')) / 100000:.2f})"

    def master_styles(self, slide_part):
        """슬라이드 → 레이아웃 → 마스터의 제목·본문 기본 글자(크기·색)와 배경"""
        lay = next((v for v in _rels(self.z, slide_part).values() if "slideLayout" in v), None)
        mas = next((v for v in _rels(self.z, lay).values() if "slideMaster" in v), None) if lay else None
        st = {"title": (44, "#000000"), "body": (18, "#000000"), "other": (18, "#000000"), "bg": None}
        if not mas:
            return st
        m = etree.fromstring(self.z.read(mas))
        for key, tag in (("title", "titleStyle"), ("body", "bodyStyle"), ("other", "otherStyle")):
            d = m.find(f"{P}txStyles/{P}{tag}/{A}lvl1pPr/{A}defRPr")
            if d is not None:
                st[key] = (int(d.get("sz", st[key][0] * 100)) / 100, self.color(d.find(A + "solidFill")) or st[key][1])
        for part in (lay, mas):
            bg = etree.fromstring(self.z.read(part)).find(f"{P}cSld/{P}bg/{P}bgPr")
            if bg is not None:
                st["bg"] = self.color(bg.find(A + "solidFill"))
                break
        return st

    def media(self, rels, rid):
        path = rels.get(rid)
        if not path:
            return ""
        ext = path.rsplit(".", 1)[-1].lower()
        if ext not in MIME:
            return ""
        return f"data:{MIME[ext]};base64,{base64.b64encode(self.z.read(path)).decode()}"

    def shape(self, el, rels, st, scale, off=(0, 0, 1, 1)):
        ox, oy, sx, sy = off
        ln = etree.QName(el).localname
        sppr = el.find(P + "spPr") if ln != "grpSp" else el.find(P + "grpSpPr")
        xf = sppr.find(A + "xfrm") if sppr is not None else None
        if xf is None:
            return ""
        x = (int(xf.find(A + "off").get("x")) / EMU - ox) * sx
        y = (int(xf.find(A + "off").get("y")) / EMU - oy) * sy
        w = int(xf.find(A + "ext").get("cx")) / EMU * sx
        h = int(xf.find(A + "ext").get("cy")) / EMU * sy
        if ln == "grpSp":
            ch_off, ch_ext = xf.find(A + "chOff"), xf.find(A + "chExt")
            cx0, cy0 = int(ch_off.get("x")) / EMU, int(ch_off.get("y")) / EMU
            cw, chh = max(1, int(ch_ext.get("cx")) / EMU), max(1, int(ch_ext.get("cy")) / EMU)
            inner = "".join(self.shape(c, rels, st, scale, (cx0, cy0, w / cw if cw else 1, h / chh if chh else 1))
                            for c in el if etree.QName(c).localname in ("sp", "pic", "grpSp", "cxnSp"))
            return f'<div style="position:absolute;left:{x * scale:.1f}px;top:{y * scale:.1f}px;width:{w * scale:.1f}px;height:{h * scale:.1f}px">{inner}</div>'
        box = f"position:absolute;left:{x * scale:.1f}px;top:{y * scale:.1f}px;width:{w * scale:.1f}px;height:{h * scale:.1f}px;"
        if ln == "pic":
            blip = el.find(f".//{A}blip")
            src = self.media(rels, blip.get(R + "embed")) if blip is not None else ""
            return f'<img src="{src}" style="{box}object-fit:fill" alt="">' if src else ""
        fill = self.color(sppr.find(A + "solidFill")) if sppr is not None else None
        geom = sppr.find(A + "prstGeom") if sppr is not None else None
        radius = "border-radius:12%;" if geom is not None and geom.get("prst") == "roundRect" else (
            "border-radius:50%;" if geom is not None and geom.get("prst") == "ellipse" else "")
        line = sppr.find(A + "ln") if sppr is not None else None
        border = ""
        if line is not None and line.find(A + "solidFill") is not None:
            lw = max(1, int(line.get("w", "12700")) / EMU * scale)
            border = f"border:{lw:.1f}px solid {self.color(line.find(A + 'solidFill'))};"
        css = box + (f"background:{fill};" if fill else "") + radius + border
        tx = el.find(P + "txBody")
        if tx is None:
            return f'<div style="{css}"></div>'
        ph = el.find(f".//{P}ph")
        kind = "other" if ph is None else ("title" if ph.get("type") in ("title", "ctrTitle") else "body")
        dsz, dcol = st[kind]
        bp = tx.find(A + "bodyPr")
        anchor = {"ctr": "center", "b": "flex-end"}.get(bp.get("anchor") if bp is not None else "", "flex-start")
        ins = [int(bp.get(k, d)) / EMU * scale if bp is not None else d / EMU * scale
               for k, d in (("tIns", 45720), ("rIns", 91440), ("bIns", 45720), ("lIns", 91440))]
        paras = []
        for p in tx.findall(A + "p"):
            ppr = p.find(A + "pPr")
            algn = {"ctr": "center", "r": "right", "just": "justify"}.get(ppr.get("algn") if ppr is not None else "", "left")
            end = p.find(A + "endParaRPr")
            runs = []
            for r in p:
                rl = etree.QName(r).localname
                if rl == "br":
                    runs.append("<br>")
                if rl not in ("r", "fld"):
                    continue
                rpr = r.find(A + "rPr")
                sz = int(rpr.get("sz")) / 100 if rpr is not None and rpr.get("sz") else (
                    int(end.get("sz")) / 100 if end is not None and end.get("sz") else dsz)
                col = (self.color(rpr.find(A + "solidFill")) if rpr is not None else None) or dcol
                bold = "font-weight:700;" if rpr is not None and rpr.get("b") == "1" else ""
                runs.append(f'<span style="font-size:{sz * scale * 1.333:.1f}px;color:{col};{bold}">{esc(r.findtext(A + "t"))}</span>')
            esz = int(end.get("sz")) / 100 if end is not None and end.get("sz") else dsz
            paras.append(f'<div style="text-align:{algn};min-height:{esz * scale * 1.333:.1f}px;line-height:1.2">{"".join(runs)}</div>')
        pad = "padding:" + " ".join(f"{v:.1f}px" for v in ins) + ";"
        return (f'<div style="{css}{pad}box-sizing:border-box;display:flex;flex-direction:column;justify-content:{anchor};'
                f'overflow:hidden;word-break:keep-all">{"".join(paras)}</div>')

    def render(self, width=960):
        scale = width / self.w
        out = []
        for i, part in enumerate(self.slides, 1):
            s = etree.fromstring(self.z.read(part))
            rels = _rels(self.z, part)
            st = self.master_styles(part)
            bgpr = s.find(f"{P}cSld/{P}bg/{P}bgPr")
            bg = (self.color(bgpr.find(A + "solidFill")) if bgpr is not None else None) or st["bg"] or "#FFFFFF"
            tree = s.find(f"{P}cSld/{P}spTree")
            lay = next((v for v in rels.values() if "slideLayout" in v), None)   # 레이아웃의 로고 그림(365 행복 천안 등)
            under = ""
            if lay:
                lt = etree.fromstring(self.z.read(lay)).find(f"{P}cSld/{P}spTree")
                lr = _rels(self.z, lay)
                under = "".join(self.shape(el, lr, st, scale) for el in lt if etree.QName(el).localname == "pic")
            shapes = under + "".join(self.shape(el, rels, st, scale) for el in tree
                             if etree.QName(el).localname in ("sp", "pic", "grpSp", "cxnSp"))
            out.append(f'<div class="no">{i}</div><div class="slide" style="width:{width}px;height:{self.h * scale:.0f}px;'
                       f'background:{bg}">{shapes}</div>')
        return "".join(out)


PPTX_CSS = """
body{margin:0;background:#e9edf2;font-family:'Malgun Gothic','맑은 고딕',sans-serif}
.bar{position:sticky;top:0;background:#14233d;color:#fff;padding:8px 16px;font-size:13px;z-index:9}
.bar b{color:#f5c518}
.no{width:960px;margin:18px auto 4px;color:#6b7785;font-size:13px}
.slide{position:relative;margin:0 auto;box-shadow:0 2px 10px rgba(0,0,0,.2);overflow:hidden}
"""


def pptx_html(path, title=None):
    body = Pptx(path).render()
    name = esc(title or Path(path).name)
    return (f'<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            f"<title>{name}</title><style>{PPTX_CSS}</style>"
            f'<div class="bar"><b>미리보기</b> · {name} — 내려받은 PowerPoint 장표와 같은 내용·배치입니다.</div>{body}{FIT_JS}</html>')


def document_html(path, title=None):
    suf = Path(path).suffix.lower()
    if suf == ".hwpx":
        return hwpx_html(path, title)
    if suf == ".pptx":
        return pptx_html(path, title)
    raise ValueError(f"미리보기를 만들 수 없는 파일: {path}")
