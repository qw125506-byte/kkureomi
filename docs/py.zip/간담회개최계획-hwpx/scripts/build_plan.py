#!/usr/bin/env python3
"""원본 간담회 계획서(HWPX)를 복제해 새 행사 내용만 바꿔 넣는다.

사용법:
    python build_plan.py content.json 결과.hwpx [--template templates/원본_간담회계획.hwpx]

원칙
  - 원본의 header.xml(글꼴·크기·색·줄간격·문단모양·테두리) 정의, 용지·여백(secPr), 결재란·로고·
    표 너비·셀 병합·배경색은 그대로 두고 글자만 바꾼다.
  - 행 수가 달라지는 표(행사흐름·소요예산·행정사항·향후계획·붙임)는 원본 행을 복제해 늘이고 줄인다.
    첫 행·중간 행·끝 행의 테두리 차이도 원본대로 따른다.
  - 원본에만 있던 그림(총장 사진 등)은 새 문서에서 쓰지 않으면 파일에서 지운다. 로고는 남긴다.
  - content.json 의 구조는 reference/content_구조.md 참고.
"""
import copy
import json
import random
import re
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from lxml import etree

HP = "http://www.hancom.co.kr/hwpml/2011/paragraph"
HC = "http://www.hancom.co.kr/hwpml/2011/core"
HH = "http://www.hancom.co.kr/hwpml/2011/head"
OPF = "http://www.idpf.org/2007/opf/"
N = {"hp": HP, "hc": HC, "hh": HH, "opf": OPF}
Q = lambda t: "{%s}%s" % (HP, t)  # noqa: E731

DEFAULT_TEMPLATE = Path(__file__).resolve().parent.parent / "templates" / "원본_간담회계획.hwpx"

# ---- 원본 양식의 고정 위치(표 id / 본문 최상위 문단 번호) --------------------------
T_APPROVAL = "1758158192"   # 표지 결재란
T_COVER_TITLE = "1758158193"  # 표지 머리문구 + 제목
T_COVER_BOX = "1782427933"  # 표지 행사 요약
T_COVER_DEPT = "1782427939"  # 표지 기관명·부서명(로고 옆)
T_BODY_TITLE = "1270099679"  # 본문 제목
T_PURPOSE_BOX = "1436782086"  # 개최 취지 요약상자
T_ATTEND_BOX = "1127693720"  # Ⅱ 참석 구성 상자(원본: 관내 12개 대학 현황)
T_AGENDA_BOX = "1133777881"  # Ⅱ 주요안건 ▶ 상자
T_FLOW = "1127693708"       # Ⅲ 행사흐름 표
T_BUDGET = "1133777870"     # Ⅳ 소요예산 표
T_ADMIN = "1133777880"      # Ⅴ 행정사항 표
T_FUTURE = "2063222768"     # Ⅵ 향후계획 표
T_ATT_HEAD = "2059716583"   # 붙임 머리 상자(붙 임1)
T_ATT_ROSTER = "1127693718"  # 붙임1 명단 표(소속·성명·사진 ×2열, 사진은 칸 배경 그림)
T_ATT_STATUS = "1129416498"  # 붙임2 현황 상자(소제목 도형·❖ 항목·※ 주석·현황 표)
P = dict(goal1=35, goal_gap=36, goal2=37, goal2b=38, date=42, place=43, attend=44, attend_box=45,
         flow_after=51, budget_amt=54, budget_after=56, admin_after=61, future_after=64,
         att_list1=65, att_list2=66, att_blank_from=67, att_blank_to=72, att_head=73, att_old=(74, 75, 76))


class BuildError(Exception):
    pass


# ---------------------------------------------------------------- 기본 도구
_used_ids = set()


def new_id():
    while True:
        v = str(random.randint(1_000_000_000, 2_100_000_000))
        if v not in _used_ids:
            _used_ids.add(v)
            return v


def drop_lineseg(p):
    for ls in p.findall("hp:linesegarray", N):
        p.remove(ls)


def text_ts(p):
    """문단 바로 아래 run 들의 hp:t 목록"""
    return [t for run in p.findall("hp:run", N) for t in run.findall("hp:t", N)]


def t_text(t):
    return (t.text or "") + "".join((c.tail or "") for c in t)


def set_t(t, s):
    for c in list(t):
        t.remove(c)
    t.text = s


def p_text(p):
    return "".join(t_text(t) for t in text_ts(p))


LEAD_SYMBOL = re.compile(r"^\s*([\ue000-\uf8ff❖◆◇■□●○❍▶▪☑]+)\s*")


def keep_symbol(old, new):
    """원래 글 앞의 글머리 기호(❖ 등, 한글 기호 글꼴 글자 포함)는 새 글에도 그대로 붙인다."""
    m = LEAD_SYMBOL.match(old or "")
    if m and not new.lstrip().startswith(m.group(1)):
        return old[:m.end()] + new.lstrip()
    return new


def set_value(p, s):
    """글자가 있는 마지막 칸(값 자리)만 바꾼다. 앞의 항목명·기호는 그대로 둔다."""
    ts = [t for t in text_ts(p) if t_text(t).strip()]
    if not ts:
        ts = text_ts(p)
    if not ts:
        run = p.find("hp:run", N)
        if run is None:
            raise BuildError("글자 칸이 없는 문단")
        ts = [etree.SubElement(run, Q("t"))]
    new = keep_symbol(t_text(ts[-1]), s)
    if t_text(ts[-1]) == new:
        return                      # 글이 같으면 그대로(줄 배치 유지)
    set_t(ts[-1], new)
    drop_lineseg(p)


def set_only(p, s):
    """첫 글자 칸에 전체 글을 넣고 나머지 칸은 비운다(셀 안 글자용)."""
    if p_text(p) == s:
        return                      # 글이 같으면 그대로(한글이 저장해 둔 줄 배치를 살린다)
    ts = text_ts(p)
    if not ts:
        run = p.find("hp:run", N)
        if run is None:
            run = etree.SubElement(p, Q("run"))
            run.set("charPrIDRef", "0")
        ts = [etree.SubElement(run, Q("t"))]
    lead = [t for t in ts if t_text(t).strip()]
    first = lead[0] if lead else ts[0]
    for t in ts:
        set_t(t, s if t is first else "")
    # 빈 run 정리(그림·표 등 다른 요소가 없는 run 만)
    for run in p.findall("hp:run", N):
        if all(etree.QName(c).localname == "t" and not t_text(c) for c in run) and run is not first.getparent():
            if len(p.findall("hp:run", N)) > 1:
                p.remove(run)
    drop_lineseg(p)


def fresh(el):
    """복제한 요소의 표·그림·도형 id 를 새로 매긴다."""
    for x in el.iter(Q("tbl"), Q("pic"), Q("rect"), Q("container"), Q("ellipse"), Q("line")):
        x.set("id", new_id())
        if x.get("instid"):
            x.set("instid", new_id())
    return el


def clone(el):
    return fresh(copy.deepcopy(el))


def insert_after(anchor, nodes):
    for n in nodes:
        anchor.addnext(n)
        anchor = n
    return anchor


def remove(el):
    if el is not None and el.getparent() is not None:
        el.getparent().remove(el)


def find_tbl(root, tid):
    r = root.xpath(".//hp:tbl[@id='%s']" % tid, namespaces=N)
    if not r:
        raise BuildError("원본 양식에서 표(id=%s)를 찾지 못했습니다 — 양식이 바뀌었는지 확인" % tid)
    return r[0]


def owner_p(el):
    """표·그림을 품고 있는 문단"""
    p = el.getparent()
    while p is not None and etree.QName(p).localname != "p":
        p = p.getparent()
    return p


def cell(tbl, row, col):
    for tc in tbl.iter(Q("tc")):
        a = tc.find("hp:cellAddr", N)
        if a.get("rowAddr") == str(row) and a.get("colAddr") == str(col):
            return tc
    raise BuildError("표 %s 에 (%d,%d) 칸이 없습니다" % (tbl.get("id"), row, col))


def cell_ps(tc):
    return tc.findall("hp:subList/hp:p", N)


# ---------------------------------------------------------------- 자간 자동 맞춤
# 한글이 새로 줄을 나눌 때 한 줄에 들어가야 할 글(표 칸·참석 줄)이 넘치면, 담당자가 한글에서 하듯 자간을 줄인다.
# 글자 폭(글자 크기 대비): 한글·한자·기호 1, 띄어쓰기 0.5, 쉼표·마침표 0.3, 숫자 0.55 — 최종 계획서의 실제 줄나눔으로 맞춘 값.
HEADER = {"root": None, "changed": False}
FIT_MIN_SPACING = -30         # 이보다 더 좁히면 읽기 어려워 그대로 둔다(줄바꿈)
_spaced = {}


def char_w(ch):
    o = ord(ch)
    if ch == " ":
        return 0.5
    if ch in ",.":
        return 0.3
    if ch.isdigit():
        return 0.55
    if ch in "()[]'\"":
        return 0.35
    if ch in "·:;~-/":
        return 0.45
    if o < 128:
        return 0.65 if ch.isupper() else 0.5
    if 0xE000 <= o <= 0xF8FF or ch in "▪•":
        return 1.0
    return 1.0


def _charpr(cid):
    for c in HEADER["root"].iter("{%s}charPr" % HH):
        if c.get("id") == cid:
            return c
    return None


def _cp_metrics(cid):
    c = _charpr(cid)
    if c is None:
        return 1000, 100, 0
    ratio = c.find("{%s}ratio" % HH)
    sp = c.find("{%s}spacing" % HH)
    return (int(c.get("height", "1000")), int(ratio.get("hangul", "100")) if ratio is not None else 100,
            int(sp.get("hangul", "0")) if sp is not None else 0)


def charpr_variant(cid, spacing=None, scale=None):
    """글자 모양(charPr)을 복제해 자간(%)이나 크기(배율)만 바꾼 새 모양의 id"""
    key = (cid, spacing, scale)
    if key in _spaced:
        return _spaced[key]
    src = _charpr(cid)
    if src is None:
        return cid
    nc = copy.deepcopy(src)
    parent = src.getparent()
    new_id = str(max(int(c.get("id")) for c in parent) + 1)
    nc.set("id", new_id)
    if spacing is not None:
        for k, _ in nc.find("{%s}spacing" % HH).attrib.items():
            nc.find("{%s}spacing" % HH).set(k, str(spacing))
    if scale is not None:
        nc.set("height", str(int(int(nc.get("height")) * scale)))
    parent.append(nc)
    parent.set("itemCnt", str(len(parent)))
    HEADER["changed"] = True
    _spaced[key] = new_id
    return new_id


_paras = {}


def parapr_variant(pid, align=None, prev=None):
    """문단 모양(paraPr)을 복제해 정렬이나 위 간격(HWPUNIT)만 바꾼 새 모양의 id"""
    key = (pid, align, prev)
    if key in _paras:
        return _paras[key]
    src = next((x for x in HEADER["root"].iter("{%s}paraPr" % HH) if x.get("id") == pid), None)
    if src is None:
        return pid
    np_ = copy.deepcopy(src)
    parent = src.getparent()
    new_id = str(max(int(x.get("id")) for x in parent) + 1)
    np_.set("id", new_id)
    if align:
        np_.find("{%s}align" % HH).set("horizontal", align)
    if prev is not None:
        for m in np_.iter("{%s}margin" % HH):
            for x in m:
                if etree.QName(x).localname == "prev":
                    x.set("value", str(prev))
    parent.append(np_)
    parent.set("itemCnt", str(len(parent)))
    HEADER["changed"] = True
    _paras[key] = new_id
    return new_id


def _para_margin(p):
    for pp in HEADER["root"].iter("{%s}paraPr" % HH):
        if pp.get("id") == p.get("paraPrIDRef"):
            m = pp.find(".//{%s}margin" % HH)
            if m is not None:
                v = {etree.QName(x).localname: int(x.get("value", "0")) for x in m}
                return v.get("left", 0) + v.get("right", 0) + max(0, v.get("intent", 0))
    return 0


def line_width(p, extra_sp=0):
    total = 0.0
    for pic in p.iter(Q("pic")):                    # 글줄 안 그림(☑ 등)도 폭에 넣는다
        sz = pic.find("hp:curSz", N)
        if sz is not None and int(sz.get("width", "0")) < 4000:
            total += int(sz.get("width", "0")) + 300
    for run in p.findall("hp:run", N):
        txt = "".join(t_text(t) for t in run.findall("hp:t", N))
        if not txt:
            continue
        em, ratio, sp = _cp_metrics(run.get("charPrIDRef"))
        for ch in txt:
            total += em * (char_w(ch) * ratio / 100 + (sp + extra_sp) / 100)
    return total


FIT_TARGET = 0.90             # 한글 글꼴은 어림값보다 조금 넓다 — 10% 여유를 둔다
MAX_SQUEEZE = 12              # 원래 자간에서 최대 12만큼만 줄인다(더 줄이면 읽기 어려움 — 그때는 줄바꿈)
CELL_TARGET, CELL_SQUEEZE = 0.94, 15   # 표 칸(짧은 글): 여유 6%, 최대 15까지(최종 계획서에서 손으로 줄인 정도)


def fit_line(p, avail, ratio=None, squeeze=None):
    """문단이 avail(HWPUNIT) 안에 한 줄로 들어가게 자간을 줄인다. 못 맞추면 원래대로 두고 False."""
    if HEADER["root"] is None or avail <= 0:
        return False
    target = (avail - _para_margin(p)) * (ratio or FIT_TARGET)
    max_squeeze = squeeze or MAX_SQUEEZE
    if line_width(p) <= target:
        return True
    runs = [r for r in p.findall("hp:run", N) if "".join(t_text(t) for t in r.findall("hp:t", N))]
    before = [r.get("charPrIDRef") for r in runs]
    base = [_cp_metrics(c)[2] for c in before]
    for need in range(1, max_squeeze + 1):
        for r, c, sp in zip(runs, before, base):
            r.set("charPrIDRef", charpr_variant(c, spacing=max(FIT_MIN_SPACING, sp - need)) if sp - need < sp else c)
        if line_width(p) <= target:
            return True
        if all(sp - need <= FIT_MIN_SPACING for sp in base):
            break
    for r, c in zip(runs, before):          # 끝까지 못 맞추면 원래대로(억지로 좁히지 않는다)
        r.set("charPrIDRef", c)
    return False


def short_detail(d):
    """참석 설명 괄호 안 줄이기(인원은 그대로):
    「(시장님, 관내 12개 대학 총장)」 → 「(시장님, 12개 대학 총장)」(꾸밈말 빼기),
    「(청년 창업가 20명, 창업지원기관 5명, 관계 공무원 5명)」 → 「(청년 창업가 20명 등)」(무리가 셋 이상이면)"""
    inner = d.strip()
    wrapped = inner.startswith("(") and inner.endswith(")")
    if wrapped:
        inner = inner[1:-1]
    parts = [re.sub(r"(관내|천안시)\s+", "", x.strip()) for x in inner.split(",") if x.strip()]
    main = [x for x in parts if "시장" not in x]
    if len(main) >= 3 or (len(main) == 2 and len(parts) > 2):
        keep = [x for x in parts if "시장" in x] + [main[0] + " 등"]
    else:
        keep = parts
    inner = ", ".join(keep)
    return f"({inner})" if wrapped else inner


def body_avail(sec):
    """본문 폭(용지 폭 - 왼쪽·오른쪽 여백)"""
    pg = sec.find(".//hp:secPr/hp:pagePr", N)
    if pg is None:
        return 0
    mg = pg.find("hp:margin", N)
    return int(pg.get("width", "0")) - int(mg.get("left", "0")) - int(mg.get("right", "0"))


def cell_avail(tc):
    sz, cm = tc.find("hp:cellSz", N), tc.find("hp:cellMargin", N)
    w = int(sz.get("width", "0")) if sz is not None else 0
    if cm is not None:
        w -= int(cm.get("left", "0")) + int(cm.get("right", "0"))
    return w


def set_cell_lines(tc, lines):
    """칸 안 문단 수를 lines 에 맞춘다(첫 문단을 복제). 서식은 각 자리 문단 것을 따른다."""
    if isinstance(lines, str):
        lines = lines.split("\n")
    lines = [str(x) for x in lines] or [""]
    ps = cell_ps(tc)
    sub = tc.find("hp:subList", N)
    while len(ps) < len(lines):
        nw = clone(ps[-1])
        ps[-1].addnext(nw)
        ps.append(nw)
    for p in ps[len(lines):]:
        sub.remove(p)
    for p, s in zip(ps, lines):
        set_only(p, s)
        if s.strip():
            fit_line(p, cell_avail(tc), ratio=CELL_TARGET, squeeze=CELL_SQUEEZE)


def as_lines(v):
    if v is None:
        return [""]
    if isinstance(v, list):
        return [str(x) for x in v]
    return str(v).split("\n")


# ---------------------------------------------------------------- 표 행 다시 만들기
def row_height(tr):
    h = 0
    for tc in tr.findall("hp:tc", N):
        if tc.find("hp:cellSpan", N).get("rowSpan", "1") == "1":
            h = max(h, int(tc.find("hp:cellSz", N).get("height")))
    return h


def renumber(tbl):
    rows = tbl.findall("hp:tr", N)
    for r, tr in enumerate(rows):
        for tc in tr.findall("hp:tc", N):
            tc.find("hp:cellAddr", N).set("rowAddr", str(r))
    tbl.set("rowCnt", str(len(rows)))
    hs = [row_height(tr) for tr in rows]
    sz = tbl.find("hp:sz", N)
    if sz is not None and all(hs):
        sz.set("height", str(sum(hs)))


def rebuild_rows(tbl, keep, first, middle, last, data, fill):
    """keep: 남길 머리 행 수. first/middle/last: 행 본(tr). data 각 항목마다 fill(tr, item, i)"""
    for tr in tbl.findall("hp:tr", N)[keep:]:
        tbl.remove(tr)
    n = len(data)
    for i, item in enumerate(data):
        if i == 0 and first is not None:
            src = first
        elif i == n - 1 and n > 1 and last is not None:
            src = last
        else:
            src = middle
        tr = clone(src)
        for q in tr.iter(Q("p")):
            drop_lineseg(q)
        fill(tr, item, i)
        tbl.append(tr)
    renumber(tbl)


def tr_cells(tr):
    return {int(tc.find("hp:cellAddr", N).get("colAddr")): tc for tc in tr.findall("hp:tc", N)}


def row_with_borders(src_tr, border_tr):
    """src_tr 모양(칸 나눔)에 border_tr 의 테두리(같은 열)를 입힌 행 본"""
    tr = copy.deepcopy(src_tr)
    bmap = {c: tc.get("borderFillIDRef") for c, tc in tr_cells(border_tr).items()}
    for c, tc in tr_cells(tr).items():
        if c in bmap:
            tc.set("borderFillIDRef", bmap[c])
    for tc in tr.findall("hp:tc", N):
        tc.find("hp:cellSpan", N).set("rowSpan", "1")
    return tr


def merge_same(tbl, col, values, start_row):
    """values[i] 가 이어서 같으면 col 열을 세로로 병합한다(원본의 통계목·관련부서 병합 방식)."""
    rows = tbl.findall("hp:tr", N)
    i = 0
    while i < len(values):
        j = i
        while j + 1 < len(values) and values[j + 1] == values[i] and str(values[i]).strip():
            j += 1
        if j > i:
            top = tr_cells(rows[start_row + i])[col]
            h = sum(row_height(rows[start_row + k]) for k in range(i, j + 1))
            top.find("hp:cellSpan", N).set("rowSpan", str(j - i + 1))
            top.find("hp:cellSz", N).set("height", str(h))
            for k in range(i + 1, j + 1):
                rows[start_row + k].remove(tr_cells(rows[start_row + k])[col])
        i = j + 1


# ---------------------------------------------------------------- 구역별 채우기
def fill_cover(root, c, tops):
    g = c.get("결재", {})
    ap = find_tbl(root, T_APPROVAL)
    if g.get("문서번호"):
        set_only(cell_ps(cell(ap, 0, 1))[0], g["문서번호"] + " ")
    line = g.get("결재선")
    if line:
        cols = [4, 5, 6, 7, 8]
        if len(line) != 5:
            raise BuildError("결재선은 원본 결재란 칸 수대로 5칸이어야 합니다(담당 팀장~시장)")
        for col, v in zip(cols, line):
            tc = cell(ap, 0, col)
            ps = cell_ps(tc)
            vs = as_lines(v)
            if len(vs) > len(ps):
                vs = vs[: len(ps) - 1] + [" ".join(vs[len(ps) - 1:])]
            vs += [""] * (len(ps) - len(vs))
            for p, s in zip(ps, vs):
                set_only(p, s)
    if "협조" in g:
        set_only(cell_ps(cell(ap, 4, 4))[0], g["협조"])
    if g.get("보존기간"):
        set_only(cell_ps(cell(ap, 2, 1))[0], g["보존기간"])
    if g.get("공개여부"):
        set_only(cell_ps(cell(ap, 5, 1))[0], g["공개여부"])

    s = c["표지"]
    tt = find_tbl(root, T_COVER_TITLE)
    set_only(cell_ps(cell(tt, 0, 0))[0], s["머리문구"])
    set_only(cell_ps(cell(tt, 2, 0))[-1], s["제목"])

    box = find_tbl(root, T_COVER_BOX)
    ps = cell_ps(cell(box, 0, 0))  # 일시, 장소, 참석대상, ※보충, 주요내용
    set_value(ps[0], " " + s["일시"])
    set_value(ps[1], s["장소"])
    set_value(ps[2], s["참석대상"])
    if s.get("참석보충"):
        set_value(ps[3], s["참석보충"])
    else:
        remove(ps[3])
    set_value(ps[4], s["주요내용"])
    box_cell = cell(box, 0, 0)
    for q in cell_ps(box_cell):                   # 표지 요약 줄도 한 줄로(넘치면 자간 조금 줄임)
        if p_text(q).strip():
            fit_line(q, cell_avail(box_cell))

    dept = find_tbl(root, T_COVER_DEPT)
    dps = cell_ps(cell(dept, 0, 1))
    b = c.get("기본", {})
    if b.get("기관명"):
        set_only(dps[0], b["기관명"])
    set_only(dps[1], "[%s]" % b["부서"])
    dps[1].set("paraPrIDRef", parapr_variant(dps[1].get("paraPrIDRef"), prev=700))   # 「천안시」와 너무 붙지 않게
    drop_lineseg(dps[1])
    # 표지는 쪽을 꽉 채운다 — 띄운 만큼 표지 뒤 빈 줄 하나를 빼야 빈 줄이 다음 쪽 맨 위로 넘어가지 않는다
    blanks = []
    nxt = owner_p(dept).getnext()
    while nxt is not None and etree.QName(nxt).localname == "p" and not p_text(nxt).strip() and not any(
            etree.QName(x).localname != "t" for r in nxt.findall("hp:run", N) for x in r if etree.QName(x).localname not in ("t", "ctrl")):
        blanks.append(nxt)
        nxt = nxt.getnext()
    if len(blanks) >= 2:
        remove(blanks[-1])

    bt = find_tbl(root, T_BODY_TITLE)
    set_only(cell_ps(cell(bt, 1, 0))[0], c.get("본문제목") or s["제목"])

    lines = c["취지"]
    if isinstance(lines, str):
        lines = [lines]
    pb = find_tbl(root, T_PURPOSE_BOX)
    tc = cell(pb, 0, 0)
    ps = cell_ps(tc)
    set_value(ps[0], " " + lines[0])
    rest = lines[1:]
    sub = tc.find("hp:subList", N)
    tmpl = ps[1]
    anchor = ps[0]
    news = []
    for ln in rest:
        nw = clone(tmpl)
        set_only(nw, "    " + ln.strip())
        news.append(nw)
    sub.remove(tmpl)
    insert_after(anchor, news)


def fill_goals(c, tops):
    goals = c["추진목적"]
    g1, gap, g2, g2b = tops[P["goal1"]], tops[P["goal_gap"]], tops[P["goal2"]], tops[P["goal2b"]]
    out = []
    for i, s in enumerate(goals):
        if i:
            out.append(copy.deepcopy(gap))
        p = copy.deepcopy(g1)
        set_value(p, s)
        out.append(p)
    anchor = g1.getprevious()
    for x in (g1, gap, g2, g2b):
        remove(x)
    insert_after(anchor, out)


def fill_overview(root, c, tops):
    o = c["행사개요"]
    set_value(tops[P["date"]], o["일시"])
    set_value(tops[P["place"]], o["장소"])
    if o.get("주재"):
        p = copy.deepcopy(tops[P["place"]])
        ts = [t for t in text_ts(p) if t_text(t).strip()]
        set_t(ts[-2], t_text(ts[-2]).replace("장   소", "주   재"))   # 항목명 칸(앞뒤 띄어쓰기 유지)
        set_t(ts[-1], o["주재"])
        drop_lineseg(p)
        tops[P["place"]].addnext(p)
    a = o["참석"]
    pa = tops[P["attend"]]
    runs = pa.findall("hp:run", N)  # ❍ / (참 석) / 인원 / 상세 / * / 보충
    set_t(runs[2].find("hp:t", N), a["인원"] + (" " if a.get("상세") else ""))
    if a.get("상세"):
        set_t(runs[3].find("hp:t", N), a["상세"] + " ")
    else:
        pa.remove(runs[3])
    if a.get("보충"):
        set_t(runs[5].find("hp:t", N), a["보충"])
    else:
        pa.remove(runs[4])
        pa.remove(runs[5])
    drop_lineseg(pa)
    avail = body_avail(root)
    if not fit_line(pa, avail) and a.get("보충"):
        star = runs[4]
        t = star.find("hp:t", N)                         # 「*」 앞에서 줄을 바꿔 다음 줄이 「*배석(…)」으로 시작
        mark = (t.text or "*").strip() or "*"
        t.text = None
        for c in list(t):
            t.remove(c)
        etree.SubElement(t, Q("lineBreak")).tail = mark
        first = copy.deepcopy(pa)                         # 첫 줄(❍ (참 석) 인원 (상세))만 따로 재어 본다
        for r in first.findall("hp:run", N)[4:]:
            first.remove(r)
        if line_width(first) > (avail - _para_margin(pa)) * 0.97 and a.get("상세"):
            set_t(runs[3].find("hp:t", N), short_detail(a["상세"]) + " ")   # 괄호 안을 줄인다(인원은 그대로)
    elif a.get("상세") and not fit_line(pa, avail):
        set_t(runs[3].find("hp:t", N), short_detail(a["상세"]) + " ")
        fit_line(pa, avail)

    box = find_tbl(root, T_ATTEND_BOX)
    comp = o.get("참석구성")
    if comp:
        set_only(cell_ps(cell(box, 0, 1))[0], comp["제목"])
        tc = cell(box, 2, 0)
        set_cell_lines(tc, comp["줄"])
        for q in cell_ps(tc):                            # 목록은 가운데 정렬
            q.set("paraPrIDRef", parapr_variant(q.get("paraPrIDRef"), align="CENTER"))
    else:
        remove(owner_p(box))

    ag = o["주요안건"]
    abox = find_tbl(root, T_AGENDA_BOX)
    tc = cell(abox, 0, 0)
    ps = cell_ps(tc)
    mid, last = ps[0], ps[-1]
    sub = tc.find("hp:subList", N)
    for p in ps:
        sub.remove(p)
    for i, s in enumerate(ag):
        p = copy.deepcopy(last if i == len(ag) - 1 else mid)
        set_value(p, " ▶ " + s)
        sub.append(p)


def make_note(tops, text):
    """원본의 *배석 주석과 같은 글꼴(charPr 149, 한컴산뜻돋움 14pt)로 주석 문단을 만든다."""
    p = copy.deepcopy(tops[P["att_blank_from"]])
    run = p.find("hp:run", N)
    run.set("charPrIDRef", "149")
    for t in run.findall("hp:t", N):
        run.remove(t)
    t = etree.SubElement(run, Q("t"))
    t.text = text
    drop_lineseg(p)
    return p


def add_notes(anchor, tops, notes):
    if not notes:
        return anchor
    if isinstance(notes, str):
        notes = [notes]
    return insert_after(anchor, [make_note(tops, s) for s in notes])


def fill_flow(root, c, tops):
    f = c["행사흐름"]
    tbl = find_tbl(root, T_FLOW)
    rows = tbl.findall("hp:tr", N)
    first, middle, last = copy.deepcopy(rows[1]), copy.deepcopy(rows[2]), copy.deepcopy(rows[-1])

    def fill(tr, it, i):
        cs = tr_cells(tr)
        set_cell_lines(cs[0], [it["시간"]])
        set_cell_lines(cs[1], [it["소요"]])
        set_cell_lines(cs[2], ["▪ " + it["내용"]])
        set_cell_lines(cs[3], as_lines(it.get("비고", "")))
    rebuild_rows(tbl, 1, first, middle, last, f["행"], fill)
    add_notes(owner_p(tbl), tops, f.get("주석"))


def fill_budget(root, c, tops):
    b = c["소요예산"]
    set_value(tops[P["budget_amt"]], " " + b["예산액"])
    tbl = find_tbl(root, T_BUDGET)
    rows = tbl.findall("hp:tr", N)
    set_cell_lines(tr_cells(rows[1])[2], [b["합계"]])
    item = copy.deepcopy(rows[4])

    def fill(tr, it, i):
        cs = tr_cells(tr)
        name = it["구분"]
        m = re.match(r"^(.+?)\s*(\([^()]+\))$", name) if isinstance(name, str) else None
        set_cell_lines(cs[0], as_lines(name))
        if m and not fit_line(cell_ps(cs[0])[0], cell_avail(cs[0])):
            set_cell_lines(cs[0], [m.group(1), m.group(2)])
            small = cell_ps(cs[0])[1]
            for r in small.findall("hp:run", N):
                r.set("charPrIDRef", charpr_variant(r.get("charPrIDRef"), scale=0.8))
            fit_line(small, cell_avail(cs[0]))
        set_cell_lines(cs[1], [it["산출기초"]])
        if not fit_line(cell_ps(cs[1])[0], cell_avail(cs[1])):        # 넘치면 「×」 앞뒤 띄어쓰기를 붙여 한 줄로
            set_cell_lines(cs[1], [re.sub(r"\s*×\s*", "×", it["산출기초"])])
        set_cell_lines(cs[2], [it["금액"]])
        set_cell_lines(cs[3], as_lines(it.get("통계목", "")))
    rebuild_rows(tbl, 2, None, item, None, b["항목"], fill)
    merge_same(tbl, 3, [it.get("통계목", "") for it in b["항목"]], 2)
    renumber(tbl)
    add_notes(owner_p(tbl), tops, b.get("주석"))


def fill_numbered(tbl, data, cols, merge_col=None, notes=None, tops=None):
    rows = tbl.findall("hp:tr", N)
    plain = rows[-1]  # 칸 나눔이 온전한 마지막 행(테두리: 중간 행)
    first = row_with_borders(plain, rows[1])
    middle = row_with_borders(plain, plain)

    def fill(tr, it, i):
        cs = tr_cells(tr)
        vals = [str(i + 1)] + [it.get(k, "") for k in cols]
        for ci, v in enumerate(vals):
            if ci == 1:
                v = " " + v if v and not v.startswith(" ") else v
            set_cell_lines(cs[ci], as_lines(v))
    rebuild_rows(tbl, 1, first, middle, None, data, fill)
    if merge_col is not None:
        merge_same(tbl, merge_col, [it.get(cols[merge_col - 1], "") for it in data], 1)
        renumber(tbl)
    add_notes(owner_p(tbl), tops, notes)


def fill_admin(root, c, tops):
    a = c["행정사항"]
    fill_numbered(find_tbl(root, T_ADMIN), a["행"], ["내용", "관련부서", "비고"], merge_col=2, notes=a.get("주석"), tops=tops)


def fill_future(root, c, tops):
    f = c["향후계획"]
    fill_numbered(find_tbl(root, T_FUTURE), f["행"], ["내용", "비고"], notes=f.get("주석"), tops=tops)


def fill_attachments(root, c, tops, pristine):
    att = c.get("붙임") or []
    photos = {}
    l1, l2 = tops[P["att_list1"]], tops[P["att_list2"]]
    head = tops[P["att_head"]]
    old = [tops[i] for i in P["att_old"]] + [tops[i] for i in range(P["att_blank_from"], P["att_blank_to"] + 1)]
    # 붙임 목록 문단
    if not att:
        set_only(l1, "끝.")
        remove(l2)
        for x in old + [head]:
            remove(x)
        return photos
    else:
        items = []
        for i, a in enumerate(att):
            p = copy.deepcopy(l1 if i == 0 else l2)
            prefix = "붙임  " if i == 0 else "      "
            s = "%s%d. %s %s." % (prefix, i + 1, a["제목"], a.get("부수", "1부"))
            if i == len(att) - 1:
                s += "  끝."
            set_only(p, s)
            items.append(p)
        anchor = l1.getprevious()
        remove(l1)
        remove(l2)
        insert_after(anchor, items)
    # 붙임 본문 — 원본 붙임 머리 상자 자리에 새로 만든 문단을 넣는다
    out = []
    for i, a in enumerate(att):
        h = clone(head)
        h.set("pageBreak", "1")  # 붙임은 새 쪽에서 시작(원본 배치)
        t = h.find(".//hp:tbl", N)
        set_only(cell_ps(cell(t, 0, 0))[0], "붙 임%d" % (i + 1))
        set_only(cell_ps(cell(t, 0, 1))[0], " " + a["제목"])
        out.append(h)
        kind = a.get("형식") or ("명단" if a.get("명단") else "현황" if a.get("현황") else "표" if a.get("표") else "문단")
        if kind == "명단":
            out.extend(build_roster(a, pristine, photos))
        elif kind == "현황":
            out.append(build_status(a, pristine))
        elif kind == "표":
            out.append(build_simple_table(a, pristine))
        elif kind != "문단":
            raise BuildError("붙임 형식은 명단·현황·표·문단 중 하나입니다: %s" % kind)
        for s in as_lines(a.get("문단")) if a.get("문단") else []:
            out.append(make_body(tops, s))
        for s in ([a["주석"]] if isinstance(a.get("주석"), str) else a.get("주석") or []):
            out.append(make_note(tops, s))
    for x in out:
        head.addprevious(x)
    for x in old + [head]:
        remove(x)
    return photos


# ---------------------------------------------------------------- 붙임 틀 ① 명단 (원본 붙임1)
def plain_twin(header, bf_id):
    """그림 채우기가 든 칸 테두리와 테두리 모양이 같고 채우기가 없는 원본 테두리 id"""
    bfs = {b.get("id"): b for b in header.iter("{%s}borderFill" % HH)}

    def sig(b):
        return tuple(etree.tostring(b.find("hh:%s" % k, N)) for k in ("leftBorder", "rightBorder", "topBorder", "bottomBorder"))
    want = sig(bfs[bf_id])
    for bid, b in bfs.items():
        if b.find("hc:fillBrush", N) is None and sig(b) == want:
            return bid
    raise BuildError("사진 칸(%s)과 같은 테두리의 빈 칸 모양을 원본에서 찾지 못했습니다" % bf_id)


def bf_image(header, bf_id):
    for b in header.iter("{%s}borderFill" % HH):
        if b.get("id") == bf_id:
            img = b.find(".//hc:img", N)
            return img.get("binaryItemIDRef") if img is not None else None
    return None


ROSTER_PER_PAGE = 12  # 원본 붙임1: 한 쪽 6행 × 2명


def build_roster(a, pristine, photos):
    """원본 붙임1 명단 표를 12명(한 쪽)씩 나눠 만든다. 둘째 표부터는 새 쪽에서 시작한다.
    사진 자리는 원본 12칸뿐이라 사진은 첫 쪽 12명까지만 넣는다."""
    people = a["명단"]
    use_photo = any(p.get("사진") for p in people)
    head_lbl = a.get("머리") or ["소    속", "성   명", "사   진" if use_photo else "비   고"]
    out = []
    for k in range(0, max(len(people), 1), ROSTER_PER_PAGE):
        part = dict(a, 명단=people[k:k + ROSTER_PER_PAGE], 머리=head_lbl)
        if k:
            for person in part["명단"]:
                if person.get("사진"):
                    raise BuildError("사진은 명단 앞 12명까지만 넣을 수 있습니다(원본 사진 칸 12개): %s" % person.get("성명"))
        tp = build_roster_page(part, pristine, photos)
        if k:
            tp.set("pageBreak", "1")
        out.append(tp)
    return out


def build_roster_page(a, pristine, photos):
    """원본 붙임1 명단 표(소속·성명·사진 ×2열)를 복제해 사람 수만큼 행을 만든다.
    왼쪽 열을 먼저 위에서 아래로 채우고 나머지를 오른쪽 열에 채운다(원본 배치)."""
    header = pristine["header"]
    tp = clone(pristine["roster"])
    tp.set("pageBreak", "0")
    tbl = tp.find(".//hp:tbl", N)
    rows = tbl.findall("hp:tr", N)
    people = a["명단"]
    use_photo = any(p.get("사진") for p in people)
    head_lbl = a.get("머리") or ["소    속", "성   명", "사   진" if use_photo else "비   고"]
    hdr = tr_cells(rows[0])
    for side in (0, 3):
        for k in range(3):
            set_cell_lines(hdr[side + k], [head_lbl[k]])
    n = len(people)
    nrow = (n + 1) // 2
    left, right = people[:nrow], people[nrow:]
    srcs = rows[1:]
    for tr in srcs:
        tbl.remove(tr)
    for i in range(nrow):
        slot = i < len(srcs)  # 원본 사진 자리가 있는 행
        tr = copy.deepcopy(srcs[i] if slot else srcs[-2])
        cs = tr_cells(tr)
        for side, person in ((0, left[i] if i < len(left) else None), (3, right[i] if i < len(right) else None)):
            person = person or {}
            set_cell_lines(cs[side], as_lines(person.get("소속", "")))
            set_cell_lines(cs[side + 1], as_lines(person.get("성명", "")))
            pc = cs[side + 2]
            bf = pc.get("borderFillIDRef")
            if person.get("사진") and slot and bf_image(header, bf):
                photos[bf_image(header, bf)] = person["사진"]
                set_cell_lines(pc, [""])
            else:
                if bf_image(header, bf):
                    pc.set("borderFillIDRef", plain_twin(header, bf))
                set_cell_lines(pc, as_lines(person.get("비고", "")))
        tbl.append(tr)
    renumber(tbl)
    return tp


# ---------------------------------------------------------------- 붙임 틀 ② 현황 (원본 붙임2)
def keep_columns(tbl, k):
    """표의 앞쪽 k개 열만 남기고 표 전체 너비는 원본대로 유지한다(오른쪽 끝 테두리는 원본 마지막 열 것)."""
    ncol = int(tbl.get("colCnt"))
    if k == ncol:
        return
    if not 2 <= k <= ncol:
        raise BuildError("현황 표 열 수는 2~%d 입니다" % ncol)
    first = tr_cells(tbl.find("hp:tr", N))
    widths = [int(first[c].find("hp:cellSz", N).get("width")) for c in range(ncol)]
    total, kept = sum(widths), sum(widths[:k])
    new = [round(w * total / kept) for w in widths[:k]]
    new[-1] += total - sum(new)
    for tr in tbl.findall("hp:tr", N):
        cs = tr_cells(tr)
        edge = cs[ncol - 1].get("borderFillIDRef")
        for c in range(k, ncol):
            tr.remove(cs[c])
        for c in range(k):
            cs[c].find("hp:cellSz", N).set("width", str(new[c]))
        cs[k - 1].set("borderFillIDRef", edge)
    tbl.set("colCnt", str(k))


# 현황 표 글자 모양(원본 charPr): 머리 / 합계 행 / 본문 행 첫 줄. 열 번호별, 없으면 마지막 값
ST_HEAD = ["118", "118", "119", "120", "122", "118", "128"]
ST_TOTAL = ["130", "129", "129", "129", "129", "129", "129"]
ST_BODY = ["140", "113", "106", "140", "140", "140", "105"]
# 열을 줄인 표(이름·대표·주소 열 구성이 아닌 표)는 모든 열을 같은 글자 모양으로, 첫 열은 가운데 정렬(원본 표 문단모양 20)
ST_BODY_PLAIN = ["140"]
CENTER_PP = "20"


def center(tc):
    for p in cell_ps(tc):
        p.set("paraPrIDRef", CENTER_PP)


def restyle(tc, cp):
    for p in cell_ps(tc):
        for run in p.findall("hp:run", N):
            run.set("charPrIDRef", cp)


def color_changes(tc):
    """증감 표기 색: (▲…) 빨강, (▼…) 파랑, (-) 검정 — 원본 붙임2 표와 같은 글자 모양"""
    for p in cell_ps(tc):
        s = p_text(p).strip()
        cp = "134" if s.startswith("(▲") else "136" if s.startswith("(▼") else "140" if s == "(-)" else None
        if cp:
            for run in p.findall("hp:run", N):
                run.set("charPrIDRef", cp)


def build_status(a, pristine):
    """원본 붙임2 현황 상자: [남색 소제목 도형] + ❖ (항목) 값 + ※ 주석 + 현황 표 를 묶음마다 반복"""
    box = clone(pristine["status"])
    box.set("pageBreak", "0")
    tbl = box.find(".//hp:tbl", N)
    tc = tbl.find(".//hp:tc", N)
    sub = tc.find("hp:subList", N)
    sub.set("vertAlign", "TOP")
    tp = cell_ps(tc)  # 0 소제목, 1 청년인구 줄, 2 ※주석, 3·4 빈 줄, 5 소제목, 6 빈 줄, 7 ❖항목, 8 ❖항목, 9 표, 10 빈 줄
    t_title, t_item, t_note, t_gap1, t_gap2, t_tbl, t_end = tp[0], tp[7], tp[2], tp[3], tp[4], tp[9], tp[10]
    for p in tp:
        sub.remove(p)
    for si, sct in enumerate(a["현황"]):
        if si:
            sub.append(clone(t_gap1))
            sub.append(clone(t_gap2))
        if sct.get("제목"):
            p = clone(t_title)
            set_only(p.find(".//hp:drawText/hp:subList/hp:p", N), sct["제목"])
            sub.append(p)
        for it in sct.get("항목", []):
            p = copy.deepcopy(t_item)
            runs = p.findall("hp:run", N)  # 앞칸 / (항목) / 값
            set_t(runs[1].find("hp:t", N), "(%s) " % it["이름"])
            set_t(runs[2].find("hp:t", N), it["값"])
            sub.append(p)
        for s in ([sct["주석"]] if isinstance(sct.get("주석"), str) else sct.get("주석") or []):
            p = copy.deepcopy(t_note)
            set_t(p.findall("hp:run", N)[1].find("hp:t", N), s)
            sub.append(p)
        if sct.get("표"):
            sub.append(build_status_table(t_tbl, sct["표"]))
    sub.append(copy.deepcopy(t_end))
    return box


def build_status_table(tmpl_p, tb):
    p = clone(tmpl_p)
    tbl = p.find(".//hp:tbl", N)
    keep_columns(tbl, len(tb["머리"]))
    rows = tbl.findall("hp:tr", N)
    hdr, total, first, middle, last = rows[0], rows[1], rows[2], rows[3], rows[-1]
    k = len(tb["머리"])
    full = k == 7
    pick = lambda arr, c: arr[-1] if c == k - 1 else arr[min(c, len(arr) - 1)]  # noqa: E731  끝 열은 원본 비고 열 모양
    for c, s in enumerate(tb["머리"]):
        hc = tr_cells(hdr)[c]
        set_cell_lines(hc, as_lines(s))
        restyle(hc, pick(ST_HEAD, c))
        if c == 0 and not full:
            center(hc)
    for tr in rows[1:]:
        tbl.remove(tr)

    def put(src, vals, style):
        tr = copy.deepcopy(src)
        cs = tr_cells(tr)
        for c in range(len(cs)):
            set_cell_lines(cs[c], as_lines(vals[c] if c < len(vals) else ""))
            restyle(cs[c], pick(style, c))
            if c == 0 and not full:
                center(cs[c])
            color_changes(cs[c])
        tbl.append(tr)
    if tb.get("합계"):
        put(total, tb["합계"], ST_TOTAL)
    body = tb["행"]
    bstyle = ST_BODY if full else ST_BODY_PLAIN + ["140"] * (k - 2) + ["105"]
    for i, vals in enumerate(body):
        put(first if i == 0 else last if i == len(body) - 1 and len(body) > 1 else middle, vals, bstyle)
    renumber(tbl)
    return p


def build_simple_table(a, pristine):
    """(보조) Ⅵ·Ⅴ 표 모양을 빌린 단순 표 — 원본 붙임 틀(명단·현황)이 맞지 않을 때만 쓴다."""
    tb = a["표"]
    ncol = len(tb["머리"])
    src = {3: pristine["future"], 4: pristine["admin"]}.get(ncol)
    if src is None:
        raise BuildError("단순 표는 3열 또는 4열만 지원합니다")
    tp = clone(src)
    tp.set("pageBreak", "0")
    tbl = tp.find(".//hp:tbl", N)
    rows = tbl.findall("hp:tr", N)
    hdr = tr_cells(rows[0])
    for ci, s in enumerate(tb["머리"]):
        set_cell_lines(hdr[ci], [s])
    plain = rows[-1]
    first = row_with_borders(plain, rows[1])

    def fill(tr, it, k):
        cs = tr_cells(tr)
        for ci, v in enumerate(it):
            set_cell_lines(cs[ci], as_lines(v))
    rebuild_rows(tbl, 1, first, row_with_borders(plain, plain), None, tb["행"], fill)
    return tp


def make_body(tops, text):
    p = copy.deepcopy(tops[P["att_list1"]])
    set_only(p, text)
    return p


# ---------------------------------------------------------------- 패키지 정리
def all_text(root):
    lines = []
    for p in root.iter(Q("p")):
        s = "".join(t_text(t) for t in text_ts(p)).strip()
        if s:
            lines.append(s)
    return lines


def white_png(w=120, h=170):
    import struct
    import zlib
    raw = b"".join(b"\x00" + b"\xff" * (w * 3) for _ in range(h))

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + \
        chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")


def prune_images(sec_xml, header_root, hpf_root):
    """본문에서 쓰지 않는 그림(원본 행사 사진 등)을 지운다. 지운 파일 목록을 돌려준다."""
    used_bf = set(re.findall(r'borderFillIDRef="(\d+)"', sec_xml))
    used_img = set(re.findall(r'binaryItemIDRef="([^"]+)"', sec_xml))
    for bf in header_root.iter("{%s}borderFill" % HH):
        imgs = bf.findall(".//hc:img", N)
        if not imgs:
            continue
        if bf.get("id") in used_bf:
            used_img |= {i.get("binaryItemIDRef") for i in imgs}
        else:
            fb = bf.find("hc:fillBrush", N)
            ib = fb.find("hc:imgBrush", N) if fb is not None else None
            if ib is not None:
                fb.remove(ib)
                if len(fb) == 0:
                    bf.remove(fb)
    removed = []
    for it in hpf_root.iter("{%s}item" % OPF):
        href = it.get("href", "")
        if href.startswith("BinData/") and it.get("id") not in used_img:
            removed.append(href)
            it.getparent().remove(it)
    return removed


MEDIA = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".bmp": "image/bmp", ".gif": "image/gif"}


def put_photos(photos, hpf_root, removed):
    """명단 사진: 원본 사진 칸이 쓰던 그림 자리(같은 id)에 새 사진 파일을 넣는다. header 의 칸 모양은 그대로."""
    added = {}
    items = {it.get("id"): it for it in hpf_root.iter("{%s}item" % OPF)}
    for img_id, path in photos.items():
        src = Path(path)
        ext = src.suffix.lower()
        if not src.is_file():
            raise BuildError("사진 파일이 없습니다: %s" % path)
        if ext not in MEDIA:
            raise BuildError("사진은 jpg·png·bmp·gif 만 넣을 수 있습니다: %s" % path)
        it = items.get(img_id)
        if it is None:
            raise BuildError("원본 사진 자리(%s)를 찾지 못했습니다" % img_id)
        removed.append(it.get("href"))  # 원본 총장 사진 파일은 빼고
        href = "BinData/%s%s" % (img_id, ext)
        it.set("href", href)
        it.set("media-type", MEDIA[ext])
        added[href] = src.read_bytes()
    return added


def ser(root):
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)


def build(content, out_path, template=DEFAULT_TEMPLATE):
    zin = zipfile.ZipFile(template)
    sec = etree.fromstring(zin.read("Contents/section0.xml"))
    _used_ids.update(re.findall(r'\bid="(\d+)"', zin.read("Contents/section0.xml").decode("utf8")))
    tops = sec.findall("hp:p", N)
    if len(tops) != 77:
        raise BuildError("원본 양식의 문단 수(%d)가 예상(77)과 다릅니다 — templates/원본 파일이 바뀌었는지 확인" % len(tops))
    header = etree.fromstring(zin.read("Contents/header.xml"))
    HEADER["root"], HEADER["changed"] = header, False
    _spaced.clear()
    _paras.clear()
    pristine = {"future": copy.deepcopy(owner_p(find_tbl(sec, T_FUTURE))),
                "admin": copy.deepcopy(owner_p(find_tbl(sec, T_ADMIN))),
                "roster": copy.deepcopy(owner_p(find_tbl(sec, T_ATT_ROSTER))),  # 붙임1 명단 표
                "status": copy.deepcopy(owner_p(find_tbl(sec, T_ATT_STATUS))),  # 붙임2 현황 상자
                "header": header}

    fill_cover(sec, content, tops)
    fill_goals(content, tops)
    fill_overview(sec, content, tops)
    fill_flow(sec, content, tops)
    fill_budget(sec, content, tops)
    fill_admin(sec, content, tops)
    fill_future(sec, content, tops)
    photos = fill_attachments(sec, content, tops, pristine)

    # 줄 배치 캐시(linesegarray): 글을 바꾼 문단은 set_* 에서 지웠다. 그대로인 문단은 한글이 저장한 배치를 살린다.
    # 행을 복제해 늘인 표의 문단은 rebuild_rows 에서 지운다(위치가 바뀌므로).
    left = [s for s in all_text(sec) if "\n" in s]
    if left:
        raise BuildError("문단 안에 줄바꿈이 남았습니다: %s" % left[:2])

    sec_xml = ser(sec)
    hpf = etree.fromstring(zin.read("Contents/content.hpf"))
    removed = prune_images(sec_xml.decode("utf8"), header, hpf)
    added = put_photos(photos, hpf, removed)
    title = content.get("기본", {}).get("파일제목") or content["표지"]["제목"]
    t = hpf.find(".//opf:title", N)
    if t is not None:
        t.text = title
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    for m in hpf.iter("{%s}meta" % OPF):
        if m.get("name") == "ModifiedDate":
            m.text = now

    parts = {
        "Contents/section0.xml": sec_xml,
        "Contents/header.xml": ser(header) if (removed or HEADER["changed"]) else zin.read("Contents/header.xml"),
        "Contents/content.hpf": ser(hpf),
        "Preview/PrvText.txt": "\r\n".join(all_text(sec))[:1000].encode("utf8"),
        "Preview/PrvImage.png": white_png(),  # 원본 표지 미리보기가 남지 않게(한글 열기 확인 때 새로 만듦)
    }
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    names = [i.filename for i in zin.infolist()]
    with zipfile.ZipFile(out_path, "w") as zout:
        for n in ["mimetype"] + [x for x in names if x != "mimetype"]:
            if n in removed:
                continue
            info = zin.getinfo(n)
            data = parts.get(n, None)
            if data is None:
                data = zin.read(n)
            ct = zipfile.ZIP_STORED if n == "mimetype" else zipfile.ZIP_DEFLATED
            zi = zipfile.ZipInfo(n, date_time=info.date_time)
            zi.compress_type = ct
            zout.writestr(zi, data)
        for n, data in added.items():
            zi = zipfile.ZipInfo(n, date_time=datetime.now().timetuple()[:6])
            zi.compress_type = zipfile.ZIP_DEFLATED
            zout.writestr(zi, data)
    return {"removed_images": removed, "lines": all_text(sec), "photos": sorted(added)}


def main(argv):
    args, tpl = [], DEFAULT_TEMPLATE
    i = 0
    while i < len(argv):
        if argv[i] == "--template":
            tpl = argv[i + 1]
            i += 2
        else:
            args.append(argv[i])
            i += 1
    if len(args) != 2:
        print(__doc__)
        return 2
    content = json.loads(Path(args[0]).read_text(encoding="utf8"))
    try:
        r = build(content, args[1], tpl)
    except BuildError as e:
        print("[실패] " + str(e))
        return 1
    print("[완료] %s" % args[1])
    if r["removed_images"]:
        print("  원본에만 쓰인 그림 %d개를 뺐습니다: %s" % (len(r["removed_images"]), ", ".join(r["removed_images"])))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
